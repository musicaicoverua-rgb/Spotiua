# OpenWave Music Streaming App

A comprehensive music streaming application built with Flutter, featuring gamification, offline support, and multi-language localization.

## Features

### Core Features
- 🎵 Music streaming from Supabase Storage
- 📱 Cross-platform (Android & iOS)
- 🌐 8 Language support (Ukrainian, English, Spanish, Russian, German, French, Polish, Czech)
- 🎨 Material 3 Design
- 🌙 Dark/Light theme support

### Audio Features
- ▶️ Background playback with media controls
- 🔀 Shuffle and repeat modes
- 📋 Queue management
- 📻 Internet Radio support

### Gamification
- 🎯 Points & Coins system
- ⭐ XP & Level progression
- 🎁 Daily Rewards with streaks
- 🎰 Spin Wheel for luck-based rewards
- 🏆 Achievements system

### Social & Admin
- 💬 Real-time chat with admin
- 👤 Admin panel for track uploads
- 📊 Analytics & listening statistics
- ❤️ Like and playlist management

### Offline Support
- 💾 Download tracks for offline listening
- 🗄️ Local SQLite database with Drift
- 📦 Smart cache management

## Tech Stack

- **Framework**: Flutter 3.x
- **State Management**: Flutter Bloc + GetIt
- **Backend**: Supabase (Auth, PostgreSQL, Storage, Realtime)
- **Local Database**: Drift (SQLite)
- **Audio**: just_audio + audio_service
- **Localization**: easy_localization

## Getting Started

### Prerequisites
- Flutter SDK >= 3.0.0
- Dart SDK >= 3.0.0
- Android Studio / Xcode
- Supabase account

### Installation

1. Clone the repository
```bash
git clone https://github.com/yourusername/openwave.git
cd openwave
```

2. Install dependencies
```bash
flutter pub get
```

3. Generate code files
```bash
dart run build_runner build --delete-conflicting-outputs
```

4. Run the app
```bash
flutter run
```

### Supabase Setup

1. Create a new Supabase project
2. Run the SQL schema from `supabase_schema.sql`
3. Create storage buckets:
   - `tracks` (public, audio files)
   - `covers` (public, images)
4. Update the Supabase URL and anon key in `lib/main.dart`

### Building for Production

**Android:**
```bash
flutter build apk --release
flutter build appbundle --release
```

**iOS:**
```bash
flutter build ios --release
```

## Project Structure

```
lib/
├── core/
│   ├── database/       # Drift database
│   ├── di/            # Dependency injection
│   ├── models/        # Data models
│   ├── router/        # Navigation
│   ├── services/      # Business logic services
│   └── theme/         # App theming
├── features/
│   ├── admin/         # Admin panel
│   ├── analytics/     # User analytics
│   ├── auth/          # Authentication
│   ├── chat/          # Real-time chat
│   ├── gamification/  # Rewards & achievements
│   ├── home/          # Home screen & tabs
│   ├── player/        # Audio player
│   ├── profile/       # User profile
│   ├── radio/         # Internet radio
│   └── settings/      # App settings
└── main.dart
```

## Localization

The app supports 8 languages:
- Ukrainian (uk) - Default
- English (en)
- Spanish (es)
- Russian (ru)
- German (de)
- French (fr)
- Polish (pl)
- Czech (cs)

Translation files are located in `assets/translations/`.

## License

This project is licensed under the MIT License.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.
