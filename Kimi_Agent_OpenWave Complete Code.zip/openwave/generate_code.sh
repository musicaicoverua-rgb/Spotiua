#!/bin/bash

# OpenWave Code Generation Script
# This script generates all necessary code files for the project

echo "========================================"
echo "OpenWave Code Generation"
echo "========================================"
echo ""

# Check if Flutter is installed
if ! command -v flutter &> /dev/null; then
    echo "Error: Flutter is not installed or not in PATH"
    exit 1
fi

# Get dependencies
echo "Step 1: Getting dependencies..."
flutter pub get

# Generate code with build_runner
echo ""
echo "Step 2: Generating code files..."
dart run build_runner build --delete-conflicting-outputs

# Generate localization files
echo ""
echo "Step 3: Generating localization files..."
flutter gen-l10n

echo ""
echo "========================================"
echo "Code generation complete!"
echo "========================================"
echo ""
echo "Next steps:"
echo "1. Run the SQL schema in Supabase: supabase_schema.sql"
echo "2. Update Supabase credentials in lib/main.dart"
echo "3. Run: flutter run"
echo ""
