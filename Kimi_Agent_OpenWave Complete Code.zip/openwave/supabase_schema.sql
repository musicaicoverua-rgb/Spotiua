-- OpenWave Music Streaming App - Complete Supabase Schema
-- Execute this in Supabase SQL Editor

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================
-- PROFILES TABLE (User data & Gamification)
-- ============================================
CREATE TABLE IF NOT EXISTS profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT UNIQUE NOT NULL,
    username TEXT UNIQUE,
    display_name TEXT,
    avatar_url TEXT,
    is_admin BOOLEAN DEFAULT FALSE,
    
    -- Gamification fields
    points INTEGER DEFAULT 0,
    coins INTEGER DEFAULT 0,
    xp INTEGER DEFAULT 0,
    level INTEGER DEFAULT 1,
    total_listening_time INTEGER DEFAULT 0, -- in seconds
    
    -- Daily rewards
    last_daily_reward TIMESTAMP WITH TIME ZONE,
    daily_streak INTEGER DEFAULT 0,
    
    -- Preferences
    preferred_language TEXT DEFAULT 'uk',
    is_premium BOOLEAN DEFAULT FALSE,
    
    -- Metadata
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- TRACKS TABLE (Music metadata)
-- ============================================
CREATE TABLE IF NOT EXISTS tracks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    artist TEXT NOT NULL,
    album TEXT,
    genre TEXT,
    duration INTEGER, -- in seconds
    file_path TEXT NOT NULL, -- Supabase Storage path
    file_size BIGINT,
    bitrate INTEGER,
    
    -- Metadata
    cover_url TEXT,
    release_year INTEGER,
    track_number INTEGER,
    
    -- Stats
    play_count INTEGER DEFAULT 0,
    likes_count INTEGER DEFAULT 0,
    
    -- Upload info
    uploaded_by UUID REFERENCES profiles(id),
    is_public BOOLEAN DEFAULT TRUE,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- PLAYLISTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS playlists (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    description TEXT,
    cover_url TEXT,
    owner_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    is_public BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- PLAYLIST TRACKS (Junction table)
-- ============================================
CREATE TABLE IF NOT EXISTS playlist_tracks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    playlist_id UUID REFERENCES playlists(id) ON DELETE CASCADE,
    track_id UUID REFERENCES tracks(id) ON DELETE CASCADE,
    position INTEGER NOT NULL,
    added_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(playlist_id, track_id)
);

-- ============================================
-- PLAY HISTORY (For AI recommendations)
-- ============================================
CREATE TABLE IF NOT EXISTS play_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    track_id UUID REFERENCES tracks(id) ON DELETE CASCADE,
    played_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    duration_played INTEGER DEFAULT 0, -- seconds actually listened
    completed BOOLEAN DEFAULT FALSE,
    source TEXT -- 'search', 'recommendation', 'playlist', 'radio'
);

-- ============================================
-- USER LIKES
-- ============================================
CREATE TABLE IF NOT EXISTS user_likes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    track_id UUID REFERENCES tracks(id) ON DELETE CASCADE,
    liked_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, track_id)
);

-- ============================================
-- REWARDS CONFIGURATION
-- ============================================
CREATE TABLE IF NOT EXISTS rewards_config (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    reward_type TEXT NOT NULL, -- 'daily', 'spin', 'achievement', 'listening'
    name TEXT NOT NULL,
    description TEXT,
    points INTEGER DEFAULT 0,
    coins INTEGER DEFAULT 0,
    xp INTEGER DEFAULT 0,
    min_reward INTEGER,
    max_reward INTEGER,
    cooldown_hours INTEGER DEFAULT 24,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- USER REWARDS HISTORY
-- ============================================
CREATE TABLE IF NOT EXISTS user_rewards (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    reward_type TEXT NOT NULL,
    points_earned INTEGER DEFAULT 0,
    coins_earned INTEGER DEFAULT 0,
    xp_earned INTEGER DEFAULT 0,
    claimed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- SPIN WHEEL REWARDS
-- ============================================
CREATE TABLE IF NOT EXISTS spin_wheel_rewards (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    reward_type TEXT NOT NULL, -- 'coins', 'points', 'xp'
    value INTEGER NOT NULL,
    probability_weight INTEGER DEFAULT 1, -- Higher = more likely
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- CHAT MESSAGES (Real-time)
-- ============================================
CREATE TABLE IF NOT EXISTS chat_messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sender_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    receiver_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- RADIO STATIONS
-- ============================================
CREATE TABLE IF NOT EXISTS radio_stations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    description TEXT,
    stream_url TEXT NOT NULL,
    cover_url TEXT,
    genre TEXT,
    country TEXT,
    language TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- OFFLINE CACHE METADATA
-- ============================================
CREATE TABLE IF NOT EXISTS offline_cache (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    track_id UUID REFERENCES tracks(id) ON DELETE CASCADE,
    local_path TEXT NOT NULL,
    file_size BIGINT,
    cached_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_accessed TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, track_id)
);

-- ============================================
-- ANALYTICS EVENTS
-- ============================================
CREATE TABLE IF NOT EXISTS analytics_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    event_type TEXT NOT NULL,
    event_data JSONB,
    session_id TEXT,
    device_info JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- ACHIEVEMENTS
-- ============================================
CREATE TABLE IF NOT EXISTS achievements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    description TEXT,
    icon_url TEXT,
    requirement_type TEXT NOT NULL, -- 'listening_time', 'tracks_played', 'level_reached', etc.
    requirement_value INTEGER NOT NULL,
    points_reward INTEGER DEFAULT 0,
    coins_reward INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- USER ACHIEVEMENTS
-- ============================================
CREATE TABLE IF NOT EXISTS user_achievements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    achievement_id UUID REFERENCES achievements(id) ON DELETE CASCADE,
    unlocked_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, achievement_id)
);

-- ============================================
-- INDEXES FOR PERFORMANCE
-- ============================================
CREATE INDEX IF NOT EXISTS idx_tracks_artist ON tracks(artist);
CREATE INDEX IF NOT EXISTS idx_tracks_genre ON tracks(genre);
CREATE INDEX IF NOT EXISTS idx_tracks_created ON tracks(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_play_history_user ON play_history(user_id, played_at DESC);
CREATE INDEX IF NOT EXISTS idx_play_history_track ON play_history(track_id);
CREATE INDEX IF NOT EXISTS idx_chat_sender ON chat_messages(sender_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_chat_receiver ON chat_messages(receiver_id, is_read);
CREATE INDEX IF NOT EXISTS idx_user_likes ON user_likes(user_id);
CREATE INDEX IF NOT EXISTS idx_analytics_user ON analytics_events(user_id, created_at DESC);

-- ============================================
-- ROW LEVEL SECURITY POLICIES
-- ============================================

-- Enable RLS on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE tracks ENABLE ROW LEVEL SECURITY;
ALTER TABLE playlists ENABLE ROW LEVEL SECURITY;
ALTER TABLE playlist_tracks ENABLE ROW LEVEL SECURITY;
ALTER TABLE play_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE offline_cache ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_rewards ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_achievements ENABLE ROW LEVEL SECURITY;

-- PROFILES POLICIES
CREATE POLICY "Public profiles are viewable by everyone" 
    ON profiles FOR SELECT USING (true);

CREATE POLICY "Users can update own profile" 
    ON profiles FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile" 
    ON profiles FOR INSERT WITH CHECK (auth.uid() = id);

-- TRACKS POLICIES (Public read, Admin-only write)
CREATE POLICY "Tracks are publicly viewable" 
    ON tracks FOR SELECT USING (is_public = true);

CREATE POLICY "Only admins can insert tracks" 
    ON tracks FOR INSERT WITH CHECK (
        EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND is_admin = true)
    );

CREATE POLICY "Only admins can update tracks" 
    ON tracks FOR UPDATE USING (
        EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND is_admin = true)
    );

CREATE POLICY "Only admins can delete tracks" 
    ON tracks FOR DELETE USING (
        EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND is_admin = true)
    );

-- PLAYLISTS POLICIES
CREATE POLICY "Public playlists are viewable" 
    ON playlists FOR SELECT USING (is_public = true OR owner_id = auth.uid());

CREATE POLICY "Users can manage own playlists" 
    ON playlists FOR ALL USING (owner_id = auth.uid());

-- PLAYLIST TRACKS POLICIES
CREATE POLICY "Users can view playlist tracks" 
    ON playlist_tracks FOR SELECT USING (
        EXISTS (SELECT 1 FROM playlists WHERE id = playlist_tracks.playlist_id 
                AND (is_public = true OR owner_id = auth.uid()))
    );

CREATE POLICY "Users can modify own playlist tracks" 
    ON playlist_tracks FOR ALL USING (
        EXISTS (SELECT 1 FROM playlists WHERE id = playlist_tracks.playlist_id 
                AND owner_id = auth.uid())
    );

-- PLAY HISTORY POLICIES
CREATE POLICY "Users can view own play history" 
    ON play_history FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can insert own play history" 
    ON play_history FOR INSERT WITH CHECK (user_id = auth.uid());

-- USER LIKES POLICIES
CREATE POLICY "Users can view own likes" 
    ON user_likes FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can manage own likes" 
    ON user_likes FOR ALL USING (user_id = auth.uid());

-- CHAT POLICIES
CREATE POLICY "Users can view own messages" 
    ON chat_messages FOR SELECT USING (sender_id = auth.uid() OR receiver_id = auth.uid());

CREATE POLICY "Users can send messages" 
    ON chat_messages FOR INSERT WITH CHECK (sender_id = auth.uid());

CREATE POLICY "Users can update read status" 
    ON chat_messages FOR UPDATE USING (receiver_id = auth.uid());

-- REWARDS POLICIES
CREATE POLICY "Users can view own rewards" 
    ON user_rewards FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can insert own rewards" 
    ON user_rewards FOR INSERT WITH CHECK (user_id = auth.uid());

-- ============================================
-- FUNCTIONS & TRIGGERS
-- ============================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers for updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_tracks_updated_at BEFORE UPDATE ON tracks
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_playlists_updated_at BEFORE UPDATE ON playlists
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to handle new user signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO profiles (id, email, username, is_admin)
    VALUES (
        NEW.id, 
        NEW.email, 
        SPLIT_PART(NEW.email, '@', 1),
        -- Set first user as admin
        NOT EXISTS (SELECT 1 FROM profiles)
    );
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Trigger for new user
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Function to calculate level from XP
CREATE OR REPLACE FUNCTION calculate_level(user_xp INTEGER)
RETURNS INTEGER AS $$
BEGIN
    -- Level formula: level = floor(sqrt(xp / 100)) + 1
    RETURN FLOOR(SQRT(user_xp::FLOAT / 100)) + 1;
END;
$$ language 'plpgsql';

-- Function to update user XP and level
CREATE OR REPLACE FUNCTION add_user_xp(user_uuid UUID, xp_amount INTEGER)
RETURNS VOID AS $$
BEGIN
    UPDATE profiles 
    SET xp = xp + xp_amount,
        level = calculate_level(xp + xp_amount),
        updated_at = NOW()
    WHERE id = user_uuid;
END;
$$ language 'plpgsql';

-- Function to increment track play count
CREATE OR REPLACE FUNCTION increment_play_count(track_uuid UUID)
RETURNS VOID AS $$
BEGIN
    UPDATE tracks 
    SET play_count = play_count + 1 
    WHERE id = track_uuid;
END;
$$ language 'plpgsql';

-- ============================================
-- SEED DATA
-- ============================================

-- Insert default spin wheel rewards
INSERT INTO spin_wheel_rewards (name, reward_type, value, probability_weight) VALUES
('Малий приз монет', 'coins', 10, 30),
('Середній приз монет', 'coins', 25, 20),
('Великий приз монет', 'coins', 50, 10),
('Малий приз XP', 'xp', 50, 25),
('Середній приз XP', 'xp', 100, 10),
('Джекпот монет', 'coins', 100, 4),
('Мега XP', 'xp', 500, 1);

-- Insert default achievements
INSERT INTO achievements (name, description, requirement_type, requirement_value, points_reward, coins_reward) VALUES
('Початківець', 'Прослухайте свій перший трек', 'tracks_played', 1, 10, 5),
('Меломан', 'Прослухайте 100 треків', 'tracks_played', 100, 100, 50),
('Музичний експерт', 'Прослухайте 1000 треків', 'tracks_played', 1000, 500, 250),
('Новачок', 'Досягніть 2 рівня', 'level_reached', 2, 50, 25),
('Профі', 'Досягніть 10 рівня', 'level_reached', 10, 200, 100),
('Легенда', 'Досягніть 50 рівня', 'level_reached', 50, 1000, 500),
('Слухач', 'Прослухайте музику 1 годину', 'listening_time', 3600, 20, 10),
('Завзятий слухач', 'Прослухайте музику 24 години', 'listening_time', 86400, 200, 100),
('Марафонець', 'Прослухайте музику 168 годин', 'listening_time', 604800, 1000, 500);

-- Insert sample radio stations
INSERT INTO radio_stations (name, description, stream_url, genre, country, language) VALUES
('Radio ROKS', 'Українське рок-радіо', 'https://online.radioroks.ua/RadioROKS', 'Rock', 'Ukraine', 'uk'),
('Kiss FM', 'Танцювальна музика', 'https://online.kissfm.ua/KissFM', 'Dance', 'Ukraine', 'uk'),
('Radio Jazz', 'Джаз 24/7', 'https://jazzradio.radioca.st/stream', 'Jazz', 'International', 'en'),
('Classical Radio', 'Класична музика', 'https://classicalradio.ice.infomaniak.ch/classicalradio.mp3', 'Classical', 'International', 'en');

-- ============================================
-- STORAGE BUCKET SETUP
-- ============================================

-- Create storage bucket for tracks (run in Storage section or use Supabase Dashboard)
-- Note: This should be done via Supabase Dashboard or Storage API
-- Bucket name: "tracks"
-- Public: true (for streaming)
-- Allowed mime types: audio/mpeg, audio/mp3, audio/wav, audio/flac, audio/aac

-- Create storage bucket for covers
-- Bucket name: "covers"
-- Public: true
-- Allowed mime types: image/jpeg, image/png, image/webp

-- ============================================
-- REALTIME SUBSCRIPTIONS
-- ============================================

-- Enable realtime for chat messages
ALTER PUBLICATION supabase_realtime ADD TABLE chat_messages;

-- Enable realtime for tracks (for admin updates)
ALTER PUBLICATION supabase_realtime ADD TABLE tracks;

-- Enable realtime for user rewards
ALTER PUBLICATION supabase_realtime ADD TABLE user_rewards;
