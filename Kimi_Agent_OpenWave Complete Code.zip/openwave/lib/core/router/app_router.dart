import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../features/auth/presentation/screens/login_screen.dart';
import '../../features/auth/presentation/screens/register_screen.dart';
import '../../features/home/presentation/screens/main_screen.dart';
import '../../features/player/presentation/screens/player_screen.dart';
import '../../features/admin/presentation/screens/admin_screen.dart';
import '../../features/gamification/presentation/screens/spin_wheel_screen.dart';
import '../../features/gamification/presentation/screens/daily_reward_screen.dart';
import '../../features/gamification/presentation/screens/achievements_screen.dart';
import '../../features/chat/presentation/screens/chat_screen.dart';
import '../../features/radio/presentation/screens/radio_screen.dart';
import '../../features/analytics/presentation/screens/analytics_screen.dart';
import '../../features/settings/presentation/screens/settings_screen.dart';
import '../../features/profile/presentation/screens/profile_screen.dart';
import '../models/track_model.dart';

class AppRouter {
  static final _rootNavigatorKey = GlobalKey<NavigatorState>();
  static final _shellNavigatorKey = GlobalKey<NavigatorState>();
  
  static GoRouter get router => GoRouter(
    navigatorKey: _rootNavigatorKey,
    initialLocation: '/',
    redirect: (context, state) {
      final session = Supabase.instance.client.auth.currentSession;
      final isAuthRoute = state.matchedLocation == '/login' || 
                          state.matchedLocation == '/register';
      
      if (session == null && !isAuthRoute) {
        return '/login';
      }
      
      if (session != null && isAuthRoute) {
        return '/';
      }
      
      return null;
    },
    routes: [
      // Auth routes
      GoRoute(
        path: '/login',
        builder: (context, state) => const LoginScreen(),
      ),
      GoRoute(
        path: '/register',
        builder: (context, state) => const RegisterScreen(),
      ),
      
      // Main shell route with bottom navigation
      ShellRoute(
        navigatorKey: _shellNavigatorKey,
        builder: (context, state, child) => MainScreen(child: child),
        routes: [
          GoRoute(
            path: '/',
            builder: (context, state) => const HomeTab(),
          ),
          GoRoute(
            path: '/search',
            builder: (context, state) => const SearchTab(),
          ),
          GoRoute(
            path: '/library',
            builder: (context, state) => const LibraryTab(),
          ),
          GoRoute(
            path: '/profile',
            builder: (context, state) => const ProfileTab(),
          ),
        ],
      ),
      
      // Feature routes
      GoRoute(
        path: '/player',
        builder: (context, state) {
          final track = state.extra as TrackModel?;
          return PlayerScreen(track: track);
        },
      ),
      GoRoute(
        path: '/admin',
        builder: (context, state) => const AdminScreen(),
      ),
      GoRoute(
        path: '/spin-wheel',
        builder: (context, state) => const SpinWheelScreen(),
      ),
      GoRoute(
        path: '/daily-reward',
        builder: (context, state) => const DailyRewardScreen(),
      ),
      GoRoute(
        path: '/achievements',
        builder: (context, state) => const AchievementsScreen(),
      ),
      GoRoute(
        path: '/chat',
        builder: (context, state) => const ChatScreen(),
      ),
      GoRoute(
        path: '/radio',
        builder: (context, state) => const RadioScreen(),
      ),
      GoRoute(
        path: '/analytics',
        builder: (context, state) => const AnalyticsScreen(),
      ),
      GoRoute(
        path: '/settings',
        builder: (context, state) => const SettingsScreen(),
      ),
      GoRoute(
        path: '/edit-profile',
        builder: (context, state) => const EditProfileScreen(),
      ),
    ],
  );
}

// Placeholder tabs - will be replaced with actual implementations
class HomeTab extends StatelessWidget {
  const HomeTab({super.key});
  
  @override
  Widget build(BuildContext context) => const Scaffold(body: Center(child: Text('Home')));
}

class SearchTab extends StatelessWidget {
  const SearchTab({super.key});
  
  @override
  Widget build(BuildContext context) => const Scaffold(body: Center(child: Text('Search')));
}

class LibraryTab extends StatelessWidget {
  const LibraryTab({super.key});
  
  @override
  Widget build(BuildContext context) => const Scaffold(body: Center(child: Text('Library')));
}

class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});
  
  @override
  Widget build(BuildContext context) => const Scaffold(body: Center(child: Text('Profile')));
}

class EditProfileScreen extends StatelessWidget {
  const EditProfileScreen({super.key});
  
  @override
  Widget build(BuildContext context) => const Scaffold(body: Center(child: Text('Edit Profile')));
}
