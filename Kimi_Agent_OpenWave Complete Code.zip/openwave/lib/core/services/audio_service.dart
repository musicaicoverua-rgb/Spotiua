import 'dart:async';
import 'package:injectable/injectable.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:rxdart/rxdart.dart';

import '../models/track_model.dart';

@lazySingleton
class AudioPlayerService {
  final AudioPlayer _player = AudioPlayer();
  final List<TrackModel> _queue = [];
  int _currentIndex = -1;
  
  // Streams
  final _currentTrackController = BehaviorSubject<TrackModel?>.seeded(null);
  final _playbackStateController = BehaviorSubject<PlaybackState>.seeded(PlaybackState.stopped);
  final _positionController = BehaviorSubject<Duration>.seeded(Duration.zero);
  final _durationController = BehaviorSubject<Duration?>.seeded(null);
  final _queueController = BehaviorSubject<List<TrackModel>>.seeded([]);
  
  Stream<TrackModel?> get currentTrackStream => _currentTrackController.stream;
  Stream<PlaybackState> get playbackStateStream => _playbackStateController.stream;
  Stream<Duration> get positionStream => _positionController.stream;
  Stream<Duration?> get durationStream => _durationController.stream;
  Stream<List<TrackModel>> get queueStream => _queueController.stream;
  
  TrackModel? get currentTrack => _currentTrackController.value;
  PlaybackState get playbackState => _playbackStateController.value;
  Duration get position => _positionController.value;
  Duration? get duration => _durationController.value;
  List<TrackModel> get queue => List.unmodifiable(_queue);
  bool get hasNext => _currentIndex < _queue.length - 1;
  bool get hasPrevious => _currentIndex > 0;
  
  Future<void> init() async {
    // Listen to player state changes
    _player.playerStateStream.listen((state) {
      if (state.playing) {
        _playbackStateController.add(PlaybackState.playing);
      } else {
        switch (state.processingState) {
          case ProcessingState.loading:
          case ProcessingState.buffering:
            _playbackStateController.add(PlaybackState.buffering);
            break;
          case ProcessingState.ready:
            _playbackStateController.add(PlaybackState.paused);
            break;
          case ProcessingState.completed:
            _playbackStateController.add(PlaybackState.completed);
            _onTrackComplete();
            break;
          case ProcessingState.idle:
            _playbackStateController.add(PlaybackState.stopped);
            break;
        }
      }
    });
    
    // Listen to position changes
    _player.positionStream.listen((position) {
      _positionController.add(position);
    });
    
    // Listen to duration changes
    _player.durationStream.listen((duration) {
      _durationController.add(duration);
    });
  }
  
  Future<void> playTrack(TrackModel track, {List<TrackModel>? queue}) async {
    try {
      if (queue != null) {
        _queue.clear();
        _queue.addAll(queue);
        _currentIndex = _queue.indexWhere((t) => t.id == track.id);
        if (_currentIndex == -1) {
          _queue.insert(0, track);
          _currentIndex = 0;
        }
      } else {
        if (!_queue.contains(track)) {
          _queue.insert(0, track);
        }
        _currentIndex = _queue.indexOf(track);
      }
      
      _queueController.add(List.unmodifiable(_queue));
      await _loadAndPlay(track);
    } catch (e) {
      print('Error playing track: $e');
    }
  }
  
  Future<void> _loadAndPlay(TrackModel track) async {
    try {
      _currentTrackController.add(track);
      
      final audioSource = AudioSource.uri(
        Uri.parse(track.streamUrl),
        tag: MediaItem(
          id: track.id,
          title: track.title,
          artist: track.artist,
          album: track.album,
          duration: track.duration != null 
              ? Duration(seconds: track.duration!) 
              : null,
          artUri: track.coverUrl != null ? Uri.parse(track.coverUrl!) : null,
        ),
      );
      
      await _player.setAudioSource(audioSource);
      await _player.play();
    } catch (e) {
      print('Error loading track: $e');
      _playbackStateController.add(PlaybackState.error);
    }
  }
  
  Future<void> play() async {
    await _player.play();
  }
  
  Future<void> pause() async {
    await _player.pause();
  }
  
  Future<void> togglePlayPause() async {
    if (_player.playing) {
      await pause();
    } else {
      await play();
    }
  }
  
  Future<void> seek(Duration position) async {
    await _player.seek(position);
  }
  
  Future<void> skipToNext() async {
    if (hasNext) {
      _currentIndex++;
      await _loadAndPlay(_queue[_currentIndex]);
    }
  }
  
  Future<void> skipToPrevious() async {
    if (hasPrevious) {
      _currentIndex--;
      await _loadAndPlay(_queue[_currentIndex]);
    }
  }
  
  Future<void> setShuffleMode(bool enabled) async {
    // Implement shuffle logic
  }
  
  Future<void> setRepeatMode(RepeatMode mode) async {
    switch (mode) {
      case RepeatMode.off:
        await _player.setLoopMode(LoopMode.off);
        break;
      case RepeatMode.one:
        await _player.setLoopMode(LoopMode.one);
        break;
      case RepeatMode.all:
        await _player.setLoopMode(LoopMode.all);
        break;
    }
  }
  
  void _onTrackComplete() {
    if (hasNext) {
      skipToNext();
    }
  }
  
  Future<void> addToQueue(TrackModel track) async {
    _queue.add(track);
    _queueController.add(List.unmodifiable(_queue));
  }
  
  Future<void> removeFromQueue(int index) async {
    if (index >= 0 && index < _queue.length) {
      _queue.removeAt(index);
      if (index < _currentIndex) {
        _currentIndex--;
      }
      _queueController.add(List.unmodifiable(_queue));
    }
  }
  
  Future<void> clearQueue() async {
    _queue.clear();
    _currentIndex = -1;
    _queueController.add([]);
    _currentTrackController.add(null);
    await _player.stop();
  }
  
  Future<void> dispose() async {
    await _player.dispose();
    _currentTrackController.close();
    _playbackStateController.close();
    _positionController.close();
    _durationController.close();
    _queueController.close();
  }
}

enum PlaybackState {
  stopped,
  playing,
  paused,
  buffering,
  completed,
  error,
}

enum RepeatMode {
  off,
  one,
  all,
}
