import 'dart:async';
import 'dart:io';
import 'package:injectable/injectable.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/track_model.dart';
import '../models/user_model.dart';
import '../models/playlist_model.dart';
import '../models/chat_message_model.dart';
import '../models/radio_station_model.dart';
import '../models/reward_model.dart';

@lazySingleton
class SupabaseService {
  final SupabaseClient _client = Supabase.instance.client;
  
  // Auth
  User? get currentUser => _client.auth.currentUser;
  Session? get currentSession => _client.auth.currentSession;
  Stream<AuthState> get authStateChanges => _client.auth.onAuthStateChange;
  
  // Realtime subscriptions
  final Map<String, StreamSubscription> _subscriptions = {};
  
  // Auth Methods
  Future<AuthResponse> signInWithEmail(String email, String password) async {
    return await _client.auth.signInWithPassword(
      email: email,
      password: password,
    );
  }
  
  Future<AuthResponse> signUpWithEmail(String email, String password, {String? username}) async {
    return await _client.auth.signUp(
      email: email,
      password: password,
      data: {'username': username},
    );
  }
  
  Future<void> signOut() async {
    await _client.auth.signOut();
  }
  
  Future<void> resetPassword(String email) async {
    await _client.auth.resetPasswordForEmail(email);
  }
  
  // User Methods
  Future<UserModel?> getCurrentUserProfile() async {
    if (currentUser == null) return null;
    
    final response = await _client
        .from('profiles')
        .select()
        .eq('id', currentUser!.id)
        .single();
    
    return UserModel.fromJson(response);
  }
  
  Future<UserModel?> getUserProfile(String userId) async {
    final response = await _client
        .from('profiles')
        .select()
        .eq('id', userId)
        .single();
    
    return UserModel.fromJson(response);
  }
  
  Future<void> updateUserProfile(Map<String, dynamic> data) async {
    if (currentUser == null) return;
    
    await _client
        .from('profiles')
        .update(data)
        .eq('id', currentUser!.id);
  }
  
  Future<bool> isAdmin() async {
    final profile = await getCurrentUserProfile();
    return profile?.isAdmin ?? false;
  }
  
  // Track Methods
  Future<List<TrackModel>> getTracks({
    int limit = 50,
    int offset = 0,
    String? genre,
    String? searchQuery,
  }) async {
    var query = _client
        .from('tracks')
        .select()
        .eq('is_public', true)
        .order('created_at', ascending: false)
        .range(offset, offset + limit - 1);
    
    if (genre != null) {
      query = query.eq('genre', genre);
    }
    
    if (searchQuery != null && searchQuery.isNotEmpty) {
      query = query.or('title.ilike.%$searchQuery%,artist.ilike.%$searchQuery%');
    }
    
    final response = await query;
    return (response as List).map((json) => TrackModel.fromJson(json)).toList();
  }
  
  Future<TrackModel?> getTrack(String trackId) async {
    final response = await _client
        .from('tracks')
        .select()
        .eq('id', trackId)
        .single();
    
    return TrackModel.fromJson(response);
  }
  
  Future<List<TrackModel>> getPopularTracks({int limit = 20}) async {
    final response = await _client
        .from('tracks')
        .select()
        .eq('is_public', true)
        .order('play_count', ascending: false)
        .limit(limit);
    
    return (response as List).map((json) => TrackModel.fromJson(json)).toList();
  }
  
  Future<List<TrackModel>> getNewReleases({int limit = 20}) async {
    final response = await _client
        .from('tracks')
        .select()
        .eq('is_public', true)
        .order('created_at', ascending: false)
        .limit(limit);
    
    return (response as List).map((json) => TrackModel.fromJson(json)).toList();
  }
  
  // Admin: Upload Track
  Future<TrackModel> uploadTrack({
    required File file,
    required String title,
    required String artist,
    String? album,
    String? genre,
    int? duration,
    File? coverFile,
  }) async {
    final userId = currentUser!.id;
    final trackId = DateTime.now().millisecondsSinceEpoch.toString();
    
    // Upload audio file
    final fileExt = file.path.split('.').last;
    final filePath = 'tracks/$userId/$trackId.$fileExt';
    
    await _client.storage
        .from('tracks')
        .upload(filePath, file);
    
    // Get public URL
    final fileUrl = _client.storage
        .from('tracks')
        .getPublicUrl(filePath);
    
    // Upload cover if provided
    String? coverUrl;
    if (coverFile != null) {
      final coverExt = coverFile.path.split('.').last;
      final coverPath = 'covers/$trackId.$coverExt';
      
      await _client.storage
          .from('covers')
          .upload(coverPath, coverFile);
      
      coverUrl = _client.storage
          .from('covers')
          .getPublicUrl(coverPath);
    }
    
    // Insert track metadata
    final response = await _client
        .from('tracks')
        .insert({
          'title': title,
          'artist': artist,
          'album': album,
          'genre': genre,
          'duration': duration,
          'file_path': fileUrl,
          'file_size': await file.length(),
          'cover_url': coverUrl,
          'uploaded_by': userId,
        })
        .select()
        .single();
    
    return TrackModel.fromJson(response);
  }
  
  // Admin: Delete Track
  Future<void> deleteTrack(String trackId) async {
    await _client
        .from('tracks')
        .delete()
        .eq('id', trackId);
  }
  
  // Play History
  Future<void> logPlayHistory({
    required String trackId,
    required int durationPlayed,
    bool completed = false,
    String? source,
  }) async {
    if (currentUser == null) return;
    
    await _client.from('play_history').insert({
      'user_id': currentUser!.id,
      'track_id': trackId,
      'duration_played': durationPlayed,
      'completed': completed,
      'source': source,
    });
    
    // Increment track play count
    await _client.rpc('increment_play_count', params: {'track_uuid': trackId});
  }
  
  // Playlist Methods
  Future<List<PlaylistModel>> getUserPlaylists() async {
    if (currentUser == null) return [];
    
    final response = await _client
        .from('playlists')
        .select('*, playlist_tracks(*)')
        .eq('owner_id', currentUser!.id)
        .order('created_at', ascending: false);
    
    return (response as List).map((json) => PlaylistModel.fromJson(json)).toList();
  }
  
  Future<PlaylistModel> createPlaylist({
    required String name,
    String? description,
    bool isPublic = false,
  }) async {
    if (currentUser == null) throw Exception('Not authenticated');
    
    final response = await _client
        .from('playlists')
        .insert({
          'name': name,
          'description': description,
          'owner_id': currentUser!.id,
          'is_public': isPublic,
        })
        .select()
        .single();
    
    return PlaylistModel.fromJson(response);
  }
  
  Future<void> addTrackToPlaylist(String playlistId, String trackId) async {
    // Get current max position
    final response = await _client
        .from('playlist_tracks')
        .select('position')
        .eq('playlist_id', playlistId)
        .order('position', ascending: false)
        .limit(1)
        .maybeSingle();
    
    final position = response != null ? (response['position'] as int) + 1 : 0;
    
    await _client.from('playlist_tracks').insert({
      'playlist_id': playlistId,
      'track_id': trackId,
      'position': position,
    });
  }
  
  // Chat Methods
  Future<List<ChatMessageModel>> getChatMessages({
    required String otherUserId,
    int limit = 50,
  }) async {
    if (currentUser == null) return [];
    
    final response = await _client
        .from('chat_messages')
        .select()
        .or('and(sender_id.eq.${currentUser!.id},receiver_id.eq.$otherUserId),and(sender_id.eq.$otherUserId,receiver_id.eq.${currentUser!.id})')
        .order('created_at', ascending: false)
        .limit(limit);
    
    return (response as List).map((json) => ChatMessageModel.fromJson(json)).toList();
  }
  
  Future<void> sendMessage({
    required String receiverId,
    required String message,
  }) async {
    if (currentUser == null) return;
    
    await _client.from('chat_messages').insert({
      'sender_id': currentUser!.id,
      'receiver_id': receiverId,
      'message': message,
    });
  }
  
  Stream<List<Map<String, dynamic>>> subscribeToChat(String otherUserId) {
    return _client
        .from('chat_messages')
        .stream(primaryKey: ['id'])
        .or('and(sender_id.eq.${currentUser?.id},receiver_id.eq.$otherUserId),and(sender_id.eq.$otherUserId,receiver_id.eq.${currentUser?.id})')
        .order('created_at');
  }
  
  // Radio Stations
  Future<List<RadioStationModel>> getRadioStations() async {
    final response = await _client
        .from('radio_stations')
        .select()
        .eq('is_active', true)
        .order('name');
    
    return (response as List).map((json) => RadioStationModel.fromJson(json)).toList();
  }
  
  // Gamification - Rewards
  Future<List<SpinWheelRewardModel>> getSpinWheelRewards() async {
    final response = await _client
        .from('spin_wheel_rewards')
        .select()
        .eq('is_active', true);
    
    return (response as List).map((json) => SpinWheelRewardModel.fromJson(json)).toList();
  }
  
  Future<void> claimDailyReward() async {
    if (currentUser == null) return;
    
    await _client.rpc('add_user_xp', params: {
      'user_uuid': currentUser!.id,
      'xp_amount': 50,
    });
    
    await _client.from('user_rewards').insert({
      'user_id': currentUser!.id,
      'reward_type': 'daily',
      'points_earned': 10,
      'coins_earned': 5,
      'xp_earned': 50,
    });
    
    await _client.from('profiles').update({
      'last_daily_reward': DateTime.now().toIso8601String(),
      'points': currentUser!.userMetadata?['points'] ?? 0 + 10,
      'coins': currentUser!.userMetadata?['coins'] ?? 0 + 5,
    }).eq('id', currentUser!.id);
  }
  
  Future<void> claimSpinReward(SpinWheelRewardModel reward) async {
    if (currentUser == null) return;
    
    int points = 0;
    int coins = 0;
    int xp = 0;
    
    switch (reward.rewardType) {
      case 'coins':
        coins = reward.value;
        break;
      case 'points':
        points = reward.value;
        break;
      case 'xp':
        xp = reward.value;
        break;
    }
    
    await _client.from('user_rewards').insert({
      'user_id': currentUser!.id,
      'reward_type': 'spin',
      'points_earned': points,
      'coins_earned': coins,
      'xp_earned': xp,
    });
    
    await _client.rpc('add_user_xp', params: {
      'user_uuid': currentUser!.id,
      'xp_amount': xp,
    });
  }
  
  // Achievements
  Future<List<AchievementModel>> getAchievements() async {
    final response = await _client
        .from('achievements')
        .select();
    
    return (response as List).map((json) => AchievementModel.fromJson(json)).toList();
  }
  
  // AI Recommendations (based on play history)
  Future<List<TrackModel>> getRecommendedTracks({int limit = 20}) async {
    if (currentUser == null) {
      return getPopularTracks(limit: limit);
    }
    
    // Get user's most played genres
    final genreResponse = await _client
        .from('play_history')
        .select('tracks(genre)')
        .eq('user_id', currentUser!.id)
        .limit(100);
    
    final genres = <String, int>{};
    for (final item in genreResponse) {
      final genre = item['tracks']?['genre'];
      if (genre != null) {
        genres[genre] = (genres[genre] ?? 0) + 1;
      }
    }
    
    final topGenres = genres.entries
        .toList()
        ..sort((a, b) => b.value.compareTo(a.value));
    
    if (topGenres.isEmpty) {
      return getPopularTracks(limit: limit);
    }
    
    // Get tracks from top genres
    final response = await _client
        .from('tracks')
        .select()
        .eq('is_public', true)
        .inFilter('genre', topGenres.take(3).map((e) => e.key).toList())
        .limit(limit);
    
    return (response as List).map((json) => TrackModel.fromJson(json)).toList();
  }
  
  // Dispose
  void dispose() {
    for (final sub in _subscriptions.values) {
      sub.cancel();
    }
    _subscriptions.clear();
  }
}
