import 'package:freezed_annotation/freezed_annotation.dart';

part 'radio_station_model.freezed.dart';
part 'radio_station_model.g.dart';

@freezed
class RadioStationModel with _$RadioStationModel {
  const factory RadioStationModel({
    required String id,
    required String name,
    String? description,
    required String streamUrl,
    String? coverUrl,
    String? genre,
    String? country,
    String? language,
    @Default(true) bool isActive,
    DateTime? createdAt,
    // Local fields
    @Default(false) bool isPlaying,
    @Default(false) bool isBuffering,
  }) = _RadioStationModel;

  factory RadioStationModel.fromJson(Map<String, dynamic> json) =>
      _$RadioStationModelFromJson(json);
      
  const RadioStationModel._();
  
  String get displayGenre => genre ?? 'Various';
  
  String get displayCountry => country ?? 'International';
  
  String get displayDescription => description ?? 'Internet Radio Station';
}
