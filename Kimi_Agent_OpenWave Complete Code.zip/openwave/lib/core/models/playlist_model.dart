import 'package:freezed_annotation/freezed_annotation.dart';

import 'track_model.dart';

part 'playlist_model.freezed.dart';
part 'playlist_model.g.dart';

@freezed
class PlaylistModel with _$PlaylistModel {
  const factory PlaylistModel({
    required String id,
    required String name,
    String? description,
    String? coverUrl,
    required String ownerId,
    @Default(false) bool isPublic,
    DateTime? createdAt,
    DateTime? updatedAt,
    @Default([]) List<TrackModel> tracks,
  }) = _PlaylistModel;

  factory PlaylistModel.fromJson(Map<String, dynamic> json) =>
      _$PlaylistModelFromJson(json);
      
  const PlaylistModel._();
  
  int get trackCount => tracks.length;
  
  int get totalDuration {
    return tracks.fold(0, (sum, track) => sum + (track.duration ?? 0));
  }
  
  String get formattedDuration {
    final hours = totalDuration ~/ 3600;
    final minutes = (totalDuration % 3600) ~/ 60;
    
    if (hours > 0) {
      return '${hours}h ${minutes}m';
    }
    return '${minutes}m';
  }
  
  String get displayDescription => description ?? 'No description';
}
