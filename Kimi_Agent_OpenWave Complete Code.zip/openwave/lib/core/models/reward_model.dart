import 'package:freezed_annotation/freezed_annotation.dart';

part 'reward_model.freezed.dart';
part 'reward_model.g.dart';

@freezed
class RewardModel with _$RewardModel {
  const factory RewardModel({
    required String id,
    required String rewardType,
    required String name,
    String? description,
    @Default(0) int points,
    @Default(0) int coins,
    @Default(0) int xp,
    int? minReward,
    int? maxReward,
    @Default(24) int cooldownHours,
    @Default(true) bool isActive,
    DateTime? createdAt,
  }) = _RewardModel;

  factory RewardModel.fromJson(Map<String, dynamic> json) =>
      _$RewardModelFromJson(json);
}

@freezed
class UserRewardModel with _$UserRewardModel {
  const factory UserRewardModel({
    required String id,
    required String userId,
    required String rewardType,
    @Default(0) int pointsEarned,
    @Default(0) int coinsEarned,
    @Default(0) int xpEarned,
    DateTime? claimedAt,
  }) = _UserRewardModel;

  factory UserRewardModel.fromJson(Map<String, dynamic> json) =>
      _$UserRewardModelFromJson(json);
}

@freezed
class SpinWheelRewardModel with _$SpinWheelRewardModel {
  const factory SpinWheelRewardModel({
    required String id,
    required String name,
    required String rewardType,
    required int value,
    @Default(1) int probabilityWeight,
    @Default(true) bool isActive,
    DateTime? createdAt,
  }) = _SpinWheelRewardModel;

  factory SpinWheelRewardModel.fromJson(Map<String, dynamic> json) =>
      _$SpinWheelRewardModelFromJson(json);
      
  const SpinWheelRewardModel._();
  
  String get displayValue {
    switch (rewardType) {
      case 'coins':
        return '$value Coins';
      case 'points':
        return '$value Points';
      case 'xp':
        return '$value XP';
      default:
        return '$value';
    }
  }
}

@freezed
class AchievementModel with _$AchievementModel {
  const factory AchievementModel({
    required String id,
    required String name,
    String? description,
    String? iconUrl,
    required String requirementType,
    required int requirementValue,
    @Default(0) int pointsReward,
    @Default(0) int coinsReward,
    DateTime? createdAt,
    // User-specific fields
    @Default(false) bool isUnlocked,
    DateTime? unlockedAt,
    @Default(0) int currentProgress,
  }) = _AchievementModel;

  factory AchievementModel.fromJson(Map<String, dynamic> json) =>
      _$AchievementModelFromJson(json);
      
  const AchievementModel._();
  
  double get progressPercent {
    return (currentProgress / requirementValue).clamp(0.0, 1.0);
  }
  
  bool get isCompleted => currentProgress >= requirementValue;
  
  String get progressText => '$currentProgress / $requirementValue';
}
