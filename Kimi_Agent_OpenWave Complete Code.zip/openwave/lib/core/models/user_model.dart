import 'package:freezed_annotation/freezed_annotation.dart';

part 'user_model.freezed.dart';
part 'user_model.g.dart';

@freezed
class UserModel with _$UserModel {
  const factory UserModel({
    required String id,
    required String email,
    String? username,
    String? displayName,
    String? avatarUrl,
    @Default(false) bool isAdmin,
    
    // Gamification
    @Default(0) int points,
    @Default(0) int coins,
    @Default(0) int xp,
    @Default(1) int level,
    @Default(0) int totalListeningTime,
    
    // Daily rewards
    DateTime? lastDailyReward,
    @Default(0) int dailyStreak,
    
    // Preferences
    @Default('uk') String preferredLanguage,
    @Default(false) bool isPremium,
    
    DateTime? createdAt,
    DateTime? updatedAt,
  }) = _UserModel;

  factory UserModel.fromJson(Map<String, dynamic> json) =>
      _$UserModelFromJson(json);
      
  const UserModel._();
  
  String get displayNameOrUsername => displayName ?? username ?? email.split('@').first;
  
  String get displayUsername => username ?? email.split('@').first;
  
  bool get canClaimDailyReward {
    if (lastDailyReward == null) return true;
    final now = DateTime.now();
    final lastClaim = lastDailyReward!;
    return now.difference(lastClaim).inHours >= 24;
  }
  
  int get hoursUntilNextReward {
    if (lastDailyReward == null) return 0;
    final now = DateTime.now();
    final lastClaim = lastDailyReward!;
    final hoursPassed = now.difference(lastClaim).inHours;
    return hoursPassed >= 24 ? 0 : 24 - hoursPassed;
  }
  
  // XP needed for next level: level * level * 100
  int get xpForNextLevel => level * level * 100;
  
  // XP needed for current level
  int get xpForCurrentLevel => (level - 1) * (level - 1) * 100;
  
  // Progress to next level (0.0 - 1.0)
  double get levelProgress {
    final needed = xpForNextLevel - xpForCurrentLevel;
    final current = xp - xpForCurrentLevel;
    return (current / needed).clamp(0.0, 1.0);
  }
  
  String get formattedListeningTime {
    final hours = totalListeningTime ~/ 3600;
    final minutes = (totalListeningTime % 3600) ~/ 60;
    
    if (hours > 0) {
      return '${hours}h ${minutes}m';
    }
    return '${minutes}m';
  }
}
