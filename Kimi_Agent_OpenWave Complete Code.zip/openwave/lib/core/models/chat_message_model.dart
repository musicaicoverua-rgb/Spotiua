import 'package:freezed_annotation/freezed_annotation.dart';

part 'chat_message_model.freezed.dart';
part 'chat_message_model.g.dart';

@freezed
class ChatMessageModel with _$ChatMessageModel {
  const factory ChatMessageModel({
    required String id,
    required String senderId,
    required String receiverId,
    required String message,
    @Default(false) bool isRead,
    DateTime? createdAt,
    // Local fields
    String? senderName,
    String? senderAvatar,
    @Default(false) bool isMe,
  }) = _ChatMessageModel;

  factory ChatMessageModel.fromJson(Map<String, dynamic> json) =>
      _$ChatMessageModelFromJson(json);
      
  const ChatMessageModel._();
  
  String get formattedTime {
    if (createdAt == null) return '';
    final now = DateTime.now();
    final messageTime = createdAt!;
    
    if (now.difference(messageTime).inDays == 0) {
      // Today - show time
      return '${messageTime.hour.toString().padLeft(2, '0')}:${messageTime.minute.toString().padLeft(2, '0')}';
    } else if (now.difference(messageTime).inDays == 1) {
      return 'Yesterday';
    } else {
      return '${messageTime.day}/${messageTime.month}/${messageTime.year}';
    }
  }
}
