import 'package:freezed_annotation/freezed_annotation.dart';

part 'track_model.freezed.dart';
part 'track_model.g.dart';

@freezed
class TrackModel with _$TrackModel {
  const factory TrackModel({
    required String id,
    required String title,
    required String artist,
    String? album,
    String? genre,
    int? duration,
    required String filePath,
    int? fileSize,
    int? bitrate,
    String? coverUrl,
    int? releaseYear,
    int? trackNumber,
    @Default(0) int playCount,
    @Default(0) int likesCount,
    String? uploadedBy,
    @Default(true) bool isPublic,
    DateTime? createdAt,
    DateTime? updatedAt,
    // Local fields
    @Default(false) bool isDownloaded,
    String? localPath,
  }) = _TrackModel;

  factory TrackModel.fromJson(Map<String, dynamic> json) =>
      _$TrackModelFromJson(json);
      
  const TrackModel._();
  
  String get displayTitle => title;
  
  String get displayArtist => artist;
  
  String get displayAlbum => album ?? 'Unknown Album';
  
  String get displayGenre => genre ?? 'Unknown Genre';
  
  String get formattedDuration {
    if (duration == null) return '--:--';
    final minutes = duration! ~/ 60;
    final seconds = duration! % 60;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }
  
  String get streamUrl => filePath;
}
