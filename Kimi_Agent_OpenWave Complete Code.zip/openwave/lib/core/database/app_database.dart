import 'dart:io';
import 'package:drift/drift.dart';
import 'package:drift_flutter/drift_flutter.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;

part 'app_database.g.dart';

// ==================== TABLES ====================

class Tracks extends Table {
  TextColumn get id => text()();
  TextColumn get title => text()();
  TextColumn get artist => text()();
  TextColumn get album => text().nullable()();
  TextColumn get genre => text().nullable()();
  IntColumn get duration => integer().nullable()();
  TextColumn get filePath => text()();
  IntColumn get fileSize => integer().nullable()();
  IntColumn get bitrate => integer().nullable()();
  TextColumn get coverUrl => text().nullable()();
  IntColumn get releaseYear => integer().nullable()();
  IntColumn get trackNumber => integer().nullable()();
  IntColumn get playCount => integer().withDefault(const Constant(0))();
  IntColumn get likesCount => integer().withDefault(const Constant(0))();
  TextColumn get uploadedBy => text().nullable()();
  BoolColumn get isPublic => boolean().withDefault(const Constant(true))();
  DateTimeColumn get createdAt => dateTime().nullable()();
  DateTimeColumn get updatedAt => dateTime().nullable()();
  
  // Local fields
  BoolColumn get isDownloaded => boolean().withDefault(const Constant(false))();
  TextColumn get localPath => text().nullable()();
  DateTimeColumn get downloadedAt => dateTime().nullable()();
  
  @override
  Set<Column> get primaryKey => {id};
}

class Playlists extends Table {
  TextColumn get id => text()();
  TextColumn get name => text()();
  TextColumn get description => text().nullable()();
  TextColumn get coverUrl => text().nullable()();
  TextColumn get ownerId => text()();
  BoolColumn get isPublic => boolean().withDefault(const Constant(false))();
  DateTimeColumn get createdAt => dateTime().nullable()();
  DateTimeColumn get updatedAt => dateTime().nullable()();
  
  @override
  Set<Column> get primaryKey => {id};
}

class PlaylistTracks extends Table {
  TextColumn get id => text()();
  TextColumn get playlistId => text().references(Playlists, #id, onDelete: KeyAction.cascade)();
  TextColumn get trackId => text().references(Tracks, #id, onDelete: KeyAction.cascade)();
  IntColumn get position => integer()();
  DateTimeColumn get addedAt => dateTime().withDefault(currentDateAndTime)();
  
  @override
  Set<Column> get primaryKey => {id};
}

class PlayHistory extends Table {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get trackId => text().references(Tracks, #id, onDelete: KeyAction.cascade)();
  DateTimeColumn get playedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get durationPlayed => integer().withDefault(const Constant(0))();
  BoolColumn get completed => boolean().withDefault(const Constant(false))();
  TextColumn get source => text().nullable()();
  
  @override
  Set<Column> get primaryKey => {id};
}

class UserLikes extends Table {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get trackId => text().references(Tracks, #id, onDelete: KeyAction.cascade)();
  DateTimeColumn get likedAt => dateTime().withDefault(currentDateAndTime)();
  
  @override
  Set<Column> get primaryKey => {id};
}

class OfflineCache extends Table {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get trackId => text().references(Tracks, #id, onDelete: KeyAction.cascade)();
  TextColumn get localPath => text()();
  IntColumn get fileSize => integer().nullable()();
  DateTimeColumn get cachedAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get lastAccessed => dateTime().withDefault(currentDateAndTime)();
  
  @override
  Set<Column> get primaryKey => {id};
}

class UserProfile extends Table {
  TextColumn get id => text()();
  TextColumn get email => text()();
  TextColumn get username => text().nullable()();
  TextColumn get displayName => text().nullable()();
  TextColumn get avatarUrl => text().nullable()();
  BoolColumn get isAdmin => boolean().withDefault(const Constant(false))();
  IntColumn get points => integer().withDefault(const Constant(0))();
  IntColumn get coins => integer().withDefault(const Constant(0))();
  IntColumn get xp => integer().withDefault(const Constant(0))();
  IntColumn get level => integer().withDefault(const Constant(1))();
  IntColumn get totalListeningTime => integer().withDefault(const Constant(0))();
  DateTimeColumn get lastDailyReward => dateTime().nullable()();
  IntColumn get dailyStreak => integer().withDefault(const Constant(0))();
  TextColumn get preferredLanguage => text().withDefault(const Constant('uk'))();
  BoolColumn get isPremium => boolean().withDefault(const Constant(false))();
  DateTimeColumn get createdAt => dateTime().nullable()();
  DateTimeColumn get updatedAt => dateTime().nullable()();
  
  @override
  Set<Column> get primaryKey => {id};
}

class RadioStations extends Table {
  TextColumn get id => text()();
  TextColumn get name => text()();
  TextColumn get description => text().nullable()();
  TextColumn get streamUrl => text()();
  TextColumn get coverUrl => text().nullable()();
  TextColumn get genre => text().nullable()();
  TextColumn get country => text().nullable()();
  TextColumn get language => text().nullable()();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  DateTimeColumn get createdAt => dateTime().nullable()();
  
  @override
  Set<Column> get primaryKey => {id};
}

// ==================== DATABASE ====================

@DriftDatabase(tables: [
  Tracks,
  Playlists,
  PlaylistTracks,
  PlayHistory,
  UserLikes,
  OfflineCache,
  UserProfile,
  RadioStations,
])
class AppDatabase extends _$AppDatabase {
  AppDatabase() : super(_openConnection());
  
  AppDatabase.forTesting(DatabaseConnection connection) : super(connection);
  
  @override
  int get schemaVersion => 1;
  
  @override
  MigrationStrategy get migration => MigrationStrategy(
    onCreate: (Migrator m) async {
      await m.createAll();
    },
    onUpgrade: (Migrator m, int from, int to) async {
      // Handle migrations here
    },
  );
  
  // ==================== TRACK METHODS ====================
  
  Future<List<Track>> getAllTracks() => select(tracks).get();
  
  Future<Track?> getTrack(String id) =>
      (select(tracks)..where((t) => t.id.equals(id))).getSingleOrNull();
  
  Future<List<Track>> getDownloadedTracks() =>
      (select(tracks)..where((t) => t.isDownloaded.equals(true))).get();
  
  Future<void> insertTrack(TracksCompanion track) =>
      into(tracks).insertOnConflictUpdate(track);
  
  Future<void> insertTracks(List<TracksCompanion> tracksList) async {
    await batch((batch) {
      batch.insertAllOnConflictUpdate(tracks, tracksList);
    });
  }
  
  Future<void> updateTrackDownloadStatus(String id, bool isDownloaded, String? localPath) {
    return update(tracks).replace(
      TracksCompanion(
        id: Value(id),
        isDownloaded: Value(isDownloaded),
        localPath: Value(localPath),
        downloadedAt: isDownloaded ? Value(DateTime.now()) : const Value.absent(),
      ),
    );
  }
  
  Future<void> deleteTrack(String id) =>
      delete(tracks).delete(TracksCompanion(id: Value(id)));
  
  Future<List<Track>> searchTracks(String query) =>
      (select(tracks)
        ..where((t) => t.title.contains(query) | t.artist.contains(query)))
          .get();
  
  // ==================== PLAYLIST METHODS ====================
  
  Future<List<Playlist>> getAllPlaylists() => select(playlists).get();
  
  Future<Playlist?> getPlaylist(String id) =>
      (select(playlists)..where((p) => p.id.equals(id))).getSingleOrNull();
  
  Future<void> insertPlaylist(PlaylistsCompanion playlist) =>
      into(playlists).insertOnConflictUpdate(playlist);
  
  Future<void> deletePlaylist(String id) =>
      delete(playlists).delete(PlaylistsCompanion(id: Value(id)));
  
  // ==================== PLAYLIST TRACKS METHODS ====================
  
  Future<List<PlaylistTrack>> getPlaylistTracks(String playlistId) =>
      (select(playlistTracks)
        ..where((pt) => pt.playlistId.equals(playlistId))
        ..orderBy([(pt) => OrderingTerm(expression: pt.position)]))
          .get();
  
  Future<void> addTrackToPlaylist(PlaylistTracksCompanion playlistTrack) =>
      into(playlistTracks).insert(playlistTrack);
  
  Future<void> removeTrackFromPlaylist(String playlistId, String trackId) =>
      delete(playlistTracks).delete(
        playlistTracks.playlistId.equals(playlistId) & 
        playlistTracks.trackId.equals(trackId),
      );
  
  // ==================== PLAY HISTORY METHODS ====================
  
  Future<List<PlayHistoryData>> getPlayHistory({int limit = 50}) =>
      (select(playHistory)
        ..orderBy([(ph) => OrderingTerm(expression: ph.playedAt, mode: OrderingMode.desc)])
        ..limit(limit))
          .get();
  
  Future<void> addPlayHistory(PlayHistoryCompanion history) =>
      into(playHistory).insert(history);
  
  Future<void> clearPlayHistory() => delete(playHistory).go();
  
  // ==================== USER LIKES METHODS ====================
  
  Future<List<UserLike>> getUserLikes(String userId) =>
      (select(userLikes)..where((ul) => ul.userId.equals(userId))).get();
  
  Future<bool> isTrackLiked(String userId, String trackId) async {
    final result = await (select(userLikes)
      ..where((ul) => ul.userId.equals(userId) & ul.trackId.equals(trackId)))
        .getSingleOrNull();
    return result != null;
  }
  
  Future<void> likeTrack(UserLikesCompanion like) =>
      into(userLikes).insert(like);
  
  Future<void> unlikeTrack(String userId, String trackId) =>
      delete(userLikes).delete(
        userLikes.userId.equals(userId) & userLikes.trackId.equals(trackId),
      );
  
  // ==================== OFFLINE CACHE METHODS ====================
  
  Future<List<OfflineCacheData>> getOfflineCache(String userId) =>
      (select(offlineCache)..where((oc) => oc.userId.equals(userId))).get();
  
  Future<void> addOfflineCache(OfflineCacheCompanion cache) =>
      into(offlineCache).insertOnConflictUpdate(cache);
  
  Future<void> removeOfflineCache(String trackId) =>
      delete(offlineCache).delete(offlineCache.trackId.equals(trackId));
  
  Future<void> updateLastAccessed(String trackId) =>
      update(offlineCache).write(
        OfflineCacheCompanion(
          trackId: Value(trackId),
          lastAccessed: Value(DateTime.now()),
        ),
      );
  
  Future<int> getTotalCacheSize(String userId) async {
    final result = await customSelect(
      'SELECT SUM(file_size) as total FROM offline_cache WHERE user_id = ?',
      variables: [Variable.withString(userId)],
    ).getSingle();
    return result.read<int?>('total') ?? 0;
  }
  
  // ==================== USER PROFILE METHODS ====================
  
  Future<UserProfileData?> getUserProfile(String id) =>
      (select(userProfile)..where((up) => up.id.equals(id))).getSingleOrNull();
  
  Future<void> insertUserProfile(UserProfileCompanion profile) =>
      into(userProfile).insertOnConflictUpdate(profile);
  
  Future<void> updateUserGamification({
    required String userId,
    int? points,
    int? coins,
    int? xp,
    int? level,
    int? listeningTime,
  }) async {
    final existing = await getUserProfile(userId);
    if (existing == null) return;
    
    await update(userProfile).replace(
      UserProfileCompanion(
        id: Value(userId),
        points: points != null ? Value(existing.points + points) : const Value.absent(),
        coins: coins != null ? Value(existing.coins + coins) : const Value.absent(),
        xp: xp != null ? Value(existing.xp + xp) : const Value.absent(),
        level: level != null ? Value(level) : const Value.absent(),
        totalListeningTime: listeningTime != null 
            ? Value(existing.totalListeningTime + listeningTime) 
            : const Value.absent(),
        updatedAt: Value(DateTime.now()),
      ),
    );
  }
  
  // ==================== RADIO STATIONS METHODS ====================
  
  Future<List<RadioStation>> getAllRadioStations() =>
      (select(radioStations)..where((rs) => rs.isActive.equals(true))).get();
  
  Future<void> insertRadioStations(List<RadioStationsCompanion> stations) async {
    await batch((batch) {
      batch.insertAllOnConflictUpdate(radioStations, stations);
    });
  }
  
  // ==================== ANALYTICS METHODS ====================
  
  Future<Map<String, dynamic>> getListeningStats(String userId) async {
    // Total listening time
    final totalTimeResult = await customSelect(
      'SELECT SUM(duration_played) as total FROM play_history WHERE user_id = ?',
      variables: [Variable.withString(userId)],
    ).getSingle();
    
    // Total tracks played
    final totalTracksResult = await customSelect(
      'SELECT COUNT(DISTINCT track_id) as count FROM play_history WHERE user_id = ?',
      variables: [Variable.withString(userId)],
    ).getSingle();
    
    // Completed tracks
    final completedTracksResult = await customSelect(
      'SELECT COUNT(*) as count FROM play_history WHERE user_id = ? AND completed = 1',
      variables: [Variable.withString(userId)],
    ).getSingle();
    
    return {
      'totalListeningTime': totalTimeResult.read<int?>('total') ?? 0,
      'totalTracksPlayed': totalTracksResult.read<int?>('count') ?? 0,
      'completedTracks': completedTracksResult.read<int?>('count') ?? 0,
    };
  }
  
  Future<List<Map<String, dynamic>>> getTopTracks(String userId, {int limit = 10}) async {
    final result = await customSelect(
      '''
      SELECT t.id, t.title, t.artist, t.cover_url, COUNT(ph.id) as play_count
      FROM play_history ph
      JOIN tracks t ON ph.track_id = t.id
      WHERE ph.user_id = ?
      GROUP BY t.id
      ORDER BY play_count DESC
      LIMIT ?
      ''',
      variables: [Variable.withString(userId), Variable.withInt(limit)],
    ).get();
    
    return result.map((row) => {
      'id': row.read<String>('id'),
      'title': row.read<String>('title'),
      'artist': row.read<String>('artist'),
      'coverUrl': row.read<String?>('cover_url'),
      'playCount': row.read<int>('play_count'),
    }).toList();
  }
  
  // ==================== CLEANUP METHODS ====================
  
  Future<void> clearAllData() async {
    await delete(tracks).go();
    await delete(playlists).go();
    await delete(playlistTracks).go();
    await delete(playHistory).go();
    await delete(userLikes).go();
    await delete(offlineCache).go();
    await delete(userProfile).go();
    await delete(radioStations).go();
  }
  
  Future<void> vacuum() async {
    await customStatement('VACUUM');
  }
}

// ==================== CONNECTION ====================

DatabaseConnection _openConnection() {
  return driftDatabase(
    name: 'openwave_database',
    native: const DriftNativeOptions(
      databaseDirectory: getApplicationSupportDirectory,
    ),
  );
}
