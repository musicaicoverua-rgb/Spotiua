// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// InjectableConfigGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:get_it/get_it.dart' as _i1;
import 'package:injectable/injectable.dart' as _i2;

import '../../features/auth/presentation/bloc/auth_bloc.dart' as _i3;
import '../../features/home/presentation/bloc/home_bloc.dart' as _i4;
import '../../features/player/presentation/bloc/player_bloc.dart' as _i5;
import '../services/audio_service.dart' as _i6;
import '../services/supabase_service.dart' as _i7;

extension GetItInjectableX on _i1.GetIt {
// initializes the registration of main-scope dependencies inside of GetIt
  _i1.GetIt init({
    String? environment,
    _i2.EnvironmentFilter? environmentFilter,
  }) {
    final gh = _i2.GetItHelper(
      this,
      environment,
      environmentFilter,
    );
    gh.lazySingleton<_i6.AudioPlayerService>(() => _i6.AudioPlayerService());
    gh.lazySingleton<_i7.SupabaseService>(() => _i7.SupabaseService());
    gh.factory<_i3.AuthBloc>(() => _i3.AuthBloc(gh<_i7.SupabaseService>()));
    gh.factory<_i4.HomeBloc>(() => _i4.HomeBloc(gh<_i7.SupabaseService>()));
    gh.factory<_i5.PlayerBloc>(() => _i5.PlayerBloc(gh<_i6.AudioPlayerService>()));
    return this;
  }
}
