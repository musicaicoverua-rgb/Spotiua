import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:just_audio_background/just_audio_background.dart';

import 'core/di/injection.dart';
import 'core/theme/app_theme.dart';
import 'core/router/app_router.dart';
import 'core/services/audio_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize localization
  await EasyLocalization.ensureInitialized();
  
  // Set preferred orientations
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  
  // Initialize audio background service
  await JustAudioBackground.init(
    androidNotificationChannelId: 'com.openwave.app.audio',
    androidNotificationChannelName: 'OpenWave Playback',
    androidNotificationOngoing: true,
    androidShowNotificationBadge: true,
  );
  
  // Initialize Supabase
  await Supabase.initialize(
    url: 'https://nmowlkjoragnffkxbrzq.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5tb3dsa2pvcmFnbmZma3hicnpxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzMwOTYyNjcsImV4cCI6MjA4ODY3MjI2N30.yNHTyZfXOjy-lJNxCOm8F9_YVGWF6kGWmueFYBHTfI0',
  );
  
  // Initialize dependency injection
  await configureDependencies();
  
  // Initialize audio service
  await getIt<AudioPlayerService>().init();
  
  runApp(
    EasyLocalization(
      supportedLocales: const [
        Locale('uk'),
        Locale('en'),
        Locale('es'),
        Locale('ru'),
        Locale('de'),
        Locale('fr'),
        Locale('pl'),
        Locale('cs'),
      ],
      path: 'assets/translations',
      fallbackLocale: const Locale('uk'),
      startLocale: const Locale('uk'),
      child: const OpenWaveApp(),
    ),
  );
}

class OpenWaveApp extends StatelessWidget {
  const OpenWaveApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'OpenWave',
      debugShowCheckedModeBanner: false,
      localizationsDelegates: context.localizationDelegates,
      supportedLocales: context.supportedLocales,
      locale: context.locale,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.system,
      routerConfig: AppRouter.router,
    );
  }
}
