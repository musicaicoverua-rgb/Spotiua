import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';

import '../../../../core/theme/app_theme.dart';
import '../../../../core/services/supabase_service.dart';
import '../../../../core/services/audio_service.dart';
import '../../../../core/models/radio_station_model.dart';

class RadioScreen extends StatefulWidget {
  const RadioScreen({super.key});

  @override
  State<RadioScreen> createState() => _RadioScreenState();
}

class _RadioScreenState extends State<RadioScreen> {
  final _supabaseService = SupabaseService();
  final _audioService = AudioPlayerService();
  
  List<RadioStationModel> _stations = [];
  bool _isLoading = true;
  RadioStationModel? _currentlyPlaying;

  @override
  void initState() {
    super.initState();
    _loadStations();
  }
  
  Future<void> _loadStations() async {
    try {
      final stations = await _supabaseService.getRadioStations();
      
      setState(() {
        _stations = stations;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
    }
  }
  
  Future<void> _playStation(RadioStationModel station) async {
    if (_currentlyPlaying?.id == station.id) {
      // Stop playing
      await _audioService.pause();
      setState(() {
        _currentlyPlaying = null;
      });
    } else {
      // Play station
      setState(() {
        _currentlyPlaying = station;
      });
      
      // Create a track model from station for playback
      // In real implementation, you'd handle radio streaming differently
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('radio'.tr()),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _stations.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.radio,
                        size: 64,
                        color: AppTheme.mutedText,
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'No radio stations available',
                        style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                              color: AppTheme.mutedText,
                            ),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _stations.length,
                  itemBuilder: (context, index) {
                    final station = _stations[index];
                    final isPlaying = _currentlyPlaying?.id == station.id;
                    
                    return Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      decoration: BoxDecoration(
                        color: isPlaying
                            ? AppTheme.primaryColor.withOpacity(0.1)
                            : Theme.of(context).cardColor,
                        borderRadius: BorderRadius.circular(16),
                        border: isPlaying
                            ? Border.all(color: AppTheme.primaryColor.withOpacity(0.3))
                            : null,
                      ),
                      child: ListTile(
                        contentPadding: const EdgeInsets.all(12),
                        leading: ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: station.coverUrl != null
                              ? Image.network(
                                  station.coverUrl!,
                                  width: 60,
                                  height: 60,
                                  fit: BoxFit.cover,
                                )
                              : Container(
                                  width: 60,
                                  height: 60,
                                  color: AppTheme.primaryColor,
                                  child: const Icon(
                                    Icons.radio,
                                    color: Colors.white,
                                  ),
                                ),
                        ),
                        title: Row(
                          children: [
                            Expanded(
                              child: Text(
                                station.name,
                                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                      fontWeight: FontWeight.bold,
                                    ),
                              ),
                            ),
                            if (isPlaying)
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: AppTheme.accentColor,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      width: 6,
                                      height: 6,
                                      decoration: const BoxDecoration(
                                        color: Colors.white,
                                        shape: BoxShape.circle,
                                      ),
                                    ),
                                    const SizedBox(width: 4),
                                    Text(
                                      'live'.tr(),
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 10,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                          ],
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 4),
                            Text(
                              station.displayDescription,
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: AppTheme.mutedText,
                                  ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 4),
                            Row(
                              children: [
                                Icon(
                                  Icons.category,
                                  size: 14,
                                  color: AppTheme.mutedText,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  station.displayGenre,
                                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                        color: AppTheme.mutedText,
                                      ),
                                ),
                                const SizedBox(width: 12),
                                Icon(
                                  Icons.language,
                                  size: 14,
                                  color: AppTheme.mutedText,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  station.displayCountry,
                                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                        color: AppTheme.mutedText,
                                      ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        trailing: Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            gradient: isPlaying
                                ? const LinearGradient(
                                    colors: [AppTheme.accentColor, AppTheme.accentOrange],
                                  )
                                : const LinearGradient(
                                    colors: [AppTheme.primaryColor, AppTheme.secondaryColor],
                                  ),
                            shape: BoxShape.circle,
                          ),
                          child: IconButton(
                            icon: Icon(
                              isPlaying ? Icons.stop : Icons.play_arrow,
                              color: Colors.white,
                            ),
                            onPressed: () => _playStation(station),
                          ),
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
