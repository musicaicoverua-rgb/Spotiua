import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/theme/app_theme.dart';
import '../bloc/player_bloc.dart';

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<PlayerBloc, PlayerState>(
      builder: (context, state) {
        final track = state.currentTrack;
        
        if (track == null) {
          return const SizedBox.shrink();
        }
        
        return GestureDetector(
          onTap: () => context.push('/player'),
          child: Container(
            height: 72,
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppTheme.primaryColor, AppTheme.secondaryColor],
              ),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.primaryColor.withOpacity(0.3),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              children: [
                const SizedBox(width: 12),
                
                // Album art
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: track.coverUrl != null
                      ? Image.network(
                          track.coverUrl!,
                          width: 48,
                          height: 48,
                          fit: BoxFit.cover,
                        )
                      : Container(
                          width: 48,
                          height: 48,
                          color: Colors.white.withOpacity(0.2),
                          child: const Icon(
                            Icons.music_note,
                            color: Colors.white,
                          ),
                        ),
                ),
                
                const SizedBox(width: 12),
                
                // Track info
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        track.title,
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 2),
                      Text(
                        track.artist,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: Colors.white.withOpacity(0.8),
                            ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                
                // Controls
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.skip_previous),
                      color: Colors.white,
                      onPressed: state.hasPrevious
                          ? () {
                              context.read<PlayerBloc>().add(
                                    PlayerPreviousRequested(),
                                  );
                            }
                          : null,
                    ),
                    
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        shape: BoxShape.circle,
                      ),
                      child: IconButton(
                        icon: Icon(
                          state.isPlaying ? Icons.pause : Icons.play_arrow,
                        ),
                        color: Colors.white,
                        onPressed: () {
                          context.read<PlayerBloc>().add(
                                PlayerPlayPauseToggled(),
                              );
                        },
                      ),
                    ),
                    
                    IconButton(
                      icon: const Icon(Icons.skip_next),
                      color: Colors.white,
                      onPressed: state.hasNext
                          ? () {
                              context.read<PlayerBloc>().add(
                                    PlayerNextRequested(),
                                  );
                            }
                          : null,
                    ),
                  ],
                ),
                
                const SizedBox(width: 8),
              ],
            ),
          ),
        );
      },
    );
  }
}
