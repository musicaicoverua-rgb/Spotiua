import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/theme/app_theme.dart';
import '../../../../core/models/track_model.dart';
import '../../../../core/services/audio_service.dart';
import '../bloc/player_bloc.dart';

class PlayerScreen extends StatelessWidget {
  final TrackModel? track;
  
  const PlayerScreen({super.key, this.track});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: BlocBuilder<PlayerBloc, PlayerState>(
          builder: (context, state) {
            final currentTrack = state.currentTrack ?? track;
            
            if (currentTrack == null) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.music_note,
                      size: 64,
                      color: AppTheme.mutedText,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'No track playing',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            color: AppTheme.mutedText,
                          ),
                    ),
                  ],
                ),
              );
            }
            
            return Column(
              children: [
                // App bar
                _buildAppBar(context),
                
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Album art
                        _buildAlbumArt(context, currentTrack),
                        
                        const SizedBox(height: 48),
                        
                        // Track info
                        _buildTrackInfo(context, currentTrack),
                        
                        const SizedBox(height: 32),
                        
                        // Progress bar
                        _buildProgressBar(context, state),
                        
                        const SizedBox(height: 32),
                        
                        // Controls
                        _buildControls(context, state),
                        
                        const SizedBox(height: 32),
                        
                        // Extra actions
                        _buildExtraActions(context),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
  
  Widget _buildAppBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(
            icon: const Icon(Icons.keyboard_arrow_down),
            onPressed: () => Navigator.pop(context),
          ),
          Text(
            'now_playing'.tr(),
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          IconButton(
            icon: const Icon(Icons.more_vert),
            onPressed: () {
              _showMoreOptions(context);
            },
          ),
        ],
      ),
    );
  }
  
  Widget _buildAlbumArt(BuildContext context, TrackModel track) {
    return Hero(
      tag: 'album_art_${track.id}',
      child: Container(
        width: MediaQuery.of(context).size.width * 0.7,
        height: MediaQuery.of(context).size.width * 0.7,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: AppTheme.primaryColor.withOpacity(0.3),
              blurRadius: 30,
              offset: const Offset(0, 20),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: track.coverUrl != null
              ? Image.network(
                  track.coverUrl!,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) {
                    return _buildPlaceholder();
                  },
                )
              : _buildPlaceholder(),
        ),
      ),
    );
  }
  
  Widget _buildPlaceholder() {
    return Container(
      color: AppTheme.darkCard,
      child: const Center(
        child: Icon(
          Icons.music_note,
          size: 80,
          color: AppTheme.mutedText,
        ),
      ),
    );
  }
  
  Widget _buildTrackInfo(BuildContext context, TrackModel track) {
    return Column(
      children: [
        Text(
          track.title,
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
          textAlign: TextAlign.center,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
        const SizedBox(height: 8),
        Text(
          track.artist,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: AppTheme.mutedText,
              ),
          textAlign: TextAlign.center,
        ),
        if (track.album != null) ...[
          const SizedBox(height: 4),
          Text(
            track.album!,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppTheme.mutedText.withOpacity(0.7),
                ),
            textAlign: TextAlign.center,
          ),
        ],
      ],
    );
  }
  
  Widget _buildProgressBar(BuildContext context, PlayerState state) {
    final duration = state.duration ?? Duration.zero;
    final position = state.position;
    
    return Column(
      children: [
        Slider(
          value: position.inMilliseconds.toDouble(),
          max: duration.inMilliseconds.toDouble().clamp(1, double.infinity),
          onChanged: (value) {
            context.read<PlayerBloc>().add(
                  PlayerSeekRequested(
                    Duration(milliseconds: value.toInt()),
                  ),
                );
          },
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                _formatDuration(position),
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppTheme.mutedText,
                    ),
              ),
              Text(
                _formatDuration(duration),
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppTheme.mutedText,
                    ),
              ),
            ],
          ),
        ),
      ],
    );
  }
  
  String _formatDuration(Duration duration) {
    final minutes = duration.inMinutes;
    final seconds = duration.inSeconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }
  
  Widget _buildControls(BuildContext context, PlayerState state) {
    final isPlaying = state.isPlaying;
    
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        // Shuffle
        IconButton(
          icon: Icon(
            Icons.shuffle,
            color: state.isShuffled ? AppTheme.primaryColor : AppTheme.mutedText,
          ),
          onPressed: () {
            context.read<PlayerBloc>().add(PlayerShuffleToggled());
          },
        ),
        
        const SizedBox(width: 16),
        
        // Previous
        IconButton(
          icon: const Icon(Icons.skip_previous),
          iconSize: 40,
          onPressed: state.hasPrevious
              ? () {
                  context.read<PlayerBloc>().add(PlayerPreviousRequested());
                }
              : null,
        ),
        
        const SizedBox(width: 16),
        
        // Play/Pause
        Container(
          width: 72,
          height: 72,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [AppTheme.primaryColor, AppTheme.secondaryColor],
            ),
            borderRadius: BorderRadius.circular(36),
            boxShadow: [
              BoxShadow(
                color: AppTheme.primaryColor.withOpacity(0.4),
                blurRadius: 20,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: IconButton(
            icon: Icon(
              isPlaying ? Icons.pause : Icons.play_arrow,
              color: Colors.white,
            ),
            iconSize: 40,
            onPressed: () {
              context.read<PlayerBloc>().add(PlayerPlayPauseToggled());
            },
          ),
        ),
        
        const SizedBox(width: 16),
        
        // Next
        IconButton(
          icon: const Icon(Icons.skip_next),
          iconSize: 40,
          onPressed: state.hasNext
              ? () {
                  context.read<PlayerBloc>().add(PlayerNextRequested());
                }
              : null,
        ),
        
        const SizedBox(width: 16),
        
        // Repeat
        IconButton(
          icon: Icon(
            state.repeatMode == RepeatMode.one
                ? Icons.repeat_one
                : Icons.repeat,
            color: state.repeatMode != RepeatMode.off
                ? AppTheme.primaryColor
                : AppTheme.mutedText,
          ),
          onPressed: () {
            context.read<PlayerBloc>().add(PlayerRepeatToggled());
          },
        ),
      ],
    );
  }
  
  Widget _buildExtraActions(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        IconButton(
          icon: const Icon(Icons.favorite_border),
          onPressed: () {
            // TODO: Toggle like
          },
        ),
        IconButton(
          icon: const Icon(Icons.download_outlined),
          onPressed: () {
            // TODO: Download track
          },
        ),
        IconButton(
          icon: const Icon(Icons.share_outlined),
          onPressed: () {
            // TODO: Share track
          },
        ),
        IconButton(
          icon: const Icon(Icons.queue_music),
          onPressed: () {
            _showQueue(context);
          },
        ),
      ],
    );
  }
  
  void _showMoreOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.playlist_add),
              title: Text('add_to_playlist'.tr()),
              onTap: () {
                Navigator.pop(context);
                // TODO: Add to playlist
              },
            ),
            ListTile(
              leading: const Icon(Icons.person),
              title: Text('View Artist'),
              onTap: () {
                Navigator.pop(context);
                // TODO: View artist
              },
            ),
            ListTile(
              leading: const Icon(Icons.album),
              title: Text('View Album'),
              onTap: () {
                Navigator.pop(context);
                // TODO: View album
              },
            ),
          ],
        ),
      ),
    );
  }
  
  void _showQueue(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        minChildSize: 0.3,
        maxChildSize: 0.9,
        expand: false,
        builder: (context, scrollController) {
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  'queue'.tr(),
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
              ),
              Expanded(
                child: BlocBuilder<PlayerBloc, PlayerState>(
                  builder: (context, state) {
                    final queue = state.queue;
                    
                    if (queue.isEmpty) {
                      return Center(
                        child: Text(
                          'Queue is empty',
                          style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                                color: AppTheme.mutedText,
                              ),
                        ),
                      );
                    }
                    
                    return ListView.builder(
                      controller: scrollController,
                      itemCount: queue.length,
                      itemBuilder: (context, index) {
                        final track = queue[index];
                        final isCurrent = state.currentTrack?.id == track.id;
                        
                        return ListTile(
                          leading: isCurrent
                              ? const Icon(
                                  Icons.volume_up,
                                  color: AppTheme.primaryColor,
                                )
                              : Text('${index + 1}'),
                          title: Text(
                            track.title,
                            style: TextStyle(
                              color: isCurrent ? AppTheme.primaryColor : null,
                              fontWeight: isCurrent ? FontWeight.bold : null,
                            ),
                          ),
                          subtitle: Text(track.artist),
                          trailing: IconButton(
                            icon: const Icon(Icons.remove_circle_outline),
                            onPressed: () {
                              context.read<PlayerBloc>().add(
                                    PlayerRemoveFromQueueRequested(index: index),
                                  );
                            },
                          ),
                          onTap: () {
                            context.read<PlayerBloc>().add(
                                  PlayerPlayAtIndexRequested(index: index),
                                );
                          },
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
