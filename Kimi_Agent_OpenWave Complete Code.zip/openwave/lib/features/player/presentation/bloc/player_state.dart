part of 'player_bloc.dart';

class PlayerState extends Equatable {
  final TrackModel? currentTrack;
  final bool isPlaying;
  final PlaybackState playbackState;
  final Duration position;
  final Duration? duration;
  final List<TrackModel> queue;
  final bool hasNext;
  final bool hasPrevious;
  final bool isShuffled;
  final RepeatMode repeatMode;

  const PlayerState({
    this.currentTrack,
    this.isPlaying = false,
    this.playbackState = PlaybackState.stopped,
    this.position = Duration.zero,
    this.duration,
    this.queue = const [],
    this.hasNext = false,
    this.hasPrevious = false,
    this.isShuffled = false,
    this.repeatMode = RepeatMode.off,
  });

  PlayerState copyWith({
    TrackModel? currentTrack,
    bool? isPlaying,
    PlaybackState? playbackState,
    Duration? position,
    Duration? Function()? duration,
    List<TrackModel>? queue,
    bool? hasNext,
    bool? hasPrevious,
    bool? isShuffled,
    RepeatMode? repeatMode,
  }) {
    return PlayerState(
      currentTrack: currentTrack ?? this.currentTrack,
      isPlaying: isPlaying ?? this.isPlaying,
      playbackState: playbackState ?? this.playbackState,
      position: position ?? this.position,
      duration: duration != null ? duration() : this.duration,
      queue: queue ?? this.queue,
      hasNext: hasNext ?? this.hasNext,
      hasPrevious: hasPrevious ?? this.hasPrevious,
      isShuffled: isShuffled ?? this.isShuffled,
      repeatMode: repeatMode ?? this.repeatMode,
    );
  }

  @override
  List<Object?> get props => [
        currentTrack,
        isPlaying,
        playbackState,
        position,
        duration,
        queue,
        hasNext,
        hasPrevious,
        isShuffled,
        repeatMode,
      ];
}
