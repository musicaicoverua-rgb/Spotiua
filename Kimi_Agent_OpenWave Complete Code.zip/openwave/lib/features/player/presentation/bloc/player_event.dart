part of 'player_bloc.dart';

abstract class PlayerEvent extends Equatable {
  const PlayerEvent();

  @override
  List<Object?> get props => [];
}

class PlayerInitialized extends PlayerEvent {}

class PlayerTrackPlayed extends PlayerEvent {
  final TrackModel track;
  final List<TrackModel>? queue;

  const PlayerTrackPlayed({
    required this.track,
    this.queue,
  });

  @override
  List<Object?> get props => [track, queue];
}

class PlayerPlayPauseToggled extends PlayerEvent {}

class PlayerNextRequested extends PlayerEvent {}

class PlayerPreviousRequested extends PlayerEvent {}

class PlayerSeekRequested extends PlayerEvent {
  final Duration position;

  const PlayerSeekRequested(this.position);

  @override
  List<Object?> get props => [position];
}

class PlayerShuffleToggled extends PlayerEvent {}

class PlayerRepeatToggled extends PlayerEvent {}

class PlayerAddToQueueRequested extends PlayerEvent {
  final TrackModel track;

  const PlayerAddToQueueRequested({required this.track});

  @override
  List<Object?> get props => [track];
}

class PlayerRemoveFromQueueRequested extends PlayerEvent {
  final int index;

  const PlayerRemoveFromQueueRequested({required this.index});

  @override
  List<Object?> get props => [index];
}

class PlayerPlayAtIndexRequested extends PlayerEvent {
  final int index;

  const PlayerPlayAtIndexRequested({required this.index});

  @override
  List<Object?> get props => [index];
}

class PlayerTrackChanged extends PlayerEvent {
  final TrackModel? track;

  const PlayerTrackChanged({this.track});

  @override
  List<Object?> get props => [track];
}

class PlayerStateChanged extends PlayerEvent {
  final PlaybackState playbackState;

  const PlayerStateChanged({required this.playbackState});

  @override
  List<Object?> get props => [playbackState];
}

class PlayerPositionChanged extends PlayerEvent {
  final Duration position;

  const PlayerPositionChanged({required this.position});

  @override
  List<Object?> get props => [position];
}

class PlayerDurationChanged extends PlayerEvent {
  final Duration? duration;

  const PlayerDurationChanged({this.duration});

  @override
  List<Object?> get props => [duration];
}

class PlayerQueueChanged extends PlayerEvent {
  final List<TrackModel> queue;

  const PlayerQueueChanged({required this.queue});

  @override
  List<Object?> get props => [queue];
}
