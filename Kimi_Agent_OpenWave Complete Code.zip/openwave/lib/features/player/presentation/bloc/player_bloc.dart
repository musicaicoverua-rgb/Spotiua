import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';

import '../../../../core/services/audio_service.dart';
import '../../../../core/models/track_model.dart';

part 'player_event.dart';
part 'player_state.dart';

@injectable
class PlayerBloc extends Bloc<PlayerEvent, PlayerState> {
  final AudioPlayerService _audioService;
  StreamSubscription? _trackSubscription;
  StreamSubscription? _stateSubscription;
  StreamSubscription? _positionSubscription;
  StreamSubscription? _durationSubscription;
  StreamSubscription? _queueSubscription;

  PlayerBloc(this._audioService) : super(const PlayerState()) {
    on<PlayerInitialized>(_onInitialized);
    on<PlayerTrackPlayed>(_onTrackPlayed);
    on<PlayerPlayPauseToggled>(_onPlayPauseToggled);
    on<PlayerNextRequested>(_onNextRequested);
    on<PlayerPreviousRequested>(_onPreviousRequested);
    on<PlayerSeekRequested>(_onSeekRequested);
    on<PlayerShuffleToggled>(_onShuffleToggled);
    on<PlayerRepeatToggled>(_onRepeatToggled);
    on<PlayerAddToQueueRequested>(_onAddToQueueRequested);
    on<PlayerRemoveFromQueueRequested>(_onRemoveFromQueueRequested);
    on<PlayerPlayAtIndexRequested>(_onPlayAtIndexRequested);
    on<PlayerTrackChanged>(_onTrackChanged);
    on<PlayerStateChanged>(_onStateChanged);
    on<PlayerPositionChanged>(_onPositionChanged);
    on<PlayerDurationChanged>(_onDurationChanged);
    on<PlayerQueueChanged>(_onQueueChanged);

    // Initialize
    add(PlayerInitialized());
  }

  void _onInitialized(PlayerInitialized event, Emitter<PlayerState> emit) {
    // Subscribe to audio service streams
    _trackSubscription = _audioService.currentTrackStream.listen((track) {
      add(PlayerTrackChanged(track: track));
    });

    _stateSubscription = _audioService.playbackStateStream.listen((playbackState) {
      add(PlayerStateChanged(playbackState: playbackState));
    });

    _positionSubscription = _audioService.positionStream.listen((position) {
      add(PlayerPositionChanged(position: position));
    });

    _durationSubscription = _audioService.durationStream.listen((duration) {
      add(PlayerDurationChanged(duration: duration));
    });

    _queueSubscription = _audioService.queueStream.listen((queue) {
      add(PlayerQueueChanged(queue: queue));
    });
  }

  Future<void> _onTrackPlayed(
    PlayerTrackPlayed event,
    Emitter<PlayerState> emit,
  ) async {
    await _audioService.playTrack(event.track, queue: event.queue);
  }

  Future<void> _onPlayPauseToggled(
    PlayerPlayPauseToggled event,
    Emitter<PlayerState> emit,
  ) async {
    await _audioService.togglePlayPause();
  }

  Future<void> _onNextRequested(
    PlayerNextRequested event,
    Emitter<PlayerState> emit,
  ) async {
    await _audioService.skipToNext();
  }

  Future<void> _onPreviousRequested(
    PlayerPreviousRequested event,
    Emitter<PlayerState> emit,
  ) async {
    await _audioService.skipToPrevious();
  }

  Future<void> _onSeekRequested(
    PlayerSeekRequested event,
    Emitter<PlayerState> emit,
  ) async {
    await _audioService.seek(event.position);
  }

  void _onShuffleToggled(PlayerShuffleToggled event, Emitter<PlayerState> emit) {
    emit(state.copyWith(isShuffled: !state.isShuffled));
    _audioService.setShuffleMode(state.isShuffled);
  }

  void _onRepeatToggled(PlayerRepeatToggled event, Emitter<PlayerState> emit) {
    RepeatMode nextMode;
    switch (state.repeatMode) {
      case RepeatMode.off:
        nextMode = RepeatMode.all;
        break;
      case RepeatMode.all:
        nextMode = RepeatMode.one;
        break;
      case RepeatMode.one:
        nextMode = RepeatMode.off;
        break;
    }
    emit(state.copyWith(repeatMode: nextMode));
    _audioService.setRepeatMode(nextMode);
  }

  Future<void> _onAddToQueueRequested(
    PlayerAddToQueueRequested event,
    Emitter<PlayerState> emit,
  ) async {
    await _audioService.addToQueue(event.track);
  }

  Future<void> _onRemoveFromQueueRequested(
    PlayerRemoveFromQueueRequested event,
    Emitter<PlayerState> emit,
  ) async {
    await _audioService.removeFromQueue(event.index);
  }

  Future<void> _onPlayAtIndexRequested(
    PlayerPlayAtIndexRequested event,
    Emitter<PlayerState> emit,
  ) async {
    final queue = state.queue;
    if (event.index >= 0 && event.index < queue.length) {
      await _audioService.playTrack(queue[event.index]);
    }
  }

  void _onTrackChanged(PlayerTrackChanged event, Emitter<PlayerState> emit) {
    emit(state.copyWith(currentTrack: () => event.track));
  }

  void _onStateChanged(PlayerStateChanged event, Emitter<PlayerState> emit) {
    emit(state.copyWith(
      playbackState: event.playbackState,
      isPlaying: event.playbackState == PlaybackState.playing,
    ));
  }

  void _onPositionChanged(PlayerPositionChanged event, Emitter<PlayerState> emit) {
    emit(state.copyWith(position: event.position));
  }

  void _onDurationChanged(PlayerDurationChanged event, Emitter<PlayerState> emit) {
    emit(state.copyWith(duration: () => event.duration));
  }

  void _onQueueChanged(PlayerQueueChanged event, Emitter<PlayerState> emit) {
    emit(state.copyWith(
      queue: event.queue,
      hasNext: _audioService.hasNext,
      hasPrevious: _audioService.hasPrevious,
    ));
  }

  @override
  Future<void> close() {
    _trackSubscription?.cancel();
    _stateSubscription?.cancel();
    _positionSubscription?.cancel();
    _durationSubscription?.cancel();
    _queueSubscription?.cancel();
    return super.close();
  }
}
