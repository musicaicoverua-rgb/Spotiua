import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

import '../../../../core/theme/app_theme.dart';
import '../../../../core/models/track_model.dart';
import '../bloc/home_bloc.dart';
import 'track_list_horizontal.dart';
import 'genre_grid.dart';

class HomeTab extends StatefulWidget {
  const HomeTab({super.key});

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  final RefreshController _refreshController = RefreshController();
  
  @override
  void initState() {
    super.initState();
    context.read<HomeBloc>().add(HomeLoadRequested());
  }
  
  @override
  void dispose() {
    _refreshController.dispose();
    super.dispose();
  }
  
  void _onRefresh() {
    context.read<HomeBloc>().add(HomeRefreshRequested());
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<HomeBloc, HomeState>(
      listener: (context, state) {
        if (state is HomeLoaded || state is HomeError) {
          _refreshController.refreshCompleted();
        }
      },
      builder: (context, state) {
        return CustomScrollView(
          slivers: [
            // App Bar
            SliverAppBar(
              floating: true,
              title: Text(
                'OpenWave',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryColor,
                    ),
              ),
              actions: [
                IconButton(
                  icon: const Icon(Icons.notifications_outlined),
                  onPressed: () {
                    // TODO: Show notifications
                  },
                ),
              ],
            ),
            
            // Content
            if (state is HomeLoading)
              const SliverFillRemaining(
                child: Center(child: CircularProgressIndicator()),
              )
            else if (state is HomeLoaded)
              SliverToBoxAdapter(
                child: SmartRefresher(
                  controller: _refreshController,
                  onRefresh: _onRefresh,
                  header: const WaterDropHeader(),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Daily Reward Banner
                      _buildDailyRewardBanner(context),
                      
                      const SizedBox(height: 24),
                      
                      // Recommended Section
                      _buildSectionHeader(
                        context,
                        title: 'for_you'.tr(),
                        onSeeAll: () {},
                      ),
                      TrackListHorizontal(
                        tracks: state.recommendedTracks,
                      ),
                      
                      const SizedBox(height: 24),
                      
                      // Popular Section
                      _buildSectionHeader(
                        context,
                        title: 'popular'.tr(),
                        onSeeAll: () {},
                      ),
                      TrackListHorizontal(
                        tracks: state.popularTracks,
                      ),
                      
                      const SizedBox(height: 24),
                      
                      // New Releases Section
                      _buildSectionHeader(
                        context,
                        title: 'new_releases'.tr(),
                        onSeeAll: () {},
                      ),
                      TrackListHorizontal(
                        tracks: state.newReleases,
                      ),
                      
                      const SizedBox(height: 24),
                      
                      // Genres Section
                      _buildSectionHeader(
                        context,
                        title: 'genres'.tr(),
                        onSeeAll: () {},
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16),
                        child: GenreGrid(),
                      ),
                      
                      const SizedBox(height: 24),
                      
                      // Mood Playlists Section
                      _buildSectionHeader(
                        context,
                        title: 'mood_playlists'.tr(),
                        onSeeAll: () {},
                      ),
                      _buildMoodPlaylists(context),
                      
                      const SizedBox(height: 100),
                    ],
                  ),
                ),
              )
            else if (state is HomeError)
              SliverFillRemaining(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.error_outline,
                        size: 64,
                        color: AppTheme.mutedText,
                      ),
                      const SizedBox(height: 16),
                      Text(state.message),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () {
                          context.read<HomeBloc>().add(HomeLoadRequested());
                        },
                        child: Text('retry'.tr()),
                      ),
                    ],
                  ),
                ),
              )
            else
              const SliverFillRemaining(
                child: Center(child: CircularProgressIndicator()),
              ),
          ],
        );
      },
    );
  }
  
  Widget _buildDailyRewardBanner(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GestureDetector(
        onTap: () => context.push('/daily-reward'),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [AppTheme.accentOrange, AppTheme.accentYellow],
            ),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.card_giftcard,
                  color: Colors.white,
                  size: 32,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'daily_reward'.tr(),
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'claim_reward'.tr(),
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Colors.white.withOpacity(0.9),
                          ),
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.arrow_forward_ios,
                color: Colors.white,
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  Widget _buildSectionHeader(
    BuildContext context, {
    required String title,
    required VoidCallback onSeeAll,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          TextButton(
            onPressed: onSeeAll,
            child: Text('more'.tr()),
          ),
        ],
      ),
    );
  }
  
  Widget _buildMoodPlaylists(BuildContext context) {
    final moods = [
      ('workout', Icons.fitness_center, AppTheme.accentColor),
      ('focus', Icons.self_improvement, AppTheme.secondaryColor),
      ('relax', Icons.spa, AppTheme.primaryColor),
      ('party', Icons.celebration, AppTheme.accentYellow),
      ('sleep', Icons.nightlight_round, AppTheme.darkCard),
      ('commute', Icons.directions_car, AppTheme.accentOrange),
    ];
    
    return SizedBox(
      height: 100,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: moods.length,
        itemBuilder: (context, index) {
          final (key, icon, color) = moods[index];
          return Padding(
            padding: const EdgeInsets.only(right: 12),
            child: GestureDetector(
              onTap: () {
                // TODO: Navigate to mood playlist
              },
              child: Container(
                width: 80,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: color.withOpacity(0.3),
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(icon, color: color),
                    const SizedBox(height: 8),
                    Text(
                      key.tr(),
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: color,
                            fontWeight: FontWeight.w600,
                          ),
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
