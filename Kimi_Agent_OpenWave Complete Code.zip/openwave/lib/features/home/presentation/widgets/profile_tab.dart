import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/theme/app_theme.dart';
import '../../../../core/services/supabase_service.dart';
import '../../../auth/presentation/bloc/auth_bloc.dart';

class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
        SliverAppBar(
          floating: true,
          title: Text(
            'profile'.tr(),
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.settings_outlined),
              onPressed: () => context.push('/settings'),
            ),
          ],
        ),
        
        SliverPadding(
          padding: const EdgeInsets.all(16),
          sliver: SliverList(
            delegate: SliverChildListDelegate([
              // User info
              _buildUserInfo(context),
              
              const SizedBox(height: 24),
              
              // Gamification stats
              _buildGamificationStats(context),
              
              const SizedBox(height: 24),
              
              // Quick actions
              _buildQuickActions(context),
              
              const SizedBox(height: 24),
              
              // Menu items
              _buildMenuItems(context),
            ]),
          ),
        ),
      ],
    );
  }
  
  Widget _buildUserInfo(BuildContext context) {
    return BlocBuilder<AuthBloc, AuthState>(
      builder: (context, state) {
        String displayName = 'User';
        String email = '';
        
        if (state is AuthAuthenticated && state.user != null) {
          displayName = state.user!.displayNameOrUsername;
          email = state.user!.email;
        }
        
        return Column(
          children: [
            // Avatar
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [AppTheme.primaryColor, AppTheme.secondaryColor],
                ),
                borderRadius: BorderRadius.circular(50),
              ),
              child: Center(
                child: Text(
                  displayName.isNotEmpty ? displayName[0].toUpperCase() : 'U',
                  style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                ),
              ),
            ),
            
            const SizedBox(height: 16),
            
            // Name
            Text(
              displayName,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            
            const SizedBox(height: 4),
            
            // Email
            Text(
              email,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: AppTheme.mutedText,
                  ),
            ),
            
            const SizedBox(height: 16),
            
            // Edit profile button
            OutlinedButton.icon(
              onPressed: () => context.push('/edit-profile'),
              icon: const Icon(Icons.edit),
              label: Text('edit'.tr()),
            ),
          ],
        );
      },
    );
  }
  
  Widget _buildGamificationStats(BuildContext context) {
    return BlocBuilder<AuthBloc, AuthState>(
      builder: (context, state) {
        int points = 0;
        int coins = 0;
        int xp = 0;
        int level = 1;
        double levelProgress = 0;
        
        if (state is AuthAuthenticated && state.user != null) {
          points = state.user!.points;
          coins = state.user!.coins;
          xp = state.user!.xp;
          level = state.user!.level;
          levelProgress = state.user!.levelProgress;
        }
        
        return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [AppTheme.primaryColor, AppTheme.secondaryColor],
            ),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            children: [
              // Level and XP
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.star,
                          color: Colors.white,
                          size: 20,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'Level $level',
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              
              const SizedBox(height: 16),
              
              // XP Progress
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: levelProgress,
                  backgroundColor: Colors.white.withOpacity(0.2),
                  valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
                  minHeight: 8,
                ),
              ),
              
              const SizedBox(height: 8),
              
              Text(
                '$xp / ${level * level * 100} XP',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.white.withOpacity(0.8),
                    ),
              ),
              
              const SizedBox(height: 16),
              
              // Stats row
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildStatItem(
                    context,
                    icon: Icons.monetization_on,
                    value: coins.toString(),
                    label: 'coins'.tr(),
                    color: AppTheme.coinsColor,
                  ),
                  _buildStatItem(
                    context,
                    icon: Icons.emoji_events,
                    value: points.toString(),
                    label: 'points'.tr(),
                    color: AppTheme.pointsColor,
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
  
  Widget _buildStatItem(
    BuildContext context, {
    required IconData icon,
    required String value,
    required String label,
    required Color color,
  }) {
    return Column(
      children: [
        Icon(icon, color: color, size: 28),
        const SizedBox(height: 4),
        Text(
          value,
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
        ),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Colors.white.withOpacity(0.8),
              ),
        ),
      ],
    );
  }
  
  Widget _buildQuickActions(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _buildQuickActionButton(
            context,
            icon: Icons.card_giftcard,
            label: 'daily_reward'.tr(),
            color: AppTheme.accentOrange,
            onTap: () => context.push('/daily-reward'),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _buildQuickActionButton(
            context,
            icon: Icons.casino,
            label: 'spin_wheel'.tr(),
            color: AppTheme.accentColor,
            onTap: () => context.push('/spin-wheel'),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _buildQuickActionButton(
            context,
            icon: Icons.emoji_events,
            label: 'achievements'.tr(),
            color: AppTheme.levelColor,
            onTap: () => context.push('/achievements'),
          ),
        ),
      ],
    );
  }
  
  Widget _buildQuickActionButton(
    BuildContext context, {
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Icon(icon, color: color),
            const SizedBox(height: 8),
            Text(
              label,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: color,
                    fontWeight: FontWeight.w600,
                  ),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildMenuItems(BuildContext context) {
    return Column(
      children: [
        _buildMenuItem(
          context,
          icon: Icons.radio,
          title: 'radio'.tr(),
          onTap: () => context.push('/radio'),
        ),
        _buildMenuItem(
          context,
          icon: Icons.chat_bubble_outline,
          title: 'chat_with_admin'.tr(),
          onTap: () => context.push('/chat'),
        ),
        _buildMenuItem(
          context,
          icon: Icons.analytics_outlined,
          title: 'analytics'.tr(),
          onTap: () => context.push('/analytics'),
        ),
        
        // Admin option (only visible for admins)
        FutureBuilder<bool>(
          future: SupabaseService().isAdmin(),
          builder: (context, snapshot) {
            if (snapshot.data == true) {
              return _buildMenuItem(
                context,
                icon: Icons.admin_panel_settings,
                title: 'admin'.tr(),
                onTap: () => context.push('/admin'),
              );
            }
            return const SizedBox.shrink();
          },
        ),
        
        _buildMenuItem(
          context,
          icon: Icons.settings_outlined,
          title: 'settings'.tr(),
          onTap: () => context.push('/settings'),
        ),
        _buildMenuItem(
          context,
          icon: Icons.logout,
          title: 'logout'.tr(),
          textColor: AppTheme.errorColor,
          onTap: () => _showLogoutDialog(context),
        ),
      ],
    );
  }
  
  Widget _buildMenuItem(
    BuildContext context, {
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    Color? textColor,
  }) {
    return ListTile(
      leading: Icon(icon, color: textColor),
      title: Text(
        title,
        style: TextStyle(color: textColor),
      ),
      trailing: const Icon(Icons.chevron_right),
      onTap: onTap,
    );
  }
  
  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('logout'.tr()),
        content: Text('confirm_logout'.tr()),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('no'.tr()),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              context.read<AuthBloc>().add(AuthLogoutRequested());
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.errorColor,
            ),
            child: Text('yes'.tr()),
          ),
        ],
      ),
    );
  }
}
