import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/theme/app_theme.dart';
import '../bloc/home_bloc.dart';

class GenreGrid extends StatelessWidget {
  const GenreGrid({super.key});

  @override
  Widget build(BuildContext context) {
    final genres = [
      ('pop', Icons.music_note, const Color(0xFFE91E63)),
      ('rock', Icons.electric_bolt, const Color(0xFF673AB7)),
      ('hip_hop', Icons.mic, const Color(0xFFFF9800)),
      ('electronic', Icons.computer, const Color(0xFF00BCD4)),
      ('jazz', Icons.nightlife, const Color(0xFF795548)),
      ('classical', Icons.piano, const Color(0xFF607D8B)),
      ('rnb', Icons.favorite, const Color(0xFF9C27B0)),
      ('all_genres', Icons.grid_view, AppTheme.primaryColor),
    ];
    
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        childAspectRatio: 0.85,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemCount: genres.length,
      itemBuilder: (context, index) {
        final (key, icon, color) = genres[index];
        return GestureDetector(
          onTap: () {
            if (key != 'all_genres') {
              context.read<HomeBloc>().add(HomeGenreSelected(genre: key));
            }
          },
          child: Column(
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [color, color.withOpacity(0.7)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: color.withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Icon(
                  icon,
                  color: Colors.white,
                  size: 28,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                key.tr(),
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      fontWeight: FontWeight.w500,
                    ),
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        );
      },
    );
  }
}
