import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/theme/app_theme.dart';
import '../bloc/home_bloc.dart';

class SearchTab extends StatefulWidget {
  const SearchTab({super.key});

  @override
  State<SearchTab> createState() => _SearchTabState();
}

class _SearchTabState extends State<SearchTab> {
  final _searchController = TextEditingController();
  
  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Search bar
        Padding(
          padding: const EdgeInsets.all(16),
          child: TextField(
            controller: _searchController,
            decoration: InputDecoration(
              hintText: 'search_hint'.tr(),
              prefixIcon: const Icon(Icons.search),
              suffixIcon: _searchController.text.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () {
                        _searchController.clear();
                        context.read<HomeBloc>().add(HomeLoadRequested());
                      },
                    )
                  : null,
            ),
            onChanged: (value) {
              setState(() {});
            },
            onSubmitted: (value) {
              if (value.isNotEmpty) {
                context.read<HomeBloc>().add(
                      HomeSearchRequested(query: value),
                    );
              }
            },
          ),
        ),
        
        // Search results
        Expanded(
          child: BlocBuilder<HomeBloc, HomeState>(
            builder: (context, state) {
              if (state is HomeSearching) {
                return const Center(child: CircularProgressIndicator());
              }
              
              if (state is HomeSearchResults) {
                if (state.tracks.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(
                          Icons.search_off,
                          size: 64,
                          color: AppTheme.mutedText,
                        ),
                        const SizedBox(height: 16),
                        Text('empty_search'.tr()),
                      ],
                    ),
                  );
                }
                
                return ListView.builder(
                  itemCount: state.tracks.length,
                  itemBuilder: (context, index) {
                    final track = state.tracks[index];
                    return ListTile(
                      leading: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: track.coverUrl != null
                            ? Image.network(
                                track.coverUrl!,
                                width: 50,
                                height: 50,
                                fit: BoxFit.cover,
                              )
                            : Container(
                                width: 50,
                                height: 50,
                                color: AppTheme.darkCard,
                                child: const Icon(Icons.music_note),
                              ),
                      ),
                      title: Text(track.title),
                      subtitle: Text(track.artist),
                      trailing: IconButton(
                        icon: const Icon(Icons.play_arrow),
                        onPressed: () {
                          context.push('/player', extra: track);
                        },
                      ),
                      onTap: () {
                        context.push('/player', extra: track);
                      },
                    );
                  },
                );
              }
              
              // Default view - trending searches
              return _buildTrendingSearches(context);
            },
          ),
        ),
      ],
    );
  }
  
  Widget _buildTrendingSearches(BuildContext context) {
    final trending = [
      'Taylor Swift',
      'The Weeknd',
      'Drake',
      'Ed Sheeran',
      'Billie Eilish',
      'Dua Lipa',
      'Ariana Grande',
      'BTS',
    ];
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'trending_now'.tr(),
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: trending.map((term) {
              return ActionChip(
                avatar: const Icon(Icons.trending_up, size: 18),
                label: Text(term),
                onPressed: () {
                  _searchController.text = term;
                  context.read<HomeBloc>().add(
                        HomeSearchRequested(query: term),
                      );
                },
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}
