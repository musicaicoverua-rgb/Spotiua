import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/theme/app_theme.dart';

class LibraryTab extends StatelessWidget {
  const LibraryTab({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
        SliverAppBar(
          floating: true,
          title: Text(
            'library'.tr(),
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.search),
              onPressed: () {
                // TODO: Search in library
              },
            ),
          ],
        ),
        
        SliverPadding(
          padding: const EdgeInsets.all(16),
          sliver: SliverList(
            delegate: SliverChildListDelegate([
              // Liked Songs
              _buildLibraryItem(
                context,
                icon: Icons.favorite,
                iconColor: AppTheme.accentColor,
                title: 'liked_songs'.tr(),
                subtitle: '0 songs',
                onTap: () {},
              ),
              
              const SizedBox(height: 12),
              
              // Recently Played
              _buildLibraryItem(
                context,
                icon: Icons.history,
                iconColor: AppTheme.primaryColor,
                title: 'recently_played'.tr(),
                subtitle: '0 songs',
                onTap: () {},
              ),
              
              const SizedBox(height: 12),
              
              // Offline Tracks
              _buildLibraryItem(
                context,
                icon: Icons.download_done,
                iconColor: AppTheme.secondaryColor,
                title: 'offline_tracks'.tr(),
                subtitle: '0 songs',
                onTap: () {},
              ),
              
              const SizedBox(height: 24),
              
              // Playlists Section
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'playlists'.tr(),
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.add),
                    onPressed: () {
                      // TODO: Create playlist
                    },
                  ),
                ],
              ),
              
              const SizedBox(height: 16),
              
              // Empty state
              Center(
                child: Column(
                  children: [
                    Icon(
                      Icons.playlist_play,
                      size: 64,
                      color: AppTheme.mutedText.withOpacity(0.5),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'No playlists yet',
                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                            color: AppTheme.mutedText,
                          ),
                    ),
                    const SizedBox(height: 8),
                    TextButton(
                      onPressed: () {
                        // TODO: Create playlist
                      },
                      child: Text('create_playlist'.tr()),
                    ),
                  ],
                ),
              ),
            ]),
          ),
        ),
      ],
    );
  }
  
  Widget _buildLibraryItem(
    BuildContext context, {
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [iconColor, iconColor.withOpacity(0.7)],
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: Colors.white),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: AppTheme.mutedText,
                        ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right),
          ],
        ),
      ),
    );
  }
}
