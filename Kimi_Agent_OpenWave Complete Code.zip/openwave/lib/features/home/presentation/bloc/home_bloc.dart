import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';

import '../../../../core/services/supabase_service.dart';
import '../../../../core/models/track_model.dart';
import '../../../../core/models/playlist_model.dart';

part 'home_event.dart';
part 'home_state.dart';

@injectable
class HomeBloc extends Bloc<HomeEvent, HomeState> {
  final SupabaseService _supabaseService;
  
  HomeBloc(this._supabaseService) : super(HomeInitial()) {
    on<HomeLoadRequested>(_onHomeLoadRequested);
    on<HomeRefreshRequested>(_onHomeRefreshRequested);
    on<HomeSearchRequested>(_onHomeSearchRequested);
    on<HomeGenreSelected>(_onHomeGenreSelected);
  }
  
  Future<void> _onHomeLoadRequested(
    HomeLoadRequested event,
    Emitter<HomeState> emit,
  ) async {
    emit(HomeLoading());
    
    try {
      final results = await Future.wait([
        _supabaseService.getPopularTracks(limit: 10),
        _supabaseService.getNewReleases(limit: 10),
        _supabaseService.getRecommendedTracks(limit: 10),
      ]);
      
      emit(HomeLoaded(
        popularTracks: results[0] as List<TrackModel>,
        newReleases: results[1] as List<TrackModel>,
        recommendedTracks: results[2] as List<TrackModel>,
      ));
    } catch (e) {
      emit(HomeError(message: 'Failed to load home data'));
    }
  }
  
  Future<void> _onHomeRefreshRequested(
    HomeRefreshRequested event,
    Emitter<HomeState> emit,
  ) async {
    final currentState = state;
    if (currentState is HomeLoaded) {
      emit(HomeRefreshing(loadedState: currentState));
    }
    
    try {
      final results = await Future.wait([
        _supabaseService.getPopularTracks(limit: 10),
        _supabaseService.getNewReleases(limit: 10),
        _supabaseService.getRecommendedTracks(limit: 10),
      ]);
      
      emit(HomeLoaded(
        popularTracks: results[0] as List<TrackModel>,
        newReleases: results[1] as List<TrackModel>,
        recommendedTracks: results[2] as List<TrackModel>,
      ));
    } catch (e) {
      if (currentState is HomeLoaded) {
        emit(currentState);
      } else {
        emit(HomeError(message: 'Failed to refresh data'));
      }
    }
  }
  
  Future<void> _onHomeSearchRequested(
    HomeSearchRequested event,
    Emitter<HomeState> emit,
  ) async {
    if (event.query.isEmpty) {
      add(HomeLoadRequested());
      return;
    }
    
    emit(HomeSearching());
    
    try {
      final tracks = await _supabaseService.getTracks(
        searchQuery: event.query,
        limit: 50,
      );
      
      emit(HomeSearchResults(tracks: tracks, query: event.query));
    } catch (e) {
      emit(HomeError(message: 'Search failed'));
    }
  }
  
  Future<void> _onHomeGenreSelected(
    HomeGenreSelected event,
    Emitter<HomeState> emit,
  ) async {
    emit(HomeLoading());
    
    try {
      final tracks = await _supabaseService.getTracks(
        genre: event.genre,
        limit: 50,
      );
      
      emit(HomeGenreResults(
        tracks: tracks,
        genre: event.genre,
      ));
    } catch (e) {
      emit(HomeError(message: 'Failed to load genre'));
    }
  }
}
