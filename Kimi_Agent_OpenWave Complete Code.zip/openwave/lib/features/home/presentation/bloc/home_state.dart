part of 'home_bloc.dart';

abstract class HomeState extends Equatable {
  const HomeState();

  @override
  List<Object?> get props => [];
}

class HomeInitial extends HomeState {}

class HomeLoading extends HomeState {}

class HomeRefreshing extends HomeState {
  final HomeLoaded loadedState;

  const HomeRefreshing({required this.loadedState});

  @override
  List<Object?> get props => [loadedState];
}

class HomeLoaded extends HomeState {
  final List<TrackModel> popularTracks;
  final List<TrackModel> newReleases;
  final List<TrackModel> recommendedTracks;

  const HomeLoaded({
    required this.popularTracks,
    required this.newReleases,
    required this.recommendedTracks,
  });

  @override
  List<Object?> get props => [popularTracks, newReleases, recommendedTracks];
}

class HomeSearching extends HomeState {}

class HomeSearchResults extends HomeState {
  final List<TrackModel> tracks;
  final String query;

  const HomeSearchResults({
    required this.tracks,
    required this.query,
  });

  @override
  List<Object?> get props => [tracks, query];
}

class HomeGenreResults extends HomeState {
  final List<TrackModel> tracks;
  final String genre;

  const HomeGenreResults({
    required this.tracks,
    required this.genre,
  });

  @override
  List<Object?> get props => [tracks, genre];
}

class HomeError extends HomeState {
  final String message;

  const HomeError({required this.message});

  @override
  List<Object?> get props => [message];
}
