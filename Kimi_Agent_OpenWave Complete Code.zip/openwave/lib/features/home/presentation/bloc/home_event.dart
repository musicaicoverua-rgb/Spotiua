part of 'home_bloc.dart';

abstract class HomeEvent extends Equatable {
  const HomeEvent();

  @override
  List<Object?> get props => [];
}

class HomeLoadRequested extends HomeEvent {}

class HomeRefreshRequested extends HomeEvent {}

class HomeSearchRequested extends HomeEvent {
  final String query;

  const HomeSearchRequested({required this.query});

  @override
  List<Object?> get props => [query];
}

class HomeGenreSelected extends HomeEvent {
  final String genre;

  const HomeGenreSelected({required this.genre});

  @override
  List<Object?> get props => [genre];
}

class HomeTrackPlayed extends HomeEvent {
  final TrackModel track;

  const HomeTrackPlayed({required this.track});

  @override
  List<Object?> get props => [track];
}
