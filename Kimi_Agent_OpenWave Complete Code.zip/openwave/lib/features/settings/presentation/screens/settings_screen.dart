import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:easy_localization/easy_localization.dart' as el;

import '../../../../core/theme/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _notificationsEnabled = true;
  bool _offlineMode = false;
  
  final List<Map<String, dynamic>> _languages = [
    {'code': 'uk', 'name': 'Українська', 'flag': '🇺🇦'},
    {'code': 'en', 'name': 'English', 'flag': '🇬🇧'},
    {'code': 'es', 'name': 'Español', 'flag': '🇪🇸'},
    {'code': 'ru', 'name': 'Русский', 'flag': '🇷🇺'},
    {'code': 'de', 'name': 'Deutsch', 'flag': '🇩🇪'},
    {'code': 'fr', 'name': 'Français', 'flag': '🇫🇷'},
    {'code': 'pl', 'name': 'Polski', 'flag': '🇵🇱'},
    {'code': 'cs', 'name': 'Čeština', 'flag': '🇨🇿'},
  ];

  @override
  Widget build(BuildContext context) {
    final currentLocale = context.locale.languageCode;
    
    return Scaffold(
      appBar: AppBar(
        title: Text('settings'.tr()),
      ),
      body: ListView(
        children: [
          // Account section
          _buildSectionHeader('Account'),
          
          ListTile(
            leading: const Icon(Icons.person_outline),
            title: const Text('Edit Profile'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {},
          ),
          
          ListTile(
            leading: const Icon(Icons.lock_outline),
            title: const Text('Change Password'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {},
          ),
          
          const Divider(),
          
          // Preferences section
          _buildSectionHeader('Preferences'),
          
          // Language
          ListTile(
            leading: const Icon(Icons.language),
            title: Text('language'.tr()),
            subtitle: Text(
              _languages.firstWhere(
                (l) => l['code'] == currentLocale,
                orElse: () => _languages[0],
              )['name'],
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _showLanguageSelector(context),
          ),
          
          // Theme
          ListTile(
            leading: const Icon(Icons.palette_outlined),
            title: Text('theme'.tr()),
            subtitle: Text('system_default'.tr()),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _showThemeSelector(context),
          ),
          
          // Notifications
          SwitchListTile(
            secondary: const Icon(Icons.notifications_outlined),
            title: Text('notifications'.tr()),
            value: _notificationsEnabled,
            onChanged: (value) {
              setState(() {
                _notificationsEnabled = value;
              });
            },
          ),
          
          // Offline mode
          SwitchListTile(
            secondary: const Icon(Icons.offline_bolt_outlined),
            title: Text('offline_mode'.tr()),
            subtitle: const Text('Only play downloaded tracks'),
            value: _offlineMode,
            onChanged: (value) {
              setState(() {
                _offlineMode = value;
              });
            },
          ),
          
          const Divider(),
          
          // Storage section
          _buildSectionHeader('Storage'),
          
          ListTile(
            leading: const Icon(Icons.storage_outlined),
            title: Text('storage_usage'.tr()),
            subtitle: const Text('125 MB used'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {},
          ),
          
          ListTile(
            leading: const Icon(Icons.delete_outline),
            title: Text('clear_cache'.tr()),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _showClearCacheDialog(context),
          ),
          
          const Divider(),
          
          // About section
          _buildSectionHeader('About'),
          
          ListTile(
            leading: const Icon(Icons.info_outline),
            title: Text('version'.tr()),
            subtitle: const Text('1.0.0'),
          ),
          
          ListTile(
            leading: const Icon(Icons.privacy_tip_outlined),
            title: Text('privacy_policy'.tr()),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {},
          ),
          
          ListTile(
            leading: const Icon(Icons.description_outlined),
            title: Text('terms_of_service'.tr()),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {},
          ),
          
          const SizedBox(height: 32),
        ],
      ),
    );
  }
  
  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Text(
        title,
        style: Theme.of(context).textTheme.titleSmall?.copyWith(
              color: AppTheme.primaryColor,
              fontWeight: FontWeight.bold,
            ),
      ),
    );
  }
  
  void _showLanguageSelector(BuildContext context) {
    final currentLocale = context.locale.languageCode;
    
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                'language'.tr(),
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
            ),
            ..._languages.map((lang) {
              final isSelected = lang['code'] == currentLocale;
              
              return ListTile(
                leading: Text(
                  lang['flag'],
                  style: const TextStyle(fontSize: 24),
                ),
                title: Text(lang['name']),
                trailing: isSelected
                    ? const Icon(Icons.check, color: AppTheme.primaryColor)
                    : null,
                onTap: () {
                  context.setLocale(Locale(lang['code']));
                  Navigator.pop(context);
                },
              );
            }),
          ],
        ),
      ),
    );
  }
  
  void _showThemeSelector(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                'theme'.tr(),
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.brightness_auto),
              title: Text('system_default'.tr()),
              trailing: const Icon(Icons.check, color: AppTheme.primaryColor),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: const Icon(Icons.brightness_7),
              title: Text('light_mode'.tr()),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: const Icon(Icons.brightness_2),
              title: Text('dark_mode'.tr()),
              onTap: () => Navigator.pop(context),
            ),
          ],
        ),
      ),
    );
  }
  
  void _showClearCacheDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('clear_cache'.tr()),
        content: const Text('This will remove all cached data. Downloaded tracks will not be affected.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('cancel'.tr()),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('cache_cleared'.tr()),
                  backgroundColor: AppTheme.successColor,
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.errorColor,
            ),
            child: Text('delete'.tr()),
          ),
        ],
      ),
    );
  }
}
