import 'dart:io';
import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:file_picker/file_picker.dart';

import '../../../../core/theme/app_theme.dart';
import '../../../../core/services/supabase_service.dart';

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});

  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  final _supabaseService = SupabaseService();
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _artistController = TextEditingController();
  final _albumController = TextEditingController();
  
  File? _selectedFile;
  File? _coverFile;
  String? _selectedGenre;
  bool _isUploading = false;
  double _uploadProgress = 0;
  
  final List<String> _genres = [
    'pop', 'rock', 'hip_hop', 'electronic', 'jazz', 'classical',
    'rnb', 'country', 'metal', 'folk', 'blues', 'reggae',
    'latin', 'funk', 'soul', 'punk', 'indie', 'alternative',
    'dance', 'trap', 'lofi', 'ambient', 'soundtrack'
  ];

  @override
  void dispose() {
    _titleController.dispose();
    _artistController.dispose();
    _albumController.dispose();
    super.dispose();
  }
  
  Future<void> _pickAudioFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.audio,
      allowMultiple: false,
    );
    
    if (result != null && result.files.single.path != null) {
      setState(() {
        _selectedFile = File(result.files.single.path!);
      });
    }
  }
  
  Future<void> _pickCoverImage() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.image,
      allowMultiple: false,
    );
    
    if (result != null && result.files.single.path != null) {
      setState(() {
        _coverFile = File(result.files.single.path!);
      });
    }
  }
  
  Future<void> _uploadTrack() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedFile == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select an audio file'),
          backgroundColor: AppTheme.errorColor,
        ),
      );
      return;
    }
    
    setState(() {
      _isUploading = true;
      _uploadProgress = 0;
    });
    
    try {
      await _supabaseService.uploadTrack(
        file: _selectedFile!,
        title: _titleController.text.trim(),
        artist: _artistController.text.trim(),
        album: _albumController.text.trim().isEmpty
            ? null
            : _albumController.text.trim(),
        genre: _selectedGenre,
        coverFile: _coverFile,
      );
      
      setState(() {
        _isUploading = false;
        _uploadProgress = 1;
      });
      
      // Clear form
      _titleController.clear();
      _artistController.clear();
      _albumController.clear();
      setState(() {
        _selectedFile = null;
        _coverFile = null;
        _selectedGenre = null;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('upload_success'.tr()),
          backgroundColor: AppTheme.successColor,
        ),
      );
    } catch (e) {
      setState(() {
        _isUploading = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('upload_error'.tr()),
          backgroundColor: AppTheme.errorColor,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('admin'.tr()),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Admin header
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [AppTheme.primaryColor, AppTheme.secondaryColor],
                  ),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  children: [
                    const Icon(
                      Icons.admin_panel_settings,
                      color: Colors.white,
                      size: 48,
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Admin Panel',
                            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                          ),
                          Text(
                            'Upload and manage tracks',
                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                  color: Colors.white.withOpacity(0.8),
                                ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: 32),
              
              // Upload section
              Text(
                'upload_track'.tr(),
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              
              const SizedBox(height: 24),
              
              // File selection
              GestureDetector(
                onTap: _isUploading ? null : _pickAudioFile,
                child: Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Theme.of(context).cardColor,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: _selectedFile != null
                          ? AppTheme.successColor
                          : AppTheme.mutedText.withOpacity(0.3),
                      width: 2,
                    ),
                  ),
                  child: Column(
                    children: [
                      Icon(
                        _selectedFile != null
                            ? Icons.check_circle
                            : Icons.audio_file,
                        size: 48,
                        color: _selectedFile != null
                            ? AppTheme.successColor
                            : AppTheme.primaryColor,
                      ),
                      const SizedBox(height: 12),
                      Text(
                        _selectedFile != null
                            ? 'File selected: ${_selectedFile!.path.split('/').last}'
                            : 'select_file'.tr(),
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: _selectedFile != null
                                  ? AppTheme.successColor
                                  : AppTheme.mutedText,
                            ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ),
              
              const SizedBox(height: 24),
              
              // Title field
              TextFormField(
                controller: _titleController,
                enabled: !_isUploading,
                decoration: InputDecoration(
                  labelText: 'track_title'.tr(),
                  prefixIcon: const Icon(Icons.music_note),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter track title';
                  }
                  return null;
                },
              ),
              
              const SizedBox(height: 16),
              
              // Artist field
              TextFormField(
                controller: _artistController,
                enabled: !_isUploading,
                decoration: InputDecoration(
                  labelText: 'artist_name'.tr(),
                  prefixIcon: const Icon(Icons.person),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter artist name';
                  }
                  return null;
                },
              ),
              
              const SizedBox(height: 16),
              
              // Album field
              TextFormField(
                controller: _albumController,
                enabled: !_isUploading,
                decoration: InputDecoration(
                  labelText: 'album_name'.tr(),
                  prefixIcon: const Icon(Icons.album),
                ),
              ),
              
              const SizedBox(height: 16),
              
              // Genre dropdown
              DropdownButtonFormField<String>(
                value: _selectedGenre,
                enabled: !_isUploading,
                decoration: InputDecoration(
                  labelText: 'genre'.tr(),
                  prefixIcon: const Icon(Icons.category),
                ),
                items: _genres.map((genre) {
                  return DropdownMenuItem(
                    value: genre,
                    child: Text(genre.tr()),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedGenre = value;
                  });
                },
              ),
              
              const SizedBox(height: 24),
              
              // Cover image selection
              GestureDetector(
                onTap: _isUploading ? null : _pickCoverImage,
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Theme.of(context).cardColor,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: _coverFile != null
                          ? AppTheme.successColor
                          : AppTheme.mutedText.withOpacity(0.3),
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        _coverFile != null
                            ? Icons.check_circle
                            : Icons.image,
                        color: _coverFile != null
                            ? AppTheme.successColor
                            : AppTheme.primaryColor,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          _coverFile != null
                              ? 'Cover selected'
                              : 'Select cover image (optional)',
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                color: _coverFile != null
                                    ? AppTheme.successColor
                                    : AppTheme.mutedText,
                              ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              
              const SizedBox(height: 32),
              
              // Upload button
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: _isUploading ? null : _uploadTrack,
                  child: _isUploading
                      ? Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'uploading'.tr(),
                              style: const TextStyle(fontSize: 12),
                            ),
                          ],
                        )
                      : Text('upload'.tr()),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
