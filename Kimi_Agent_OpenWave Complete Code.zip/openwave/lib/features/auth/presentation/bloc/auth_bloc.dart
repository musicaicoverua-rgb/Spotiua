import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';

import '../../../../core/services/supabase_service.dart';
import '../../../../core/models/user_model.dart';

part 'auth_event.dart';
part 'auth_state.dart';

@injectable
class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final SupabaseService _supabaseService;
  
  AuthBloc(this._supabaseService) : super(AuthInitial()) {
    on<AuthCheckRequested>(_onAuthCheckRequested);
    on<AuthLoginRequested>(_onAuthLoginRequested);
    on<AuthRegisterRequested>(_onAuthRegisterRequested);
    on<AuthLogoutRequested>(_onAuthLogoutRequested);
    
    // Check auth status on init
    add(AuthCheckRequested());
  }
  
  Future<void> _onAuthCheckRequested(
    AuthCheckRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    
    try {
      final session = _supabaseService.currentSession;
      
      if (session != null) {
        final user = await _supabaseService.getCurrentUserProfile();
        emit(AuthAuthenticated(user: user));
      } else {
        emit(AuthUnauthenticated());
      }
    } catch (e) {
      emit(AuthUnauthenticated());
    }
  }
  
  Future<void> _onAuthLoginRequested(
    AuthLoginRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    
    try {
      await _supabaseService.signInWithEmail(
        event.email,
        event.password,
      );
      
      final user = await _supabaseService.getCurrentUserProfile();
      emit(AuthAuthenticated(user: user));
    } catch (e) {
      emit(AuthError(message: _getErrorMessage(e)));
      emit(AuthUnauthenticated());
    }
  }
  
  Future<void> _onAuthRegisterRequested(
    AuthRegisterRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    
    try {
      await _supabaseService.signUpWithEmail(
        event.email,
        event.password,
        username: event.username,
      );
      
      final user = await _supabaseService.getCurrentUserProfile();
      emit(AuthAuthenticated(user: user));
    } catch (e) {
      emit(AuthError(message: _getErrorMessage(e)));
      emit(AuthUnauthenticated());
    }
  }
  
  Future<void> _onAuthLogoutRequested(
    AuthLogoutRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    
    try {
      await _supabaseService.signOut();
      emit(AuthUnauthenticated());
    } catch (e) {
      emit(AuthError(message: _getErrorMessage(e)));
    }
  }
  
  String _getErrorMessage(dynamic error) {
    final message = error.toString().toLowerCase();
    
    if (message.contains('invalid login credentials')) {
      return 'Invalid email or password';
    } else if (message.contains('user already registered')) {
      return 'This email is already registered';
    } else if (message.contains('network')) {
      return 'Network error. Please check your connection';
    }
    
    return 'An error occurred. Please try again';
  }
}
