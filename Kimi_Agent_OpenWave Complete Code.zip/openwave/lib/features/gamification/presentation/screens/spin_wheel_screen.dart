import 'dart:math';
import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter_fortune_wheel/flutter_fortune_wheel.dart';
import 'package:confetti/confetti.dart';

import '../../../../core/theme/app_theme.dart';
import '../../../../core/services/supabase_service.dart';
import '../../../../core/models/reward_model.dart';

class SpinWheelScreen extends StatefulWidget {
  const SpinWheelScreen({super.key});

  @override
  State<SpinWheelScreen> createState() => _SpinWheelScreenState();
}

class _SpinWheelScreenState extends State<SpinWheelScreen> {
  final _supabaseService = SupabaseService();
  final _confettiController = ConfettiController(duration: const Duration(seconds: 3));
  
  List<SpinWheelRewardModel> _rewards = [];
  bool _isLoading = true;
  bool _isSpinning = false;
  int _selectedIndex = 0;
  int _userCoins = 0;
  static const int _spinCost = 10;
  
  @override
  void initState() {
    super.initState();
    _loadData();
  }
  
  @override
  void dispose() {
    _confettiController.dispose();
    super.dispose();
  }
  
  Future<void> _loadData() async {
    try {
      final rewards = await _supabaseService.getSpinWheelRewards();
      final profile = await _supabaseService.getCurrentUserProfile();
      
      setState(() {
        _rewards = rewards;
        _userCoins = profile?.coins ?? 0;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
    }
  }
  
  void _spin() {
    if (_userCoins < _spinCost) {
      _showInsufficientCoinsDialog();
      return;
    }
    
    setState(() {
      _isSpinning = true;
    });
    
    // Select random reward based on probability weights
    final random = Random();
    final totalWeight = _rewards.fold<int>(0, (sum, r) => sum + r.probabilityWeight);
    var randomValue = random.nextInt(totalWeight);
    
    int selectedIndex = 0;
    for (int i = 0; i < _rewards.length; i++) {
      randomValue -= _rewards[i].probabilityWeight;
      if (randomValue <= 0) {
        selectedIndex = i;
        break;
      }
    }
    
    setState(() {
      _selectedIndex = selectedIndex;
    });
    
    // Deduct coins
    setState(() {
      _userCoins -= _spinCost;
    });
  }
  
  void _onSpinComplete() async {
    final reward = _rewards[_selectedIndex];
    
    // Save reward to database
    await _supabaseService.claimSpinReward(reward);
    
    // Show confetti for big wins
    if (reward.value >= 50) {
      _confettiController.play();
    }
    
    // Show result dialog
    _showRewardDialog(reward);
    
    setState(() {
      _isSpinning = false;
    });
  }
  
  void _showRewardDialog(SpinWheelRewardModel reward) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text(
          'you_won'.tr(),
          textAlign: TextAlign.center,
          style: const TextStyle(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 16),
            Icon(
              _getRewardIcon(reward.rewardType),
              size: 64,
              color: _getRewardColor(reward.rewardType),
            ),
            const SizedBox(height: 16),
            Text(
              reward.name,
              style: Theme.of(context).textTheme.titleLarge,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              reward.displayValue,
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: _getRewardColor(reward.rewardType),
                  ),
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: Text('done'.tr()),
          ),
        ],
      ),
    );
  }
  
  void _showInsufficientCoinsDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('insufficient_coins'.tr()),
        content: Text('you_need_more_coins'.tr(args: {'coins': '10'})),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('cancel'.tr()),
          ),
        ],
      ),
    );
  }
  
  IconData _getRewardIcon(String type) {
    switch (type) {
      case 'coins':
        return Icons.monetization_on;
      case 'points':
        return Icons.emoji_events;
      case 'xp':
        return Icons.star;
      default:
        return Icons.card_giftcard;
    }
  }
  
  Color _getRewardColor(String type) {
    switch (type) {
      case 'coins':
        return AppTheme.coinsColor;
      case 'points':
        return AppTheme.pointsColor;
      case 'xp':
        return AppTheme.xpColor;
      default:
        return AppTheme.primaryColor;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('spin_wheel'.tr()),
      ),
      body: Stack(
        children: [
          if (_isLoading)
            const Center(child: CircularProgressIndicator())
          else
            Column(
              children: [
                // Coins display
                Container(
                  margin: const EdgeInsets.all(16),
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [AppTheme.coinsColor, Color(0xFFFFA000)],
                    ),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.monetization_on,
                        color: Colors.white,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        '$_userCoins',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                      ),
                    ],
                  ),
                ),
                
                // Spin cost
                Text(
                  'spin_cost'.tr(args: {'cost': _spinCost.toString()}),
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppTheme.mutedText,
                      ),
                ),
                
                const SizedBox(height: 24),
                
                // Wheel
                Expanded(
                  child: _rewards.isEmpty
                      ? const Center(child: Text('No rewards available'))
                      : FortuneWheel(
                          selected: Stream.value(_selectedIndex),
                          items: _rewards.map((reward) {
                            return FortuneItem(
                              child: Padding(
                                padding: const EdgeInsets.all(8),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      _getRewardIcon(reward.rewardType),
                                      color: Colors.white,
                                      size: 20,
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      reward.value.toString(),
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              style: FortuneItemStyle(
                                color: _getRewardColor(reward.rewardType),
                                borderColor: Colors.white,
                                borderWidth: 2,
                              ),
                            );
                          }).toList(),
                          onAnimationEnd: _onSpinComplete,
                          onFling: _spin,
                          physics: NoPanPhysics(),
                        ),
                ),
                
                const SizedBox(height: 24),
                
                // Spin button
                Padding(
                  padding: const EdgeInsets.all(24),
                  child: SizedBox(
                    width: double.infinity,
                    height: 56,
                    child: ElevatedButton(
                      onPressed: _isSpinning ? null : _spin,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.primaryColor,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                      child: _isSpinning
                          ? const SizedBox(
                              height: 24,
                              width: 24,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : Text(
                              'spin'.tr(),
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                    ),
                  ),
                ),
              ],
            ),
          
          // Confetti
          Align(
            alignment: Alignment.topCenter,
            child: ConfettiWidget(
              confettiController: _confettiController,
              blastDirectionality: BlastDirectionality.explosive,
              particleDrag: 0.05,
              emissionFrequency: 0.05,
              numberOfParticles: 50,
              gravity: 0.2,
              shouldLoop: false,
              colors: const [
                AppTheme.primaryColor,
                AppTheme.secondaryColor,
                AppTheme.accentColor,
                AppTheme.accentYellow,
                AppTheme.coinsColor,
              ],
            ),
          ),
        ],
      ),
    );
  }
}
