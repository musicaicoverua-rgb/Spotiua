import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:lottie/lottie.dart';

import '../../../../core/theme/app_theme.dart';
import '../../../../core/services/supabase_service.dart';

class DailyRewardScreen extends StatefulWidget {
  const DailyRewardScreen({super.key});

  @override
  State<DailyRewardScreen> createState() => _DailyRewardScreenState();
}

class _DailyRewardScreenState extends State<DailyRewardScreen>
    with SingleTickerProviderStateMixin {
  final _supabaseService = SupabaseService();
  
  bool _isLoading = true;
  bool _canClaim = false;
  bool _hasClaimed = false;
  int _streak = 0;
  int _hoursUntilNext = 0;
  
  late AnimationController _animationController;
  
  // Rewards for each day of streak
  final List<Map<String, dynamic>> _dailyRewards = [
    {'day': 1, 'coins': 5, 'points': 10, 'xp': 20},
    {'day': 2, 'coins': 10, 'points': 15, 'xp': 30},
    {'day': 3, 'coins': 15, 'points': 20, 'xp': 40},
    {'day': 4, 'coins': 20, 'points': 25, 'xp': 50},
    {'day': 5, 'coins': 30, 'points': 35, 'xp': 70},
    {'day': 6, 'coins': 40, 'points': 45, 'xp': 90},
    {'day': 7, 'coins': 100, 'points': 100, 'xp': 200, 'bonus': true},
  ];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _loadData();
  }
  
  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
  
  Future<void> _loadData() async {
    try {
      final profile = await _supabaseService.getCurrentUserProfile();
      
      setState(() {
        _streak = profile?.dailyStreak ?? 0;
        _canClaim = profile?.canClaimDailyReward ?? true;
        _hoursUntilNext = profile?.hoursUntilNextReward ?? 0;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
    }
  }
  
  Future<void> _claimReward() async {
    if (!_canClaim) return;
    
    setState(() {
      _hasClaimed = true;
    });
    
    _animationController.forward();
    
    try {
      await _supabaseService.claimDailyReward();
      
      // Show success
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('reward_claimed'.tr()),
          backgroundColor: AppTheme.successColor,
        ),
      );
      
      setState(() {
        _canClaim = false;
        _streak = (_streak % 7) + 1;
        _hoursUntilNext = 24;
      });
    } catch (e) {
      setState(() {
        _hasClaimed = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error claiming reward'),
          backgroundColor: AppTheme.errorColor,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('daily_reward'.tr()),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  // Header animation
                  if (_hasClaimed)
                    Lottie.asset(
                      'assets/animations/success.json',
                      height: 150,
                      repeat: false,
                      controller: _animationController,
                    )
                  else
                    Icon(
                      Icons.card_giftcard,
                      size: 100,
                      color: AppTheme.accentOrange,
                    ),
                  
                  const SizedBox(height: 24),
                  
                  // Title
                  Text(
                    'daily_reward'.tr(),
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  
                  const SizedBox(height: 8),
                  
                  // Streak info
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [AppTheme.accentOrange, AppTheme.accentYellow],
                      ),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.local_fire_department,
                          color: Colors.white,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          '$_streak Day Streak',
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ),
                  
                  const SizedBox(height: 32),
                  
                  // Calendar grid
                  _buildCalendarGrid(),
                  
                  const SizedBox(height: 32),
                  
                  // Claim button or timer
                  if (_canClaim && !_hasClaimed)
                    SizedBox(
                      width: double.infinity,
                      height: 56,
                      child: ElevatedButton(
                        onPressed: _claimReward,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.successColor,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                        child: Text(
                          'claim_reward'.tr(),
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    )
                  else
                    Container(
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        color: AppTheme.darkCard.withOpacity(0.5),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        children: [
                          Icon(
                            Icons.access_time,
                            size: 48,
                            color: AppTheme.mutedText,
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'come_back_tomorrow'.tr(),
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 8),
                          Text(
                            '$_hoursUntilNext hours remaining',
                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                  color: AppTheme.mutedText,
                                ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
    );
  }
  
  Widget _buildCalendarGrid() {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        childAspectRatio: 0.8,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemCount: _dailyRewards.length,
      itemBuilder: (context, index) {
        final reward = _dailyRewards[index];
        final day = reward['day'] as int;
        final isClaimed = day < _streak;
        final isCurrent = day == _streak && _canClaim;
        final isBonus = reward['bonus'] == true;
        
        return Container(
          decoration: BoxDecoration(
            gradient: isClaimed
                ? const LinearGradient(
                    colors: [AppTheme.successColor, Color(0xFF66BB6A)],
                  )
                : isCurrent
                    ? const LinearGradient(
                        colors: [AppTheme.accentOrange, AppTheme.accentYellow],
                      )
                    : null,
            color: isClaimed || isCurrent ? null : AppTheme.darkCard.withOpacity(0.5),
            borderRadius: BorderRadius.circular(12),
            border: isCurrent
                ? Border.all(color: AppTheme.accentOrange, width: 3)
                : isBonus && !isClaimed
                    ? Border.all(color: AppTheme.accentColor, width: 2)
                    : null,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Day $day',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: isClaimed || isCurrent ? Colors.white : AppTheme.mutedText,
                ),
              ),
              const SizedBox(height: 8),
              if (isClaimed)
                const Icon(Icons.check_circle, color: Colors.white)
              else ...[
                Icon(
                  Icons.monetization_on,
                  color: isCurrent ? Colors.white : AppTheme.coinsColor,
                  size: 16,
                ),
                Text(
                  '${reward['coins']}',
                  style: TextStyle(
                    fontSize: 12,
                    color: isCurrent ? Colors.white : AppTheme.mutedText,
                  ),
                ),
                if (isBonus) ...[
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                    decoration: BoxDecoration(
                      color: AppTheme.accentColor,
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: const Text(
                      'BONUS',
                      style: TextStyle(
                        fontSize: 8,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ],
            ],
          ),
        );
      },
    );
  }
}
