import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';

import '../../../../core/theme/app_theme.dart';
import '../../../../core/services/supabase_service.dart';
import '../../../../core/models/reward_model.dart';

class AchievementsScreen extends StatefulWidget {
  const AchievementsScreen({super.key});

  @override
  State<AchievementsScreen> createState() => _AchievementsScreenState();
}

class _AchievementsScreenState extends State<AchievementsScreen> {
  final _supabaseService = SupabaseService();
  
  List<AchievementModel> _achievements = [];
  bool _isLoading = true;
  int _unlockedCount = 0;

  @override
  void initState() {
    super.initState();
    _loadAchievements();
  }
  
  Future<void> _loadAchievements() async {
    try {
      final achievements = await _supabaseService.getAchievements();
      
      setState(() {
        _achievements = achievements;
        _unlockedCount = achievements.where((a) => a.isUnlocked).length;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('achievements'.tr()),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                // Progress header
                Container(
                  margin: const EdgeInsets.all(16),
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [AppTheme.primaryColor, AppTheme.secondaryColor],
                    ),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.emoji_events,
                            color: Colors.white,
                            size: 48,
                          ),
                          const SizedBox(width: 16),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '$_unlockedCount / ${_achievements.length}',
                                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                    ),
                              ),
                              Text(
                                'achievements'.tr(),
                                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                                      color: Colors.white.withOpacity(0.8),
                                    ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: LinearProgressIndicator(
                          value: _achievements.isEmpty
                              ? 0
                              : _unlockedCount / _achievements.length,
                          backgroundColor: Colors.white.withOpacity(0.2),
                          valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
                          minHeight: 8,
                        ),
                      ),
                    ],
                  ),
                ),
                
                // Achievements list
                Expanded(
                  child: _achievements.isEmpty
                      ? Center(
                          child: Text(
                            'No achievements available',
                            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                                  color: AppTheme.mutedText,
                                ),
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          itemCount: _achievements.length,
                          itemBuilder: (context, index) {
                            final achievement = _achievements[index];
                            return _buildAchievementCard(achievement);
                          },
                        ),
                ),
              ],
            ),
    );
  }
  
  Widget _buildAchievementCard(AchievementModel achievement) {
    final isUnlocked = achievement.isUnlocked;
    
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isUnlocked
            ? AppTheme.successColor.withOpacity(0.1)
            : Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(16),
        border: isUnlocked
            ? Border.all(color: AppTheme.successColor.withOpacity(0.3))
            : null,
      ),
      child: Row(
        children: [
          // Icon
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              gradient: isUnlocked
                  ? const LinearGradient(
                      colors: [AppTheme.successColor, Color(0xFF66BB6A)],
                    )
                  : const LinearGradient(
                      colors: [AppTheme.darkCard, AppTheme.mutedText],
                    ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(
              isUnlocked ? Icons.emoji_events : Icons.lock,
              color: Colors.white,
              size: 32,
            ),
          ),
          
          const SizedBox(width: 16),
          
          // Info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        achievement.name,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                              color: isUnlocked ? null : AppTheme.mutedText,
                            ),
                      ),
                    ),
                    if (isUnlocked)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppTheme.successColor,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          'unlocked'.tr(),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      )
                    else
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppTheme.darkCard,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          'locked'.tr(),
                          style: const TextStyle(
                            color: AppTheme.mutedText,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  achievement.description ?? '',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: AppTheme.mutedText,
                      ),
                ),
                const SizedBox(height: 8),
                
                // Progress bar
                if (!isUnlocked) ...[
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: achievement.progressPercent,
                      backgroundColor: AppTheme.darkCard,
                      valueColor: const AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),
                      minHeight: 6,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    achievement.progressText,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: AppTheme.mutedText,
                          fontSize: 10,
                        ),
                  ),
                ],
                
                // Rewards
                if (achievement.pointsReward > 0 || achievement.coinsReward > 0) ...[
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      if (achievement.pointsReward > 0) ...[
                        Icon(
                          Icons.emoji_events,
                          size: 14,
                          color: AppTheme.pointsColor,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '+${achievement.pointsReward}',
                          style: TextStyle(
                            fontSize: 12,
                            color: AppTheme.pointsColor,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(width: 12),
                      ],
                      if (achievement.coinsReward > 0) ...[
                        Icon(
                          Icons.monetization_on,
                          size: 14,
                          color: AppTheme.coinsColor,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '+${achievement.coinsReward}',
                          style: TextStyle(
                            fontSize: 12,
                            color: AppTheme.coinsColor,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ],
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
