import UIKit
import Flutter
import AVFoundation

@UIApplicationMain
@objc class AppDelegate: FlutterAppDelegate {
    private var audioChannel: FlutterMethodChannel?
    
    override func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        let controller = window?.rootViewController as! FlutterViewController
        audioChannel = FlutterMethodChannel(
            name: "com.openwave.app/audio",
            binaryMessenger: controller.binaryMessenger
        )
        
        audioChannel?.setMethodCallHandler { [weak self] call, result in
            switch call.method {
            case "createNotificationChannel":
                self?.setupAudioSession()
                result(true)
            case "requestAudioFocus":
                self?.requestAudioFocus(result: result)
            case "abandonAudioFocus":
                self?.abandonAudioFocus(result: result)
            case "configureAudioSession":
                self?.setupAudioSession()
                result(true)
            default:
                result(FlutterMethodNotImplemented)
            }
        }
        
        // Configure audio session for background playback
        setupAudioSession()
        
        GeneratedPluginRegistrant.register(with: self)
        return super.application(application, didFinishLaunchingWithOptions: launchOptions)
    }
    
    private func setupAudioSession() {
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default, options: [.allowAirPlay, .allowBluetooth])
            try session.setActive(true)
        } catch {
            print("Failed to set up audio session: \(error)")
        }
    }
    
    private func requestAudioFocus(result: @escaping FlutterResult) {
        do {
            try AVAudioSession.sharedInstance().setActive(true)
            result(true)
        } catch {
            result(FlutterError(code: "AUDIO_FOCUS_ERROR", message: error.localizedDescription, details: nil))
        }
    }
    
    private func abandonAudioFocus(result: @escaping FlutterResult) {
        do {
            try AVAudioSession.sharedInstance().setActive(false)
            result(true)
        } catch {
            result(FlutterError(code: "AUDIO_FOCUS_ERROR", message: error.localizedDescription, details: nil))
        }
    }
    
    override func applicationDidBecomeActive(_ application: UIApplication) {
        super.applicationDidBecomeActive(application)
        setupAudioSession()
    }
}
