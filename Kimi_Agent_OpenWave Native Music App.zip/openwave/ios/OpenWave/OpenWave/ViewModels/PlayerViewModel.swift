import Foundation
import Combine

@MainActor
class PlayerViewModel: ObservableObject {
    @Published var currentTrack: Track?
    @Published var isPlaying: Bool = false
    @Published var currentTime: TimeInterval = 0
    @Published var duration: TimeInterval = 0
    @Published var playbackState: AudioPlayerService.PlaybackState = .idle
    @Published var queue: [Track] = []
    @Published var currentIndex: Int = 0
    @Published var shuffleEnabled: Bool = false
    @Published var repeatMode: RepeatMode = .off
    
    enum RepeatMode: Int {
        case off = 0
        case all = 1
        case one = 2
    }
    
    private let audioService = AudioPlayerService.shared
    private var cancellables = Set<AnyCancellable>()
    
    init() {
        setupBindings()
    }
    
    private func setupBindings() {
        audioService.$currentTrack
            .receive(on: DispatchQueue.main)
            .assign(to: &$currentTrack)
        
        audioService.$isPlaying
            .receive(on: DispatchQueue.main)
            .assign(to: &$isPlaying)
        
        audioService.$currentTime
            .receive(on: DispatchQueue.main)
            .assign(to: &$currentTime)
        
        audioService.$duration
            .receive(on: DispatchQueue.main)
            .assign(to: &$duration)
        
        audioService.$playbackState
            .receive(on: DispatchQueue.main)
            .assign(to: &$playbackState)
    }
    
    func playTrack(_ track: Track, tracks: [Track] = []) {
        audioService.playTrack(track, playlist: tracks.isEmpty ? [track] : tracks)
        queue = tracks.isEmpty ? [track] : tracks
        currentIndex = queue.firstIndex(where: { $0.id == track.id }) ?? 0
    }
    
    func togglePlayPause() {
        audioService.togglePlayPause()
    }
    
    func play() {
        audioService.play()
    }
    
    func pause() {
        audioService.pause()
    }
    
    func playNext() {
        audioService.playNext()
        updateCurrentTrack()
    }
    
    func playPrevious() {
        audioService.playPrevious()
        updateCurrentTrack()
    }
    
    func seekTo(_ position: TimeInterval) {
        audioService.seek(to: position)
    }
    
    func skipForward() {
        audioService.skipForward()
    }
    
    func skipBackward() {
        audioService.skipBackward()
    }
    
    func toggleShuffle() {
        shuffleEnabled.toggle()
        // Implementation for shuffle
    }
    
    func cycleRepeatMode() {
        switch repeatMode {
        case .off:
            repeatMode = .all
        case .all:
            repeatMode = .one
        case .one:
            repeatMode = .off
        }
        audioService.player?.actionAtItemEnd = repeatMode == .one ? .none : .advance
    }
    
    func addToQueue(_ track: Track) {
        audioService.addToQueue(track)
        queue = audioService.getQueue()
    }
    
    func clearQueue() {
        audioService.clearQueue()
        queue = []
    }
    
    private func updateCurrentTrack() {
        currentTrack = audioService.currentTrack
        currentIndex = audioService.getQueue().firstIndex(where: { $0.id == currentTrack?.id }) ?? 0
    }
    
    func formatTime(_ time: TimeInterval) -> String {
        let minutes = Int(time) / 60
        let seconds = Int(time) % 60
        return String(format: "%d:%02d", minutes, seconds)
    }
}
