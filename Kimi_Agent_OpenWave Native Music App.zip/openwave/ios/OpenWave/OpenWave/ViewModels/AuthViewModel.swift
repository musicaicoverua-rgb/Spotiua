import Foundation
import Combine

@MainActor
class AuthViewModel: ObservableObject {
    @Published var authState: AuthState = .initial
    @Published var currentUser: User?
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?
    
    enum AuthState {
        case initial
        case loading
        case authenticated
        case adminAuthenticated
        case unauthenticated
        case error(String)
    }
    
    private var cancellables = Set<AnyCancellable>()
    
    init() {
        checkAuthState()
    }
    
    func checkAuthState() {
        Task {
            isLoading = true
            defer { isLoading = false }
            
            do {
                if SupabaseService.shared.isAuthenticated {
                    let user = try await SupabaseService.shared.currentUser
                    currentUser = user
                    authState = user?.isAdmin == true ? .adminAuthenticated : .authenticated
                } else {
                    authState = .unauthenticated
                }
            } catch {
                authState = .unauthenticated
                errorMessage = error.localizedDescription
            }
        }
    }
    
    func signIn(email: String, password: String) {
        Task {
            isLoading = true
            errorMessage = nil
            
            do {
                let user = try await SupabaseService.shared.signIn(email: email, password: password)
                currentUser = user
                authState = .authenticated
            } catch {
                errorMessage = error.localizedDescription
                authState = .error(error.localizedDescription)
            }
            
            isLoading = false
        }
    }
    
    func adminSignIn(email: String, password: String) {
        Task {
            isLoading = true
            errorMessage = nil
            
            do {
                let user = try await SupabaseService.shared.adminSignIn(email: email, password: password)
                currentUser = user
                authState = .adminAuthenticated
            } catch {
                errorMessage = error.localizedDescription
                authState = .error(error.localizedDescription)
            }
            
            isLoading = false
        }
    }
    
    func signUp(email: String, password: String, username: String?) {
        Task {
            isLoading = true
            errorMessage = nil
            
            do {
                let user = try await SupabaseService.shared.signUp(email: email, password: password, username: username)
                currentUser = user
                authState = .authenticated
            } catch {
                errorMessage = error.localizedDescription
                authState = .error(error.localizedDescription)
            }
            
            isLoading = false
        }
    }
    
    func signOut() {
        Task {
            isLoading = true
            
            do {
                try await SupabaseService.shared.signOut()
                currentUser = nil
                authState = .unauthenticated
            } catch {
                errorMessage = error.localizedDescription
            }
            
            isLoading = false
        }
    }
    
    func updateProfile(user: User) {
        Task {
            // Implementation
        }
    }
    
    func clearError() {
        errorMessage = nil
    }
}
