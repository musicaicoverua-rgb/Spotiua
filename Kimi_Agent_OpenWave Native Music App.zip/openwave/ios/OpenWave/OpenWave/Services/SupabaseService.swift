import Foundation
import Supabase
import Realtime

class SupabaseService {
    static let shared = SupabaseService()
    
    let client: SupabaseClient
    
    private init() {
        client = SupabaseClient(
            supabaseURL: URL(string: "YOUR_SUPABASE_URL")!,
            supabaseKey: "YOUR_SUPABASE_ANON_KEY"
        )
    }
    
    // MARK: - Auth
    
    var currentUser: User? {
        get async throws {
            let session = try await client.auth.session
            guard let userId = session.user?.id else { return nil }
            return try await getUserProfile(userId: userId)
        }
    }
    
    var isAuthenticated: Bool {
        client.auth.currentSession != nil
    }
    
    func signUp(email: String, password: String, username: String?) async throws -> User {
        let authResponse = try await client.auth.signUp(
            email: email,
            password: password
        )
        
        guard let userId = authResponse.user?.id else {
            throw AuthError.signUpFailed
        }
        
        let newUser = User(
            id: userId,
            email: email,
            username: username,
            role: .user,
            points: 0,
            coins: 0,
            level: 1,
            totalListeningTime: 0
        )
        
        try await client.database
            .from("users")
            .insert(newUser)
            .execute()
        
        return newUser
    }
    
    func signIn(email: String, password: String) async throws -> User {
        let session = try await client.auth.signIn(
            email: email,
            password: password
        )
        
        guard let userId = session.user?.id else {
            throw AuthError.signInFailed
        }
        
        return try await getUserProfile(userId: userId)
    }
    
    func adminSignIn(email: String, password: String) async throws -> User {
        let user = try await signIn(email: email, password: password)
        
        guard user.isAdmin else {
            try await signOut()
            throw AuthError.notAdmin
        }
        
        return user
    }
    
    func signOut() async throws {
        try await client.auth.signOut()
    }
    
    func getUserProfile(userId: UUID) async throws -> User {
        let response = try await client.database
            .from("users")
            .select()
            .eq("id", value: userId)
            .single()
            .execute()
        
        return try JSONDecoder().decode(User.self, from: response.data)
    }
    
    // MARK: - Tracks
    
    func getTracks(page: Int = 0, pageSize: Int = 20) async throws -> [Track] {
        let response = try await client.database
            .from("tracks")
            .select()
            .order("created_at", ascending: false)
            .range(from: page * pageSize, to: (page + 1) * pageSize - 1)
            .execute()
        
        return try JSONDecoder().decode([Track].self, from: response.data)
    }
    
    func searchTracks(query: String) async throws -> [Track] {
        let response = try await client.database
            .from("tracks")
            .select()
            .or("title.ilike.%\(query)%,artist.ilike.%\(query)%")
            .order("plays", ascending: false)
            .limit(50)
            .execute()
        
        return try JSONDecoder().decode([Track].self, from: response.data)
    }
    
    func getTrendingTracks(limit: Int = 20) async throws -> [Track] {
        let response = try await client.database
            .from("tracks")
            .select()
            .order("plays", ascending: false)
            .limit(limit)
            .execute()
        
        return try JSONDecoder().decode([Track].self, from: response.data)
    }
    
    func getNewReleases(limit: Int = 20) async throws -> [Track] {
        let response = try await client.database
            .from("tracks")
            .select()
            .order("created_at", ascending: false)
            .limit(limit)
            .execute()
        
        return try JSONDecoder().decode([Track].self, from: response.data)
    }
    
    func incrementPlays(trackId: UUID) async throws {
        try await client.database
            .rpc("increment_track_plays", params: ["track_uuid": trackId])
            .execute()
    }
    
    // MARK: - Playlists
    
    func getUserPlaylists(userId: UUID) async throws -> [Playlist] {
        let response = try await client.database
            .from("playlists")
            .select()
            .eq("user_id", value: userId)
            .order("created_at", ascending: false)
            .execute()
        
        return try JSONDecoder().decode([Playlist].self, from: response.data)
    }
    
    func createPlaylist(name: String, description: String?, userId: UUID) async throws -> Playlist {
        let playlist = Playlist(
            id: UUID(),
            name: name,
            description: description,
            userId: userId,
            isPublic: true
        )
        
        let response = try await client.database
            .from("playlists")
            .insert(playlist)
            .select()
            .single()
            .execute()
        
        return try JSONDecoder().decode(Playlist.self, from: response.data)
    }
    
    // MARK: - Likes
    
    func getLikedTracks(userId: UUID) async throws -> [Track] {
        let response = try await client.database
            .from("likes")
            .select("tracks(*)")
            .eq("user_id", value: userId)
            .order("created_at", ascending: false)
            .execute()
        
        return try JSONDecoder().decode([Track].self, from: response.data)
    }
    
    func likeTrack(userId: UUID, trackId: UUID) async throws {
        let like = Like(id: UUID(), userId: userId, trackId: trackId)
        
        try await client.database
            .from("likes")
            .insert(like)
            .execute()
    }
    
    func unlikeTrack(userId: UUID, trackId: UUID) async throws {
        try await client.database
            .from("likes")
            .delete()
            .eq("user_id", value: userId)
            .eq("track_id", value: trackId)
            .execute()
    }
    
    // MARK: - Gamification
    
    func claimDailyReward(userId: UUID) async throws -> DailyRewardResult {
        let response = try await client.database
            .rpc("claim_daily_reward", params: ["user_uuid": userId])
            .execute()
        
        let json = try JSONSerialization.jsonObject(with: response.data) as? [String: Any]
        
        guard json?["success"] as? Bool == true else {
            let message = json?["message"] as? String ?? "Already claimed"
            throw GamificationError.claimFailed(message)
        }
        
        let points = json?["points"] as? Int ?? 20
        let coins = json?["coins"] as? Int ?? 10
        
        return DailyRewardResult(points: points, coins: coins)
    }
    
    func spinBonusWheel(userId: UUID) async throws -> WheelSpinResult {
        let response = try await client.database
            .rpc("spin_bonus_wheel", params: ["user_uuid": userId])
            .execute()
        
        let json = try JSONSerialization.jsonObject(with: response.data) as? [String: Any]
        
        guard json?["success"] as? Bool == true else {
            let message = json?["message"] as? String ?? "Already spun"
            throw GamificationError.spinFailed(message)
        }
        
        let type = json?["type"] as? String ?? "points"
        let amount = json?["amount"] as? Int ?? 0
        
        return WheelSpinResult(rewardType: RewardType(rawValue: type) ?? .points, amount: amount)
    }
    
    func getLeaderboardByPoints(limit: Int = 100) async throws -> [LeaderboardEntry] {
        let response = try await client.database
            .from("users")
            .select("id, username, avatar_url, points, level")
            .eq("role", value: "user")
            .order("points", ascending: false)
            .limit(limit)
            .execute()
        
        var entries = try JSONDecoder().decode([LeaderboardEntry].self, from: response.data)
        for (index, _) in entries.enumerated() {
            entries[index].rank = Int64(index + 1)
        }
        return entries
    }
    
    func getLeaderboardByListeningTime(limit: Int = 100) async throws -> [LeaderboardEntry] {
        let response = try await client.database
            .from("users")
            .select("id, username, avatar_url, total_listening_time, level")
            .eq("role", value: "user")
            .order("total_listening_time", ascending: false)
            .limit(limit)
            .execute()
        
        var entries = try JSONDecoder().decode([LeaderboardEntry].self, from: response.data)
        for (index, _) in entries.enumerated() {
            entries[index].rank = Int64(index + 1)
        }
        return entries
    }
    
    // MARK: - Messages
    
    func getUserMessages(userId: UUID) async throws -> [Message] {
        let response = try await client.database
            .from("messages")
            .select()
            .eq("user_id", value: userId)
            .order("created_at", ascending: true)
            .execute()
        
        return try JSONDecoder().decode([Message].self, from: response.data)
    }
    
    func sendMessage(userId: UUID, message: String) async throws -> Message {
        let newMessage = Message(
            id: UUID(),
            userId: userId,
            message: message,
            isRead: false
        )
        
        let response = try await client.database
            .from("messages")
            .insert(newMessage)
            .select()
            .single()
            .execute()
        
        return try JSONDecoder().decode(Message.self, from: response.data)
    }
    
    // MARK: - Realtime
    
    func subscribeToMessages(userId: UUID) async throws -> RealtimeChannel {
        let channel = client.realtime.channel("messages") {
            Table(name: "messages", schema: "public") {
                Filter(column: "user_id", operator: .eq, value: userId.uuidString)
            }
        }
        
        await channel.subscribe()
        return channel
    }
}

// MARK: - Errors

enum AuthError: Error {
    case signUpFailed
    case signInFailed
    case notAdmin
}

enum GamificationError: Error {
    case claimFailed(String)
    case spinFailed(String)
}

// MARK: - Result Types

struct DailyRewardResult {
    let points: Int
    let coins: Int
}

struct WheelSpinResult {
    let rewardType: RewardType
    let amount: Int
}

enum RewardType: String, Codable {
    case points
    case coins
    case xp
}

struct LeaderboardEntry: Codable {
    var rank: Int64
    let userId: UUID
    let username: String?
    let avatarUrl: String?
    let points: Int?
    let totalListeningTime: Int?
    let level: Int
    
    enum CodingKeys: String, CodingKey {
        case rank
        case userId = "user_id"
        case username
        case avatarUrl = "avatar_url"
        case points
        case totalListeningTime = "total_listening_time"
        case level
    }
}

struct Message: Identifiable, Codable {
    let id: UUID
    let userId: UUID
    let message: String
    var reply: String?
    var isRead: Bool
    var repliedBy: UUID?
    var repliedAt: Date?
    var createdAt: Date?
    
    enum CodingKeys: String, CodingKey {
        case id
        case userId = "user_id"
        case message
        case reply
        case isRead = "is_read"
        case repliedBy = "replied_by"
        case repliedAt = "replied_at"
        case createdAt = "created_at"
    }
    
    var hasReply: Bool {
        reply != nil && !reply!.isEmpty
    }
}
