import Foundation
import AVFoundation
import Combine
import MediaPlayer

class AudioPlayerService: ObservableObject {
    static let shared = AudioPlayerService()
    
    private var player: AVPlayer?
    private var playerItem: AVPlayerItem?
    private var timeObserver: Any?
    
    @Published var currentTrack: Track?
    @Published var isPlaying: Bool = false
    @Published var currentTime: TimeInterval = 0
    @Published var duration: TimeInterval = 0
    @Published var playbackState: PlaybackState = .idle
    
    private var playlist: [Track] = []
    private var currentIndex: Int = 0
    
    private var cancellables = Set<AnyCancellable>()
    
    enum PlaybackState {
        case idle
        case loading
        case playing
        case paused
        case error(Error)
    }
    
    private init() {
        setupAudioSession()
        setupRemoteTransportControls()
        setupNotifications()
    }
    
    private func setupAudioSession() {
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default, options: [.allowAirPlay, .allowBluetooth])
            try session.setActive(true)
        } catch {
            print("Failed to setup audio session: \(error)")
        }
    }
    
    private func setupRemoteTransportControls() {
        let commandCenter = MPRemoteCommandCenter.shared()
        
        commandCenter.playCommand.addTarget { [weak self] _ in
            self?.play()
            return .success
        }
        
        commandCenter.pauseCommand.addTarget { [weak self] _ in
            self?.pause()
            return .success
        }
        
        commandCenter.nextTrackCommand.addTarget { [weak self] _ in
            self?.playNext()
            return .success
        }
        
        commandCenter.previousTrackCommand.addTarget { [weak self] _ in
            self?.playPrevious()
            return .success
        }
        
        commandCenter.changePlaybackPositionCommand.addTarget { [weak self] event in
            if let positionEvent = event as? MPChangePlaybackPositionCommandEvent {
                self?.seek(to: positionEvent.positionTime)
            }
            return .success
        }
    }
    
    private func setupNotifications() {
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(playerItemDidReachEnd),
            name: .AVPlayerItemDidPlayToEndTime,
            object: nil
        )
    }
    
    @objc private func playerItemDidReachEnd() {
        playNext()
    }
    
    private func updateNowPlayingInfo() {
        guard let track = currentTrack else { return }
        
        var nowPlayingInfo: [String: Any] = [
            MPMediaItemPropertyTitle: track.title,
            MPMediaItemPropertyArtist: track.artist,
            MPMediaItemPropertyPlaybackDuration: duration,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: currentTime,
            MPNowPlayingInfoPropertyPlaybackRate: isPlaying ? 1.0 : 0.0
        ]
        
        if let coverUrl = track.coverUrl,
           let url = URL(string: coverUrl) {
            // Load artwork asynchronously
            URLSession.shared.dataTask(with: url) { data, _, _ in
                if let data = data, let image = UIImage(data: data) {
                    let artwork = MPMediaItemArtwork(boundsSize: image.size) { _ in image }
                    nowPlayingInfo[MPMediaItemPropertyArtwork] = artwork
                    MPNowPlayingInfoCenter.default().nowPlayingInfo = nowPlayingInfo
                }
            }.resume()
        }
        
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nowPlayingInfo
    }
    
    // MARK: - Playback Control
    
    func playTrack(_ track: Track, playlist: [Track] = []) {
        self.playlist = playlist.isEmpty ? [track] : playlist
        self.currentIndex = self.playlist.firstIndex(where: { $0.id == track.id }) ?? 0
        self.currentTrack = track
        
        loadAndPlay(track: track)
    }
    
    private func loadAndPlay(track: Track) {
        playbackState = .loading
        
        guard let url = URL(string: track.bestAudioUrl) else {
            playbackState = .error(AudioPlayerError.invalidURL)
            return
        }
        
        playerItem = AVPlayerItem(url: url)
        player = AVPlayer(playerItem: playerItem)
        
        // Observe duration
        playerItem?.publisher(for: \.duration)
            .sink { [weak self] duration in
                if duration.isFinite && duration > 0 {
                    self?.duration = duration
                }
            }
            .store(in: &cancellables)
        
        // Observe status
        playerItem?.publisher(for: \.status)
            .sink { [weak self] status in
                switch status {
                case .readyToPlay:
                    self?.playbackState = .playing
                    self?.isPlaying = true
                    self?.updateNowPlayingInfo()
                case .failed:
                    self?.playbackState = .error(AudioPlayerError.playbackFailed)
                default:
                    break
                }
            }
            .store(in: &cancellables)
        
        // Time observer
        let interval = CMTime(seconds: 1, preferredTimescale: CMTimeScale(NSEC_PER_SEC))
        timeObserver = player?.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak self] time in
            self?.currentTime = time.seconds
            self?.updateNowPlayingInfo()
        }
        
        player?.play()
    }
    
    func play() {
        player?.play()
        isPlaying = true
        playbackState = .playing
        updateNowPlayingInfo()
    }
    
    func pause() {
        player?.pause()
        isPlaying = false
        playbackState = .paused
        updateNowPlayingInfo()
    }
    
    func togglePlayPause() {
        if isPlaying {
            pause()
        } else {
            play()
        }
    }
    
    func playNext() {
        guard !playlist.isEmpty else { return }
        
        currentIndex = (currentIndex + 1) % playlist.count
        let nextTrack = playlist[currentIndex]
        currentTrack = nextTrack
        loadAndPlay(track: nextTrack)
    }
    
    func playPrevious() {
        guard !playlist.isEmpty else { return }
        
        currentIndex = currentIndex > 0 ? currentIndex - 1 : playlist.count - 1
        let previousTrack = playlist[currentIndex]
        currentTrack = previousTrack
        loadAndPlay(track: previousTrack)
    }
    
    func seek(to time: TimeInterval) {
        let cmTime = CMTime(seconds: time, preferredTimescale: CMTimeScale(NSEC_PER_SEC))
        player?.seek(to: cmTime)
        currentTime = time
    }
    
    func skipForward(seconds: TimeInterval = 10) {
        let newTime = min(currentTime + seconds, duration)
        seek(to: newTime)
    }
    
    func skipBackward(seconds: TimeInterval = 10) {
        let newTime = max(currentTime - seconds, 0)
        seek(to: newTime)
    }
    
    func stop() {
        player?.pause()
        player = nil
        playerItem = nil
        currentTrack = nil
        isPlaying = false
        currentTime = 0
        duration = 0
        playbackState = .idle
        
        if let observer = timeObserver {
            player?.removeTimeObserver(observer)
            timeObserver = nil
        }
    }
    
    // MARK: - Queue Management
    
    func addToQueue(_ track: Track) {
        playlist.append(track)
    }
    
    func clearQueue() {
        playlist.removeAll()
        currentIndex = 0
    }
    
    func getQueue() -> [Track] {
        return playlist
    }
}

enum AudioPlayerError: Error {
    case invalidURL
    case playbackFailed
    case networkError
}

// MARK: - Audio Session Manager

class AudioSessionManager {
    static let shared = AudioSessionManager()
    
    func configure() {
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default, options: [.allowAirPlay, .allowBluetooth])
            try session.setActive(true)
        } catch {
            print("Failed to configure audio session: \(error)")
        }
    }
}
