import SwiftUI

struct ContentView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @EnvironmentObject var playerViewModel: PlayerViewModel
    
    var body: some View {
        Group {
            switch authViewModel.authState {
            case .initial, .loading:
                SplashScreen()
            
            case .authenticated:
                MainTabView()
            
            case .adminAuthenticated:
                AdminTabView()
            
            case .unauthenticated, .error:
                LoginView()
            }
        }
    }
}

struct SplashScreen: View {
    var body: some View {
        ZStack {
            Color(.systemBackground)
                .ignoresSafeArea()
            
            VStack {
                Image(systemName: "waveform")
                    .font(.system(size: 80))
                    .foregroundColor(.green)
                
                Text("OpenWave")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.top)
                
                ProgressView()
                    .padding(.top, 20)
            }
        }
    }
}

struct MainTabView: View {
    @EnvironmentObject var playerViewModel: PlayerViewModel
    
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Label(NSLocalizedString("home", comment: ""), systemImage: "house")
                }
            
            SearchView()
                .tabItem {
                    Label(NSLocalizedString("search", comment: ""), systemImage: "magnifyingglass")
                }
            
            LibraryView()
                .tabItem {
                    Label(NSLocalizedString("library", comment: ""), systemImage: "music.note.list")
                }
            
            LeaderboardView()
                .tabItem {
                    Label(NSLocalizedString("leaderboard", comment: ""), systemImage: "trophy")
                }
            
            RadioView()
                .tabItem {
                    Label(NSLocalizedString("radio", comment: ""), systemImage: "radio")
                }
            
            SpinView()
                .tabItem {
                    Label(NSLocalizedString("spin", comment: ""), systemImage: "dice")
                }
            
            SupportView()
                .tabItem {
                    Label(NSLocalizedString("support", comment: ""), systemImage: "message")
                }
        }
        .accentColor(.green)
    }
}

struct AdminTabView: View {
    var body: some View {
        TabView {
            AdminDashboardView()
                .tabItem {
                    Label("Dashboard", systemImage: "chart.bar")
                }
            
            AdminUploadView()
                .tabItem {
                    Label("Upload", systemImage: "cloud.upload")
                }
            
            AdminTracksView()
                .tabItem {
                    Label("Tracks", systemImage: "music.note")
                }
            
            AdminAnalyticsView()
                .tabItem {
                    Label("Analytics", systemImage: "chart.pie")
                }
            
            AdminMessagesView()
                .tabItem {
                    Label("Messages", systemImage: "envelope")
                }
        }
        .accentColor(.green)
    }
}

// Placeholder Views
struct SearchView: View {
    var body: some View {
        Text("Search")
    }
}

struct LibraryView: View {
    var body: some View {
        Text("Library")
    }
}

struct LeaderboardView: View {
    var body: some View {
        Text("Leaderboard")
    }
}

struct RadioView: View {
    var body: some View {
        Text("Radio")
    }
}

struct SpinView: View {
    var body: some View {
        Text("Spin")
    }
}

struct SupportView: View {
    var body: some View {
        Text("Support")
    }
}

struct AdminDashboardView: View {
    var body: some View {
        Text("Admin Dashboard")
    }
}

struct AdminUploadView: View {
    var body: some View {
        Text("Admin Upload")
    }
}

struct AdminTracksView: View {
    var body: some View {
        Text("Admin Tracks")
    }
}

struct AdminAnalyticsView: View {
    var body: some View {
        Text("Admin Analytics")
    }
}

struct AdminMessagesView: View {
    var body: some View {
        Text("Admin Messages")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(AuthViewModel())
            .environmentObject(PlayerViewModel())
    }
}
