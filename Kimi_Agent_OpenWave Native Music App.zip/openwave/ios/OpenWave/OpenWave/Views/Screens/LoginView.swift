import SwiftUI

struct LoginView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @State private var email = ""
    @State private var password = ""
    @State private var showingRegister = false
    @State private var showingAdminLogin = false
    
    var body: some View {
        NavigationView {
            ZStack {
                Color(.systemBackground)
                    .ignoresSafeArea()
                
                VStack(spacing: 24) {
                    // Logo
                    VStack(spacing: 16) {
                        Image(systemName: "waveform")
                            .font(.system(size: 80))
                            .foregroundColor(.green)
                        
                        Text("OpenWave")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                        
                        Text(NSLocalizedString("tagline", comment: ""))
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    .padding(.top, 60)
                    
                    Spacer()
                    
                    // Form
                    VStack(spacing: 16) {
                        TextField(NSLocalizedString("email", comment: ""), text: $email)
                            .textContentType(.emailAddress)
                            .keyboardType(.emailAddress)
                            .autocapitalization(.none)
                            .padding()
                            .background(Color(.secondarySystemBackground))
                            .cornerRadius(8)
                        
                        SecureField(NSLocalizedString("password", comment: ""), text: $password)
                            .textContentType(.password)
                            .padding()
                            .background(Color(.secondarySystemBackground))
                            .cornerRadius(8)
                    }
                    
                    // Error Message
                    if let errorMessage = authViewModel.errorMessage {
                        Text(errorMessage)
                            .font(.caption)
                            .foregroundColor(.red)
                            .multilineTextAlignment(.center)
                    }
                    
                    // Login Button
                    Button(action: login) {
                        if authViewModel.isLoading {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        } else {
                            Text(NSLocalizedString("login", comment: ""))
                                .font(.headline)
                                .foregroundColor(.white)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.green)
                    .cornerRadius(25)
                    .disabled(authViewModel.isLoading || email.isEmpty || password.isEmpty)
                    
                    // Register Link
                    Button(action: { showingRegister = true }) {
                        Text(NSLocalizedString("no_account_register", comment: ""))
                            .font(.subheadline)
                            .foregroundColor(.green)
                    }
                    
                    // Admin Login Link
                    Button(action: { showingAdminLogin = true }) {
                        Text(NSLocalizedString("admin_login", comment: ""))
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    
                    Spacer()
                }
                .padding(.horizontal, 32)
            }
            .navigationBarHidden(true)
            .sheet(isPresented: $showingRegister) {
                RegisterView()
            }
            .sheet(isPresented: $showingAdminLogin) {
                AdminLoginView()
            }
        }
    }
    
    private func login() {
        authViewModel.signIn(email: email, password: password)
    }
}

struct RegisterView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @Environment(\.presentationMode) var presentationMode
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var username = ""
    
    var body: some View {
        NavigationView {
            ZStack {
                Color(.systemBackground)
                    .ignoresSafeArea()
                
                VStack(spacing: 24) {
                    Text(NSLocalizedString("create_account", comment: ""))
                        .font(.title)
                        .fontWeight(.bold)
                        .padding(.top, 40)
                    
                    VStack(spacing: 16) {
                        TextField(NSLocalizedString("username_optional", comment: ""), text: $username)
                            .textContentType(.username)
                            .autocapitalization(.none)
                            .padding()
                            .background(Color(.secondarySystemBackground))
                            .cornerRadius(8)
                        
                        TextField(NSLocalizedString("email", comment: ""), text: $email)
                            .textContentType(.emailAddress)
                            .keyboardType(.emailAddress)
                            .autocapitalization(.none)
                            .padding()
                            .background(Color(.secondarySystemBackground))
                            .cornerRadius(8)
                        
                        SecureField(NSLocalizedString("password", comment: ""), text: $password)
                            .textContentType(.newPassword)
                            .padding()
                            .background(Color(.secondarySystemBackground))
                            .cornerRadius(8)
                        
                        SecureField(NSLocalizedString("confirm_password", comment: ""), text: $confirmPassword)
                            .textContentType(.newPassword)
                            .padding()
                            .background(Color(.secondarySystemBackground))
                            .cornerRadius(8)
                    }
                    
                    if let errorMessage = authViewModel.errorMessage {
                        Text(errorMessage)
                            .font(.caption)
                            .foregroundColor(.red)
                            .multilineTextAlignment(.center)
                    }
                    
                    Button(action: register) {
                        if authViewModel.isLoading {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        } else {
                            Text(NSLocalizedString("register", comment: ""))
                                .font(.headline)
                                .foregroundColor(.white)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.green)
                    .cornerRadius(25)
                    .disabled(authViewModel.isLoading || !isValid)
                    
                    Spacer()
                }
                .padding(.horizontal, 32)
            }
            .navigationBarItems(trailing: Button(NSLocalizedString("cancel", comment: "")) {
                presentationMode.wrappedValue.dismiss()
            })
        }
    }
    
    private var isValid: Bool {
        !email.isEmpty && !password.isEmpty && password == confirmPassword
    }
    
    private func register() {
        authViewModel.signUp(email: email, password: password, username: username.isEmpty ? nil : username)
    }
}

struct AdminLoginView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @Environment(\.presentationMode) var presentationMode
    @State private var email = ""
    @State private var password = ""
    
    var body: some View {
        NavigationView {
            ZStack {
                Color(.systemBackground)
                    .ignoresSafeArea()
                
                VStack(spacing: 24) {
                    Image(systemName: "shield.lefthalf.fill")
                        .font(.system(size: 60))
                        .foregroundColor(.green)
                        .padding(.top, 40)
                    
                    Text(NSLocalizedString("admin_login", comment: ""))
                        .font(.title)
                        .fontWeight(.bold)
                    
                    VStack(spacing: 16) {
                        TextField(NSLocalizedString("email", comment: ""), text: $email)
                            .textContentType(.emailAddress)
                            .keyboardType(.emailAddress)
                            .autocapitalization(.none)
                            .padding()
                            .background(Color(.secondarySystemBackground))
                            .cornerRadius(8)
                        
                        SecureField(NSLocalizedString("password", comment: ""), text: $password)
                            .textContentType(.password)
                            .padding()
                            .background(Color(.secondarySystemBackground))
                            .cornerRadius(8)
                    }
                    
                    if let errorMessage = authViewModel.errorMessage {
                        Text(errorMessage)
                            .font(.caption)
                            .foregroundColor(.red)
                            .multilineTextAlignment(.center)
                    }
                    
                    Button(action: login) {
                        if authViewModel.isLoading {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        } else {
                            Text(NSLocalizedString("login", comment: ""))
                                .font(.headline)
                                .foregroundColor(.white)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.green)
                    .cornerRadius(25)
                    .disabled(authViewModel.isLoading || email.isEmpty || password.isEmpty)
                    
                    Spacer()
                }
                .padding(.horizontal, 32)
            }
            .navigationBarItems(trailing: Button(NSLocalizedString("cancel", comment: "")) {
                presentationMode.wrappedValue.dismiss()
            })
        }
    }
    
    private func login() {
        authViewModel.adminSignIn(email: email, password: password)
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
            .environmentObject(AuthViewModel())
    }
}
