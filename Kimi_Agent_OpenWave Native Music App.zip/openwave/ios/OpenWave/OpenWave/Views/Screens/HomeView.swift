import SwiftUI

struct HomeView: View {
    @StateObject private var viewModel = HomeViewModel()
    @EnvironmentObject var playerViewModel: PlayerViewModel
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    // Greeting Header
                    GreetingHeader(
                        username: viewModel.currentUser?.displayName ?? "Guest",
                        points: viewModel.currentUser?.points ?? 0,
                        level: viewModel.currentUser?.level ?? 1
                    )
                    
                    // Trending Section
                    SectionHeader(title: NSLocalizedString("trending_now", comment: ""), action: {})
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 16) {
                            ForEach(viewModel.trendingTracks) { track in
                                TrackCard(track: track) {
                                    playerViewModel.playTrack(track, tracks: viewModel.trendingTracks)
                                }
                            }
                        }
                        .padding(.horizontal)
                    }
                    
                    // New Releases Section
                    SectionHeader(title: NSLocalizedString("new_releases", comment: ""), action: {})
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 16) {
                            ForEach(viewModel.newReleases) { track in
                                TrackCard(track: track) {
                                    playerViewModel.playTrack(track, tracks: viewModel.newReleases)
                                }
                            }
                        }
                        .padding(.horizontal)
                    }
                    
                    // Recently Played Section
                    if !viewModel.recentlyPlayed.isEmpty {
                        SectionHeader(title: NSLocalizedString("recently_played", comment: ""), action: {})
                        
                        VStack(spacing: 8) {
                            ForEach(viewModel.recentlyPlayed) { track in
                                TrackListItem(track: track) {
                                    playerViewModel.playTrack(track, tracks: viewModel.recentlyPlayed)
                                }
                            }
                        }
                        .padding(.horizontal)
                    }
                }
                .padding(.vertical)
            }
            .background(Color(.systemBackground))
            .navigationTitle("")
            .navigationBarHidden(true)
            .refreshable {
                await viewModel.refresh()
            }
        }
    }
}

struct GreetingHeader: View {
    let username: String
    let points: Int
    let level: Int
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(String(format: NSLocalizedString("greeting", comment: ""), username))
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(.primary)
            
            HStack(spacing: 12) {
                // Level Badge
                BadgeView(
                    text: "Lv. \(level)",
                    backgroundColor: Color.green.opacity(0.2),
                    textColor: .green
                )
                
                // Points Badge
                BadgeView(
                    text: "\(points) \(NSLocalizedString("points", comment: ""))",
                    backgroundColor: Color.blue.opacity(0.2),
                    textColor: .blue
                )
            }
        }
        .padding(.horizontal)
    }
}

struct BadgeView: View {
    let text: String
    let backgroundColor: Color
    let textColor: Color
    
    var body: some View {
        Text(text)
            .font(.caption)
            .fontWeight(.medium)
            .foregroundColor(textColor)
            .padding(.horizontal, 12)
            .padding(.vertical, 4)
            .background(backgroundColor)
            .cornerRadius(12)
    }
}

struct SectionHeader: View {
    let title: String
    let action: () -> Void
    
    var body: some View {
        HStack {
            Text(title)
                .font(.title2)
                .fontWeight(.bold)
            
            Spacer()
            
            Button(action: action) {
                Text(NSLocalizedString("see_all", comment: ""))
                    .font(.subheadline)
                    .foregroundColor(.green)
            }
        }
        .padding(.horizontal)
    }
}

struct TrackCard: View {
    let track: Track
    let onTap: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            // Cover Image
            AsyncImage(url: URL(string: track.coverUrl ?? "")) { image in
                image
                    .resizable()
                    .aspectRatio(contentMode: .fill)
            } placeholder: {
                Rectangle()
                    .fill(Color.gray.opacity(0.3))
                    .overlay(
                        Image(systemName: "music.note")
                            .font(.largeTitle)
                            .foregroundColor(.gray)
                    )
            }
            .frame(width: 140, height: 140)
            .cornerRadius(8)
            
            // Title
            Text(track.title)
                .font(.subheadline)
                .fontWeight(.medium)
                .lineLimit(1)
                .foregroundColor(.primary)
            
            // Artist
            Text(track.artist)
                .font(.caption)
                .lineLimit(1)
                .foregroundColor(.secondary)
        }
        .frame(width: 140)
        .onTapGesture(perform: onTap)
    }
}

struct TrackListItem: View {
    let track: Track
    let onTap: () -> Void
    
    var body: some View {
        HStack(spacing: 12) {
            // Cover Image
            AsyncImage(url: URL(string: track.coverUrl ?? "")) { image in
                image
                    .resizable()
                    .aspectRatio(contentMode: .fill)
            } placeholder: {
                Rectangle()
                    .fill(Color.gray.opacity(0.3))
                    .overlay(
                        Image(systemName: "music.note")
                            .foregroundColor(.gray)
                    )
            }
            .frame(width: 56, height: 56)
            .cornerRadius(4)
            
            // Track Info
            VStack(alignment: .leading, spacing: 4) {
                Text(track.title)
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .lineLimit(1)
                    .foregroundColor(.primary)
                
                Text(track.artist)
                    .font(.caption)
                    .lineLimit(1)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            // Duration
            Text(track.displayDuration)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding(.vertical, 4)
        .onTapGesture(perform: onTap)
    }
}

@MainActor
class HomeViewModel: ObservableObject {
    @Published var currentUser: User?
    @Published var trendingTracks: [Track] = []
    @Published var newReleases: [Track] = []
    @Published var recentlyPlayed: [Track] = []
    @Published var isLoading: Bool = false
    
    init() {
        Task {
            await loadData()
        }
    }
    
    func loadData() async {
        isLoading = true
        defer { isLoading = false }
        
        do {
            // Load user
            currentUser = try await SupabaseService.shared.currentUser
            
            // Load trending tracks
            trendingTracks = try await SupabaseService.shared.getTrendingTracks(limit: 10)
            
            // Load new releases
            newReleases = try await SupabaseService.shared.getNewReleases(limit: 10)
            
            // Load recently played
            if let userId = currentUser?.id {
                // Implementation for recently played
            }
        } catch {
            print("Error loading data: \(error)")
        }
    }
    
    func refresh() async {
        await loadData()
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
            .environmentObject(PlayerViewModel())
            .preferredColorScheme(.dark)
    }
}
