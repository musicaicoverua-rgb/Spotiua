import Foundation

enum UserRole: String, Codable {
    case user = "user"
    case admin = "admin"
}

struct User: Identifiable, Codable {
    let id: UUID
    let email: String
    var username: String?
    var role: UserRole
    var avatarUrl: String?
    var points: Int
    var coins: Int
    var level: Int
    var totalListeningTime: Int
    var lastDailyReward: Date?
    var createdAt: Date?
    
    enum CodingKeys: String, CodingKey {
        case id
        case email
        case username
        case role
        case avatarUrl = "avatar_url"
        case points
        case coins
        case level
        case totalListeningTime = "total_listening_time"
        case lastDailyReward = "last_daily_reward"
        case createdAt = "created_at"
    }
    
    var displayName: String {
        username ?? email.components(separatedBy: "@").first ?? "User"
    }
    
    var isAdmin: Bool {
        role == .admin
    }
    
    var nextLevelPoints: Int {
        LevelRequirements.pointsForLevel(level + 1)
    }
    
    var progressToNextLevel: Double {
        let currentLevelPoints = LevelRequirements.pointsForLevel(level)
        let nextLevelPoints = LevelRequirements.pointsForLevel(level + 1)
        let pointsInCurrentLevel = points - currentLevelPoints
        let pointsNeeded = nextLevelPoints - currentLevelPoints
        return pointsNeeded > 0 ? Double(pointsInCurrentLevel) / Double(pointsNeeded) : 1.0
    }
}

struct LevelRequirements {
    static let requirements: [Int: Int] = [
        1: 0,
        2: 100,
        3: 300,
        4: 600,
        5: 1000,
        6: 1500,
        7: 2100,
        8: 2800,
        9: 3600,
        10: 4500
    ]
    
    static func pointsForLevel(_ level: Int) -> Int {
        requirements[level] ?? 4500
    }
    
    static func levelForPoints(_ points: Int) -> Int {
        requirements
            .filter { $0.value <= points }
            .max { $0.key < $1.key }?
            .key ?? 1
    }
    
    static func titleForLevel(_ level: Int, language: String = "uk") -> String {
        let titles: [String: [String]] = [
            "uk": ["Новачок", "Слухач", "Меломан", "Експерт", "Майстер", "Профі", "Зірка", "Легенда", "Ікона", "Бог музики"],
            "en": ["Beginner", "Listener", "Music Lover", "Expert", "Master", "Pro", "Star", "Legend", "Icon", "Music God"],
            "ru": ["Новичок", "Слушатель", "Меломан", "Эксперт", "Мастер", "Про", "Звезда", "Легенда", "Икона", "Бог музыки"],
            "es": ["Principiante", "Oyente", "Melómano", "Experto", "Maestro", "Pro", "Estrella", "Leyenda", "Icono", "Dios de la Música"],
            "fr": ["Débutant", "Auditeur", "Mélomane", "Expert", "Maître", "Pro", "Star", "Légende", "Icône", "Dieu de la Musique"],
            "de": ["Anfänger", "Hörer", "Musikliebhaber", "Experte", "Meister", "Profi", "Star", "Legende", "Ikone", "Musikgott"],
            "pl": ["Początkujący", "Słuchacz", "Meloman", "Ekspert", "Mistrz", "Pro", "Gwiazda", "Legenda", "Ikona", "Bóg Muzyki"],
            "cs": ["Začátečník", "Posluchač", "Meloman", "Expert", "Mistr", "Pro", "Hvězda", "Legenda", "Ikona", "Bůh Hudby"]
        ]
        return titles[language]?[safe: level - 1] ?? titles["uk"]![level - 1]
    }
}

extension Array {
    subscript(safe index: Int) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}
