import Foundation

struct Track: Identifiable, Codable, Equatable {
    let id: UUID
    let title: String
    let artist: String
    var album: String?
    var duration: Int?
    var audioUrl: String
    var audioUrlAac: String?
    var coverUrl: String?
    var genre: String?
    var plays: Int
    var uploadedBy: UUID?
    var isProcessed: Bool
    var originalFormat: String?
    var bitrate: Int?
    var createdAt: Date?
    var updatedAt: Date?
    
    // Local properties
    var isDownloaded: Bool = false
    var localPath: String?
    var isLiked: Bool = false
    
    enum CodingKeys: String, CodingKey {
        case id
        case title
        case artist
        case album
        case duration
        case audioUrl = "audio_url"
        case audioUrlAac = "audio_url_aac"
        case coverUrl = "cover_url"
        case genre
        case plays
        case uploadedBy = "uploaded_by"
        case isProcessed = "is_processed"
        case originalFormat = "original_format"
        case bitrate
        case createdAt = "created_at"
        case updatedAt = "updated_at"
    }
    
    var displayDuration: String {
        guard let duration = duration else { return "--:--" }
        let minutes = duration / 60
        let seconds = duration % 60
        return String(format: "%d:%02d", minutes, seconds)
    }
    
    var bestAudioUrl: String {
        audioUrlAac ?? audioUrl
    }
    
    static func == (lhs: Track, rhs: Track) -> Bool {
        lhs.id == rhs.id
    }
}

struct Playlist: Identifiable, Codable {
    let id: UUID
    var name: String
    var description: String?
    let userId: UUID
    var coverUrl: String?
    var isPublic: Bool
    var createdAt: Date?
    var updatedAt: Date?
    
    // Local properties
    var tracks: [Track] = []
    var trackCount: Int { tracks.count }
    
    enum CodingKeys: String, CodingKey {
        case id
        case name
        case description
        case userId = "user_id"
        case coverUrl = "cover_url"
        case isPublic = "is_public"
        case createdAt = "created_at"
        case updatedAt = "updated_at"
    }
}

struct PlaylistTrack: Identifiable, Codable {
    let id: UUID
    let playlistId: UUID
    let trackId: UUID
    var position: Int
    var addedAt: Date?
    
    enum CodingKeys: String, CodingKey {
        case id
        case playlistId = "playlist_id"
        case trackId = "track_id"
        case position
        case addedAt = "added_at"
    }
}

struct Like: Identifiable, Codable {
    let id: UUID
    let userId: UUID
    let trackId: UUID
    var createdAt: Date?
    
    enum CodingKeys: String, CodingKey {
        case id
        case userId = "user_id"
        case trackId = "track_id"
        case createdAt = "created_at"
    }
}

struct ListeningHistory: Identifiable, Codable {
    let id: UUID
    let userId: UUID
    let trackId: UUID
    var playedAt: Date
    var duration: Int
    var completed: Bool
    var track: Track?
    
    enum CodingKeys: String, CodingKey {
        case id
        case userId = "user_id"
        case trackId = "track_id"
        case playedAt = "played_at"
        case duration
        case completed
    }
}

struct OfflineDownload: Identifiable, Codable {
    let id: UUID
    let userId: UUID
    let trackId: UUID
    var localPath: String?
    var downloadedAt: Date?
    var expiresAt: Date?
    var track: Track?
    
    enum CodingKeys: String, CodingKey {
        case id
        case userId = "user_id"
        case trackId = "track_id"
        case localPath = "local_path"
        case downloadedAt = "downloaded_at"
        case expiresAt = "expires_at"
    }
}
