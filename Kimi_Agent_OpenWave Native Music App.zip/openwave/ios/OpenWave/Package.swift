// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "OpenWave",
    platforms: [
        .iOS(.v16)
    ],
    dependencies: [
        .package(url: "https://github.com/supabase/supabase-swift.git", from: "1.0.0"),
    ],
    targets: [
        .target(
            name: "OpenWave",
            dependencies: [
                .product(name: "Supabase", package: "supabase-swift"),
                .product(name: "Auth", package: "supabase-swift"),
                .product(name: "PostgREST", package: "supabase-swift"),
                .product(name: "Realtime", package: "supabase-swift"),
                .product(name: "Storage", package: "supabase-swift"),
            ]
        ),
        .testTarget(
            name: "OpenWaveTests",
            dependencies: ["OpenWave"]
        ),
    ]
)
