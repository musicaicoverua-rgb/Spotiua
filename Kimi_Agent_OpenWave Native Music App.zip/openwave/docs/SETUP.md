# OpenWave Setup Guide

This guide will walk you through setting up the OpenWave music streaming application.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Supabase Backend Setup](#supabase-backend-setup)
3. [Android App Setup](#android-app-setup)
4. [iOS App Setup](#ios-app-setup)
5. [Configuration](#configuration)
6. [Running the Apps](#running-the-apps)

## Prerequisites

### Required Accounts
- [Supabase](https://supabase.com) account (free tier works)
- [Google Play Console](https://play.google.com/console) (for Android release)
- [Apple Developer](https://developer.apple.com) account (for iOS release)

### Required Software
- **Android Development**:
  - Android Studio Hedgehog (2023.1.1) or later
  - JDK 17 or later
  - Android SDK 34

- **iOS Development**:
  - Xcode 15.0 or later
  - macOS 14.0 or later
  - iOS 16.0+ deployment target

## Supabase Backend Setup

### 1. Create Supabase Project

1. Go to [Supabase Dashboard](https://app.supabase.com)
2. Click "New Project"
3. Enter project details:
   - Name: `openwave`
   - Database Password: (generate a secure password)
   - Region: Choose closest to your users
4. Wait for project creation (2-3 minutes)

### 2. Configure Database

1. Go to SQL Editor in Supabase Dashboard
2. Create a new query
3. Copy and paste the entire contents of `supabase/schema.sql`
4. Click "Run"

This will create all tables, indexes, functions, and RLS policies.

### 3. Create Storage Buckets

1. Go to Storage in Supabase Dashboard
2. Create three buckets:

#### Bucket 1: music-files
- Name: `music-files`
- Public: ✅ Enabled
- File size limit: 50MB
- Allowed MIME types:
  - audio/mpeg
  - audio/aac
  - audio/wav
  - audio/flac
  - audio/ogg
  - audio/mp4

#### Bucket 2: covers
- Name: `covers`
- Public: ✅ Enabled
- File size limit: 5MB
- Allowed MIME types:
  - image/jpeg
  - image/png
  - image/webp

#### Bucket 3: avatars
- Name: `avatars`
- Public: ✅ Enabled
- File size limit: 2MB
- Allowed MIME types:
  - image/jpeg
  - image/png
  - image/webp

### 4. Configure Storage Policies

1. Go to SQL Editor
2. Copy and paste the contents of `supabase/storage.sql`
3. Click "Run"

### 5. Deploy Edge Functions

#### Install Supabase CLI
```bash
npm install -g supabase
```

#### Login to Supabase
```bash
supabase login
```

#### Link Project
```bash
supabase link --project-ref YOUR_PROJECT_REF
```

#### Deploy Functions
```bash
# Audio Processor
cd supabase/functions/audio-processor
supabase functions deploy audio-processor

# Analytics
cd ../analytics
supabase functions deploy analytics

# Chat Notifications
cd ../chat-notifications
supabase functions deploy chat-notifications
```

### 6. Get API Credentials

1. Go to Project Settings > API
2. Copy the following:
   - **Project URL**: `https://xxxxxx.supabase.co`
   - **anon/public key**: `eyJhbG...`

Save these for the next steps.

## Android App Setup

### 1. Open Project

```bash
cd android
open -a "Android Studio" .
```

Or open Android Studio and select `openwave/android` folder.

### 2. Configure Supabase Credentials

Open `app/build.gradle.kts` and update:

```kotlin
buildConfigField("String", "SUPABASE_URL", "\"https://your-project.supabase.co\"")
buildConfigField("String", "SUPABASE_ANON_KEY", "\"your-anon-key\"")
```

### 3. Sync Project

Click "Sync Now" in the notification bar or:
- File > Sync Project with Gradle Files

### 4. Build Project

```bash
./gradlew build
```

### 5. Run on Device/Emulator

1. Connect an Android device or start an emulator
2. Click the Run button (▶) in Android Studio
3. Select your device

## iOS App Setup

### 1. Open Project

```bash
cd ios/OpenWave
open OpenWave.xcodeproj
```

### 2. Configure Supabase Credentials

Open `OpenWave/Services/SupabaseService.swift` and update:

```swift
client = SupabaseClient(
    supabaseURL: URL(string: "https://your-project.supabase.co")!,
    supabaseKey: "your-anon-key"
)
```

### 3. Install Dependencies

The project uses Swift Package Manager. Dependencies will resolve automatically when you build.

If needed, manually add:
1. File > Add Package Dependencies
2. Add `https://github.com/supabase/supabase-swift.git`
3. Select version 1.0.0 or later

### 4. Build Project

Press Cmd+B or:
- Product > Build

### 5. Run on Simulator/Device

1. Select a simulator or connected device
2. Click the Run button (▶) or press Cmd+R

## Configuration

### Environment Variables

Create environment-specific configuration files:

#### Android
Create `app/src/debug/res/values/config.xml`:
```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="supabase_url">https://dev-project.supabase.co</string>
</resources>
```

#### iOS
Create configuration files in Xcode:
1. File > New > File
2. Select "Configuration Settings File"
3. Name it `Debug.xcconfig`

### Enable CDN (Recommended)

1. Go to Supabase Dashboard > Storage
2. Click on each bucket
3. Go to "Configuration" tab
4. Enable "CDN"
5. Set cache duration to 1 hour

### Configure Authentication

#### Email Auth (Enabled by default)

1. Go to Authentication > Providers
2. Ensure "Email" is enabled
3. Configure email templates if needed

#### Social Auth (Optional)

To add Google/Apple sign-in:
1. Go to Authentication > Providers
2. Enable desired providers
3. Configure OAuth credentials

## Running the Apps

### Android

#### Debug Mode
```bash
./gradlew installDebug
```

#### Release Mode
```bash
./gradlew assembleRelease
```

### iOS

#### Simulator
1. Select simulator (e.g., iPhone 15 Pro)
2. Press Cmd+R

#### Physical Device
1. Connect iPhone/iPad
2. Select device in Xcode
3. Press Cmd+R
4. Trust developer certificate on device

## Testing

### Create Admin User

1. Register a regular user through the app
2. Go to Supabase Dashboard > Table Editor > users
3. Find your user and change `role` from `user` to `admin`

### Upload Test Track

1. Log in as admin
2. Go to Admin Dashboard > Upload
3. Select an audio file (MP3, AAC, etc.)
4. Add cover image
5. Fill in track details
6. Upload

### Test Features

- [ ] User registration/login
- [ ] Track playback
- [ ] Playlist creation
- [ ] Like/unlike tracks
- [ ] Download for offline
- [ ] Daily rewards
- [ ] Bonus wheel
- [ ] Leaderboard
- [ ] Support chat

## Troubleshooting

### Android Issues

**Build fails with "Could not resolve dependencies"**
- Check internet connection
- Try File > Invalidate Caches / Restart

**App crashes on startup**
- Check Supabase credentials
- Verify network permission in AndroidManifest.xml

**Audio not playing**
- Check audio URL is accessible
- Verify ExoPlayer dependencies

### iOS Issues

**Build fails with "No such module 'Supabase'"**
- Clean build folder (Cmd+Shift+K)
- Rebuild (Cmd+B)

**App crashes on device**
- Check signing certificates
- Verify bundle identifier

**Audio not playing**
- Check audio session configuration
- Verify background modes are enabled

### Supabase Issues

**RLS policy errors**
- Check user is authenticated
- Verify RLS policies are correct

**Storage upload fails**
- Check bucket exists and is public
- Verify file size limits

**Edge function errors**
- Check function logs in Supabase Dashboard
- Verify function is deployed correctly

## Next Steps

1. **Customize UI**: Modify themes in `theme/` directories
2. **Add Features**: Extend ViewModels and repositories
3. **Optimize Performance**: Add caching, lazy loading
4. **Add Tests**: Write unit and integration tests
5. **Deploy**: Publish to Play Store and App Store

## Support

For issues and questions:
- Check the [FAQ](FAQ.md)
- Open an issue on GitHub
- Contact support@openwave.app
