# OpenWave - Music Streaming Application

A fully native mobile music streaming application similar to Spotify, built for Android (Kotlin) and iOS (Swift) with Supabase backend.

## Features

### Core Features
- **Music Streaming**: High-quality audio streaming with CDN support
- **Offline Listening**: Download tracks for offline playback
- **Search**: Find tracks, artists, and albums
- **Playlists**: Create and manage personal playlists
- **Liked Songs**: Save your favorite tracks

### Gamification System
- **Points System**: Earn 1 point per minute of listening
- **Coin System**: Earn 1 coin per 10 minutes of listening
- **Level System**: 10 levels with increasing requirements
- **Daily Rewards**: Claim 20 points and 10 coins daily
- **Bonus Wheel**: Spin for random rewards (points, coins, XP)
- **Leaderboard**: Compete with other users

### Admin Features
- **Track Upload**: Upload and manage music tracks
- **Analytics Dashboard**: View app statistics
- **User Management**: Manage users and content
- **Support Chat**: Reply to user messages

### Technical Features
- **Multi-language Support**: 8 languages (Ukrainian, Russian, English, Spanish, French, German, Polish, Czech)
- **Real-time Chat**: User-to-admin messaging
- **AI Recommendations**: Personalized track suggestions
- **Radio Mode**: Continuous playback of similar tracks
- **Background Playback**: Listen while using other apps

## Project Structure

```
openwave/
├── supabase/           # Supabase backend configuration
│   ├── schema.sql      # Database schema
│   ├── storage.sql     # Storage bucket policies
│   └── functions/      # Edge functions
│       ├── audio-processor/  # Audio file processing
│       ├── analytics/        # Analytics aggregation
│       └── chat-notifications/ # Chat notifications
├── android/            # Android app (Kotlin)
│   └── app/src/main/java/com/openwave/app/
│       ├── data/       # Data layer
│       │   ├── local/  # Local database (Room)
│       │   ├── remote/ # Supabase client
│       │   └── repository/ # Repositories
│       ├── domain/     # Domain layer
│       │   └── model/  # Data models
│       ├── presentation/ # UI layer
│       │   ├── components/ # Reusable components
│       │   ├── screens/    # Screen composables
│       │   ├── viewmodel/  # ViewModels
│       │   ├── navigation/ # Navigation
│       │   └── theme/      # Theme and styling
│       ├── service/    # Background services
│       └── di/         # Dependency injection
├── ios/                # iOS app (Swift)
│   └── OpenWave/
│       ├── Models/     # Data models
│       ├── Services/   # Services (Supabase, Audio)
│       ├── ViewModels/ # ViewModels
│       ├── Views/      # SwiftUI views
│       └── Resources/  # Localization, Assets
└── docs/               # Documentation
```

## Setup Instructions

### Prerequisites

- **Supabase Account**: Create a free account at [supabase.com](https://supabase.com)
- **Android Studio**: For Android development
- **Xcode**: For iOS development

### Supabase Setup

1. **Create a new Supabase project**
   ```bash
   # Or use the Supabase Dashboard
   ```

2. **Run the database schema**
   - Go to SQL Editor in Supabase Dashboard
   - Copy and paste the contents of `supabase/schema.sql`
   - Run the SQL

3. **Create storage buckets**
   - Go to Storage in Supabase Dashboard
   - Create three buckets:
     - `music-files` (public, 50MB max)
     - `covers` (public, 5MB max)
     - `avatars` (public, 2MB max)
   - Run `supabase/storage.sql` for bucket policies

4. **Deploy edge functions**
   ```bash
   cd supabase/functions/audio-processor
   supabase functions deploy audio-processor
   
   cd ../analytics
   supabase functions deploy analytics
   
   cd ../chat-notifications
   supabase functions deploy chat-notifications
   ```

5. **Get API credentials**
   - Project URL: Settings > API > Project URL
   - Anon Key: Settings > API > Project API Keys > anon/public

### Android Setup

1. **Open the project in Android Studio**
   ```bash
   cd android
   open -a "Android Studio" .
   ```

2. **Configure Supabase credentials**
   - Open `app/build.gradle.kts`
   - Replace `YOUR_SUPABASE_URL` and `YOUR_SUPABASE_ANON_KEY`

3. **Build and run**
   - Connect an Android device or start an emulator
   - Click Run in Android Studio

### iOS Setup

1. **Open the project in Xcode**
   ```bash
   cd ios/OpenWave
   open OpenWave.xcodeproj
   ```

2. **Configure Supabase credentials**
   - Open `OpenWave/Services/SupabaseService.swift`
   - Replace `YOUR_SUPABASE_URL` and `YOUR_SUPABASE_ANON_KEY`

3. **Install dependencies**
   - The project uses Swift Package Manager
   - Dependencies will be resolved automatically

4. **Build and run**
   - Select a simulator or connected device
   - Click Run in Xcode

## Architecture

### Android
- **Architecture Pattern**: MVVM (Model-View-ViewModel)
- **UI Framework**: Jetpack Compose
- **Dependency Injection**: Hilt
- **Networking**: Ktor (Supabase SDK)
- **Audio Player**: ExoPlayer
- **Local Storage**: Room Database
- **Image Loading**: Coil

### iOS
- **Architecture Pattern**: MVVM (Model-View-ViewModel)
- **UI Framework**: SwiftUI
- **Reactive Programming**: Combine
- **Networking**: Supabase Swift SDK
- **Audio Player**: AVPlayer
- **Local Storage**: Core Data (optional)
- **Image Loading**: AsyncImage

### Backend
- **Database**: PostgreSQL (via Supabase)
- **Authentication**: Supabase Auth
- **Storage**: Supabase Storage with CDN
- **Realtime**: Supabase Realtime
- **Serverless Functions**: Supabase Edge Functions

## Database Schema

### Tables
- `users` - User profiles with gamification stats
- `tracks` - Music tracks with metadata
- `playlists` - User playlists
- `playlist_tracks` - Playlist-track relationships
- `likes` - User liked tracks
- `listening_history` - Track playback history
- `offline_downloads` - Offline download records
- `messages` - User-admin chat messages
- `analytics` - App analytics events
- `daily_rewards` - Daily reward claims
- `wheel_spins` - Bonus wheel spins
- `ai_recommendations` - AI-generated recommendations
- `radio_sessions` - Radio mode sessions

## API Endpoints

### Edge Functions
- `audio-processor` - Process uploaded audio files
- `analytics` - Get analytics data
- `chat-notifications` - Handle chat notifications

### Database Functions
- `increment_track_plays` - Increment track play count
- `update_user_listening_stats` - Update user stats
- `claim_daily_reward` - Claim daily reward
- `spin_bonus_wheel` - Spin bonus wheel
- `get_leaderboard_by_points` - Get points leaderboard
- `get_leaderboard_by_listening_time` - Get time leaderboard

## Security

### Row Level Security (RLS)
- Users can only access their own data
- Admins have full access to all data
- Public tracks are readable by all users
- Only admins can upload/modify tracks

### Storage Policies
- Public read access for music files and covers
- Admin-only write access for tracks
- User-specific write access for avatars

## Localization

Supported languages:
- Ukrainian (primary)
- Russian
- English
- Spanish
- French
- German
- Polish
- Czech

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

MIT License - see LICENSE file for details

## Support

For support, please contact us through the in-app support chat or email support@openwave.app
