# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Uncomment this to preserve the line number information for
# debugging stack traces.
#-keepattributes SourceFile,LineNumberTable

# If you keep the line number table, uncomment this to
# hide the original source file name.
#-renamesourcefileattribute SourceFile

# Keep data classes
-keepclassmembers class com.openwave.app.domain.model.** {
    *;
}

# Keep Kotlin serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *; }

# Keep Supabase
-keep class io.github.jan.tensort.supabase.** { *; }
-keep class io.ktor.** { *; }

# Keep ExoPlayer
-keep class androidx.media3.** { *; }

# Keep Hilt
-keep class dagger.hilt.** { *; }
-keep class javax.inject.** { *; }

# Keep Retrofit
-keep class retrofit2.** { *; }
-keep class com.squareup.okhttp3.** { *; }

# Keep Room
-keep class androidx.room.** { *; }
-keep @androidx.room.Entity class *

# Keep Coil
-keep class coil.** { *; }
