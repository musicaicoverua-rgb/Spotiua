package com.openwave.app.presentation.viewmodel

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.openwave.app.data.repository.TrackRepository
import com.openwave.app.domain.model.Track
import com.openwave.app.service.MusicPlaybackService
import com.openwave.app.service.PlaybackState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

/**
 * Player ViewModel
 * Manages audio playback state and controls
 */
@HiltViewModel
class PlayerViewModel @Inject constructor(
    application: Application,
    private val trackRepository: TrackRepository
) : AndroidViewModel(application) {

    private var musicService: MusicPlaybackService? = null
    private var serviceBound = false

    // Playback State
    private val _currentTrack = MutableStateFlow<Track?>(null)
    val currentTrack: StateFlow<Track?> = _currentTrack.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition: StateFlow<Long> = _currentPosition.asStateFlow()

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration.asStateFlow()

    private val _playbackState = MutableStateFlow<PlaybackState>(PlaybackState.Idle)
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    private val _queue = MutableStateFlow<List<Track>>(emptyList())
    val queue: StateFlow<List<Track>> = _queue.asStateFlow()

    private val _currentIndex = MutableStateFlow(0)
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

    private val _shuffleEnabled = MutableStateFlow(false)
    val shuffleEnabled: StateFlow<Boolean> = _shuffleEnabled.asStateFlow()

    private val _repeatMode = MutableStateFlow(0) // 0: Off, 1: All, 2: One
    val repeatMode: StateFlow<Int> = _repeatMode.asStateFlow()

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            // Service connected
            Timber.d("Player service connected")
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            musicService = null
            serviceBound = false
        }
    }

    init {
        bindService()
        startPositionUpdates()
    }

    private fun bindService() {
        val context = getApplication<Application>()
        val intent = Intent(context, MusicPlaybackService::class.java)
        context.bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
        serviceBound = true
    }

    private fun startPositionUpdates() {
        viewModelScope.launch {
            while (true) {
                musicService?.let { service ->
                    _currentPosition.value = service.currentPosition.value
                    _duration.value = service.duration.value
                    _isPlaying.value = service.isPlaying.value
                    _playbackState.value = service.playbackState.value
                }
                delay(1000)
            }
        }
    }

    /**
     * Play a track
     */
    fun playTrack(track: Track, tracks: List<Track> = listOf(track)) {
        viewModelScope.launch {
            try {
                // Increment play count
                trackRepository.incrementPlays(track.id)

                // Start service and play
                val context = getApplication<Application>()
                val intent = Intent(context, MusicPlaybackService::class.java).apply {
                    action = MusicPlaybackService.ACTION_PLAY
                }
                context.startService(intent)

                musicService?.playTrack(track, tracks)

                _currentTrack.value = track
                _queue.value = tracks
                _currentIndex.value = tracks.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
                _isPlaying.value = true

            } catch (e: Exception) {
                Timber.e(e, "Error playing track")
            }
        }
    }

    /**
     * Toggle play/pause
     */
    fun togglePlayPause() {
        musicService?.togglePlayPause()
    }

    /**
     * Play
     */
    fun play() {
        musicService?.play()
        _isPlaying.value = true
    }

    /**
     * Pause
     */
    fun pause() {
        musicService?.pause()
        _isPlaying.value = false
    }

    /**
     * Play next track
     */
    fun playNext() {
        musicService?.playNext()
        updateCurrentTrack()
    }

    /**
     * Play previous track
     */
    fun playPrevious() {
        musicService?.playPrevious()
        updateCurrentTrack()
    }

    /**
     * Seek to position
     */
    fun seekTo(positionMs: Long) {
        musicService?.seekTo(positionMs)
        _currentPosition.value = positionMs
    }

    /**
     * Skip forward
     */
    fun skipForward(milliseconds: Long = 10000) {
        musicService?.skipForward(milliseconds)
    }

    /**
     * Skip backward
     */
    fun skipBackward(milliseconds: Long = 10000) {
        musicService?.skipBackward(milliseconds)
    }

    /**
     * Toggle shuffle
     */
    fun toggleShuffle() {
        _shuffleEnabled.value = !_shuffleEnabled.value
        musicService?.setShuffleEnabled(_shuffleEnabled.value)
    }

    /**
     * Set repeat mode
     */
    fun setRepeatMode(mode: Int) {
        _repeatMode.value = mode
        musicService?.setRepeatMode(mode)
    }

    /**
     * Add track to queue
     */
    fun addToQueue(track: Track) {
        musicService?.addToQueue(track)
        _queue.value = musicService?.getQueue() ?: emptyList()
    }

    /**
     * Clear queue
     */
    fun clearQueue() {
        musicService?.clearQueue()
        _queue.value = emptyList()
    }

    /**
     * Update current track from service
     */
    private fun updateCurrentTrack() {
        _currentTrack.value = musicService?.currentTrack?.value
        _currentIndex.value = musicService?.getCurrentIndex() ?: 0
    }

    /**
     * Format position for display
     */
    fun formatPosition(positionMs: Long): String {
        val seconds = positionMs / 1000
        val minutes = seconds / 60
        val remainingSeconds = seconds % 60
        return "%d:%02d".format(minutes, remainingSeconds)
    }

    override fun onCleared() {
        super.onCleared()
        if (serviceBound) {
            getApplication<Application>().unbindService(serviceConnection)
            serviceBound = false
        }
    }
}
