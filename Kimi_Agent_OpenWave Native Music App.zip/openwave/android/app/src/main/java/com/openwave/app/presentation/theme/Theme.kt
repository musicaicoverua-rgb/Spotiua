package com.openwave.app.presentation.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

/**
 * OpenWave Theme
 * Dark theme similar to Spotify
 */

private val DarkColorScheme = darkColorScheme(
    primary = SpotifyGreen,
    onPrimary = TextPrimary,
    primaryContainer = SpotifyGreenDark,
    onPrimaryContainer = TextPrimary,
    secondary = AccentBlue,
    onSecondary = TextPrimary,
    secondaryContainer = DarkElevated,
    onSecondaryContainer = TextPrimary,
    tertiary = AccentPurple,
    onTertiary = TextPrimary,
    tertiaryContainer = DarkElevated,
    onTertiaryContainer = TextPrimary,
    error = Error,
    onError = TextPrimary,
    errorContainer = Error.copy(alpha = 0.2f),
    onErrorContainer = Error,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkElevated,
    onSurfaceVariant = TextSecondary,
    outline = Divider,
    outlineVariant = DarkElevated,
    scrim = Overlay,
    inverseSurface = TextPrimary,
    inverseOnSurface = DarkBackground,
    inversePrimary = SpotifyGreenLight,
    surfaceTint = SpotifyGreen,
    surfaceBright = DarkElevated,
    surfaceContainer = DarkSurface,
    surfaceContainerHigh = DarkElevated,
    surfaceContainerHighest = DarkCard,
    surfaceContainerLow = DarkSurface,
    surfaceContainerLowest = DarkBackground,
    surfaceDim = DarkBackground
)

@Composable
fun OpenWaveTheme(
    darkTheme: Boolean = true, // Always use dark theme
    dynamicColor: Boolean = false, // Disable dynamic color
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> DarkColorScheme // Always use dark theme
    }
    
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

/**
 * Theme utilities
 */
object OpenWaveTheme {
    val colors: androidx.compose.material3.ColorScheme
        @Composable
        get() = MaterialTheme.colorScheme
    
    val typography: androidx.compose.material3.Typography
        @Composable
        get() = MaterialTheme.typography
    
    val shapes: androidx.compose.material3.Shapes
        @Composable
        get() = MaterialTheme.shapes
}
