package com.openwave.app.presentation.theme

import androidx.compose.ui.graphics.Color

/**
 * OpenWave Color Palette
 * Dark theme similar to Spotify
 */

// Primary Colors
val SpotifyGreen = Color(0xFF1DB954)
val SpotifyGreenDark = Color(0xFF1AA34A)
val SpotifyGreenLight = Color(0xFF1ED760)

// Background Colors
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF181818)
val DarkElevated = Color(0xFF282828)
val DarkCard = Color(0xFF2A2A2A)

// Text Colors
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFB3B3B3)
val TextTertiary = Color(0xFF7C7C7C)
val TextDisabled = Color(0xFF535353)

// Accent Colors
val AccentBlue = Color(0xFF2E77D0)
val AccentPurple = Color(0xFF8B5CF6)
val AccentPink = Color(0xFFE91E63)
val AccentOrange = Color(0xFFFF9800)
val AccentRed = Color(0xFFE22134)

// Gradient Colors
val GradientStart = Color(0xFF2E77D0)
val GradientEnd = Color(0xFF1DB954)

// Status Colors
val Success = Color(0xFF4CAF50)
val Error = Color(0xFFE22134)
val Warning = Color(0xFFFF9800)
val Info = Color(0xFF2196F3)

// Player Colors
val PlayerBackground = Color(0xFF181818)
val PlayerProgress = Color(0xFF1DB954)
val PlayerProgressBackground = Color(0xFF404040)

// Button Colors
val ButtonPrimary = SpotifyGreen
val ButtonSecondary = Color(0xFFFFFFFF)
val ButtonDisabled = Color(0xFF535353)

// Overlay Colors
val Overlay = Color(0x80000000)
val OverlayLight = Color(0x40000000)

// Divider
val Divider = Color(0xFF282828)
