package com.openwave.app.presentation

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.openwave.app.presentation.components.BottomNavigationBar
import com.openwave.app.presentation.components.MiniPlayer
import com.openwave.app.presentation.navigation.AppNavigation
import com.openwave.app.presentation.navigation.Screen
import com.openwave.app.presentation.theme.OpenWaveTheme
import com.openwave.app.presentation.viewmodel.AuthViewModel
import com.openwave.app.presentation.viewmodel.PlayerViewModel
import com.openwave.app.service.MusicPlaybackService
import dagger.hilt.android.AndroidEntryPoint
import timber.log.Timber

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val authViewModel: AuthViewModel by viewModels()
    private val playerViewModel: PlayerViewModel by viewModels()
    
    private var musicService: MusicPlaybackService? = null
    private var serviceBound by mutableStateOf(false)
    
    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            // Service is bound
            Timber.d("Music service connected")
        }
        
        override fun onServiceDisconnected(name: ComponentName?) {
            musicService = null
            serviceBound = false
            Timber.d("Music service disconnected")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)
        
        // Bind to music service
        bindMusicService()
        
        setContent {
            OpenWaveTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    OpenWaveApp(
                        authViewModel = authViewModel,
                        playerViewModel = playerViewModel
                    )
                }
            }
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        if (serviceBound) {
            unbindService(serviceConnection)
            serviceBound = false
        }
    }
    
    private fun bindMusicService() {
        val intent = Intent(this, MusicPlaybackService::class.java)
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
        serviceBound = true
    }
}

@Composable
fun OpenWaveApp(
    authViewModel: AuthViewModel,
    playerViewModel: PlayerViewModel
) {
    val navController = rememberNavController()
    val context = LocalContext.current
    
    // Observe auth state
    val authState by authViewModel.authState.collectAsStateWithLifecycle()
    val currentUser by authViewModel.currentUser.collectAsStateWithLifecycle()
    
    // Observe player state
    val currentTrack by playerViewModel.currentTrack.collectAsStateWithLifecycle()
    val isPlaying by playerViewModel.isPlaying.collectAsStateWithLifecycle()
    
    // Get current route
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    
    // Check if we should show bottom bar
    val showBottomBar = currentRoute?.let { route ->
        route !in listOf(
            Screen.Login.route,
            Screen.Register.route,
            Screen.AdminLogin.route,
            Screen.FullPlayer.route
        )
    } ?: false
    
    // Check if we should show mini player
    val showMiniPlayer = currentTrack != null && currentRoute != Screen.FullPlayer.route
    
    // Initialize auth
    LaunchedEffect(Unit) {
        authViewModel.checkAuthState()
    }
    
    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                BottomNavigationBar(
                    navController = navController,
                    isAdmin = currentUser?.isAdmin ?: false
                )
            }
        }
    ) { paddingValues ->
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            color = MaterialTheme.colorScheme.background
        ) {
            AppNavigation(
                navController = navController,
                authViewModel = authViewModel,
                playerViewModel = playerViewModel,
                startDestination = when (authState) {
                    is AuthViewModel.AuthState.Authenticated -> Screen.Home.route
                    is AuthViewModel.AuthState.AdminAuthenticated -> Screen.AdminDashboard.route
                    else -> Screen.Login.route
                }
            )
        }
        
        // Mini Player overlay
        if (showMiniPlayer) {
            MiniPlayer(
                track = currentTrack!!,
                isPlaying = isPlaying,
                onPlayPause = { playerViewModel.togglePlayPause() },
                onClick = { navController.navigate(Screen.FullPlayer.route) },
                onNext = { playerViewModel.playNext() },
                modifier = Modifier.padding(paddingValues)
            )
        }
    }
}
