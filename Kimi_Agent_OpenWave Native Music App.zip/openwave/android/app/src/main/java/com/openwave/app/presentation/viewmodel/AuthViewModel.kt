package com.openwave.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.openwave.app.data.remote.Result
import com.openwave.app.data.repository.AuthRepository
import com.openwave.app.domain.model.User
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

/**
 * Authentication ViewModel
 * Manages user authentication state and operations
 */
@HiltViewModel
class AuthViewModel @Inject constructor(
    private val authRepository: AuthRepository
) : ViewModel() {

    // Auth State
    sealed class AuthState {
        object Initial : AuthState()
        object Loading : AuthState()
        object Authenticated : AuthState()
        object AdminAuthenticated : AuthState()
        object Unauthenticated : AuthState()
        data class Error(val message: String) : AuthState()
    }

    private val _authState = MutableStateFlow<AuthState>(AuthState.Initial)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    init {
        checkAuthState()
    }

    /**
     * Check current authentication state
     */
    fun checkAuthState() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                if (authRepository.isLoggedIn()) {
                    val userId = authRepository.getCurrentUserId()
                    userId?.let {
                        when (val result = authRepository.getUserProfile(it)) {
                            is Result.Success -> {
                                _currentUser.value = result.data
                                _authState.value = if (result.data.isAdmin) {
                                    AuthState.AdminAuthenticated
                                } else {
                                    AuthState.Authenticated
                                }
                            }
                            is Result.Error -> {
                                _authState.value = AuthState.Unauthenticated
                                signOut()
                            }
                            else -> {}
                        }
                    } ?: run {
                        _authState.value = AuthState.Unauthenticated
                    }
                } else {
                    _authState.value = AuthState.Unauthenticated
                }
            } catch (e: Exception) {
                Timber.e(e, "Error checking auth state")
                _authState.value = AuthState.Unauthenticated
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Sign in with email and password
     */
    fun signIn(email: String, password: String, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            
            when (val result = authRepository.signIn(email, password)) {
                is Result.Success -> {
                    _currentUser.value = result.data
                    _authState.value = AuthState.Authenticated
                    onSuccess()
                }
                is Result.Error -> {
                    _errorMessage.value = result.message
                    _authState.value = AuthState.Error(result.message)
                }
                else -> {}
            }
            
            _isLoading.value = false
        }
    }

    /**
     * Admin sign in
     */
    fun adminSignIn(email: String, password: String, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            
            when (val result = authRepository.adminSignIn(email, password)) {
                is Result.Success -> {
                    _currentUser.value = result.data
                    _authState.value = AuthState.AdminAuthenticated
                    onSuccess()
                }
                is Result.Error -> {
                    _errorMessage.value = result.message
                    _authState.value = AuthState.Error(result.message)
                }
                else -> {}
            }
            
            _isLoading.value = false
        }
    }

    /**
     * Sign up with email and password
     */
    fun signUp(email: String, password: String, username: String? = null, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            
            when (val result = authRepository.signUp(email, password, username)) {
                is Result.Success -> {
                    _currentUser.value = result.data
                    _authState.value = AuthState.Authenticated
                    onSuccess()
                }
                is Result.Error -> {
                    _errorMessage.value = result.message
                    _authState.value = AuthState.Error(result.message)
                }
                else -> {}
            }
            
            _isLoading.value = false
        }
    }

    /**
     * Sign out
     */
    fun signOut() {
        viewModelScope.launch {
            _isLoading.value = true
            
            when (val result = authRepository.signOut()) {
                is Result.Success -> {
                    _currentUser.value = null
                    _authState.value = AuthState.Unauthenticated
                }
                is Result.Error -> {
                    _errorMessage.value = result.message
                }
                else -> {}
            }
            
            _isLoading.value = false
        }
    }

    /**
     * Update user profile
     */
    fun updateProfile(user: User) {
        viewModelScope.launch {
            when (val result = authRepository.updateUserProfile(user)) {
                is Result.Success -> {
                    _currentUser.value = result.data
                }
                is Result.Error -> {
                    _errorMessage.value = result.message
                }
                else -> {}
            }
        }
    }

    /**
     * Reset password
     */
    fun resetPassword(email: String, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            _isLoading.value = true
            
            when (val result = authRepository.resetPassword(email)) {
                is Result.Success -> {
                    onSuccess()
                }
                is Result.Error -> {
                    _errorMessage.value = result.message
                }
                else -> {}
            }
            
            _isLoading.value = false
        }
    }

    /**
     * Clear error message
     */
    fun clearError() {
        _errorMessage.value = null
    }
}
