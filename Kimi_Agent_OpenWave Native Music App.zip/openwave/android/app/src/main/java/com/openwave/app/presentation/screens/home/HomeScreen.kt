package com.openwave.app.presentation.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.ExperimentalMaterialApi
import androidx.compose.material.pullrefresh.PullRefreshIndicator
import androidx.compose.material.pullrefresh.pullRefresh
import androidx.compose.material.pullrefresh.rememberPullRefreshState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.openwave.app.R
import com.openwave.app.domain.model.Track
import com.openwave.app.presentation.components.SectionHeader
import com.openwave.app.presentation.navigation.Screen
import com.openwave.app.presentation.theme.*
import com.openwave.app.presentation.viewmodel.PlayerViewModel

/**
 * Home Screen
 * Main screen with personalized content, trending tracks, and recommendations
 */
@OptIn(ExperimentalMaterialApi::class)
@Composable
fun HomeScreen(
    navController: NavController,
    playerViewModel: PlayerViewModel,
    onTrackClick: (Track, List<Track>) -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    
    val pullRefreshState = rememberPullRefreshState(
        refreshing = uiState.isRefreshing,
        onRefresh = { viewModel.refresh() }
    )
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .pullRefresh(pullRefreshState)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            // Greeting Header
            item {
                GreetingHeader(
                    username = currentUser?.displayName,
                    points = currentUser?.points ?: 0,
                    level = currentUser?.level ?: 1
                )
            }
            
            // Trending Tracks
            item {
                SectionHeader(
                    title = stringResource(R.string.trending_now),
                    onSeeAllClick = { /* Navigate to trending */ }
                )
            }
            
            item {
                TrackRow(
                    tracks = uiState.trendingTracks,
                    onTrackClick = onTrackClick
                )
            }
            
            // New Releases
            item {
                SectionHeader(
                    title = stringResource(R.string.new_releases),
                    onSeeAllClick = { /* Navigate to new releases */ }
                )
            }
            
            item {
                TrackRow(
                    tracks = uiState.newReleases,
                    onTrackClick = onTrackClick
                )
            }
            
            // Recommended For You
            if (uiState.recommendations.isNotEmpty()) {
                item {
                    SectionHeader(
                        title = stringResource(R.string.recommended_for_you),
                        onSeeAllClick = { /* Navigate to recommendations */ }
                    )
                }
                
                item {
                    TrackRow(
                        tracks = uiState.recommendations,
                        onTrackClick = onTrackClick
                    )
                }
            }
            
            // Recently Played
            if (uiState.recentlyPlayed.isNotEmpty()) {
                item {
                    SectionHeader(
                        title = stringResource(R.string.recently_played),
                        onSeeAllClick = { /* Navigate to history */ }
                    )
                }
                
                items(uiState.recentlyPlayed) { track ->
                    TrackListItem(
                        track = track,
                        onClick = { onTrackClick(track, uiState.recentlyPlayed) }
                    )
                }
            }
        }
        
        // Pull refresh indicator
        PullRefreshIndicator(
            refreshing = uiState.isRefreshing,
            state = pullRefreshState,
            modifier = Modifier.align(Alignment.TopCenter),
            backgroundColor = DarkSurface,
            contentColor = SpotifyGreen
        )
    }
}

@Composable
fun GreetingHeader(
    username: String?,
    points: Int,
    level: Int
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Text(
            text = stringResource(R.string.greeting, username ?: stringResource(R.string.guest)),
            style = CustomTypography.SectionTitle,
            color = TextPrimary
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Level Badge
            Surface(
                color = SpotifyGreen.copy(alpha = 0.2f),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    text = "Lv. $level",
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelMedium,
                    color = SpotifyGreen
                )
            }
            
            Spacer(modifier = Modifier.width(8.dp))
            
            // Points Badge
            Surface(
                color = AccentBlue.copy(alpha = 0.2f),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    text = "$points ${stringResource(R.string.points)}",
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelMedium,
                    color = AccentBlue
                )
            }
        }
    }
}

@Composable
fun TrackRow(
    tracks: List<Track>,
    onTrackClick: (Track, List<Track>) -> Unit
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(tracks) { track ->
            TrackCard(
                track = track,
                onClick = { onTrackClick(track, tracks) }
            )
        }
    }
}

@Composable
fun TrackCard(
    track: Track,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .width(140.dp)
            .clickable(onClick = onClick)
    ) {
        // Cover Image
        AsyncImage(
            model = track.coverUrl ?: R.drawable.placeholder_cover,
            contentDescription = track.title,
            modifier = Modifier
                .size(140.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(DarkElevated),
            contentScale = ContentScale.Crop
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        // Title
        Text(
            text = track.title,
            style = CustomTypography.TrackTitle,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        
        // Artist
        Text(
            text = track.artist,
            style = CustomTypography.ArtistName,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun TrackListItem(
    track: Track,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Cover Image
        AsyncImage(
            model = track.coverUrl ?: R.drawable.placeholder_cover,
            contentDescription = track.title,
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(DarkElevated),
            contentScale = ContentScale.Crop
        )
        
        Spacer(modifier = Modifier.width(12.dp))
        
        // Track Info
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = track.title,
                style = CustomTypography.TrackTitle,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            
            Text(
                text = track.artist,
                style = CustomTypography.ArtistName,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        
        // Duration
        Text(
            text = track.displayDuration,
            style = MaterialTheme.typography.bodySmall,
            color = TextTertiary
        )
    }
}
