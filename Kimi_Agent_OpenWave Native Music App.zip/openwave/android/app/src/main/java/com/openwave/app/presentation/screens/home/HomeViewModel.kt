package com.openwave.app.presentation.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.openwave.app.data.remote.Result
import com.openwave.app.data.repository.AuthRepository
import com.openwave.app.data.repository.TrackRepository
import com.openwave.app.domain.model.Track
import com.openwave.app.domain.model.User
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

data class HomeUiState(
    val isLoading: Boolean = false,
    val isRefreshing: Boolean = false,
    val trendingTracks: List<Track> = emptyList(),
    val newReleases: List<Track> = emptyList(),
    val recommendations: List<Track> = emptyList(),
    val recentlyPlayed: List<Track> = emptyList(),
    val errorMessage: String? = null
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val trackRepository: TrackRepository,
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    init {
        loadUser()
        loadData()
    }

    private fun loadUser() {
        viewModelScope.launch {
            val userId = authRepository.getCurrentUserId()
            userId?.let {
                when (val result = authRepository.getUserProfile(it)) {
                    is Result.Success -> _currentUser.value = result.data
                    is Result.Error -> Timber.e("Failed to load user: ${result.message}")
                    else -> {}
                }
            }
        }
    }

    fun loadData() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            
            // Load trending tracks
            when (val result = trackRepository.getTrendingTracks(10)) {
                is Result.Success -> {
                    _uiState.value = _uiState.value.copy(trendingTracks = result.data)
                }
                is Result.Error -> Timber.e("Failed to load trending: ${result.message}")
                else -> {}
            }
            
            // Load new releases
            when (val result = trackRepository.getNewReleases(10)) {
                is Result.Success -> {
                    _uiState.value = _uiState.value.copy(newReleases = result.data)
                }
                is Result.Error -> Timber.e("Failed to load new releases: ${result.message}")
                else -> {}
            }
            
            // Load recently played
            val userId = authRepository.getCurrentUserId()
            userId?.let {
                when (val result = trackRepository.getListeningHistory(it, 10)) {
                    is Result.Success -> {
                        val tracks = result.data.mapNotNull { it.track }
                        _uiState.value = _uiState.value.copy(recentlyPlayed = tracks)
                    }
                    is Result.Error -> Timber.e("Failed to load history: ${result.message}")
                    else -> {}
                }
            }
            
            _uiState.value = _uiState.value.copy(isLoading = false)
        }
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isRefreshing = true)
            loadData()
            _uiState.value = _uiState.value.copy(isRefreshing = false)
        }
    }
}
