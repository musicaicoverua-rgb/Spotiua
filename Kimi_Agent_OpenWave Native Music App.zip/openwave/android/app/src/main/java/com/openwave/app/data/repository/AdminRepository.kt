package com.openwave.app.data.repository

import android.net.Uri
import com.openwave.app.data.remote.Result
import com.openwave.app.data.remote.SupabaseClientProvider
import com.openwave.app.domain.model.DashboardStats
import com.openwave.app.domain.model.DailyStats
import com.openwave.app.domain.model.Track
import io.github.jan.tensort.supabase.postgrest.query.Columns
import io.github.jan.tensort.supabase.postgrest.query.Order
import io.github.jan.tensort.supabase.storage.upload
import kotlinx.serialization.json.JsonObject
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Admin Repository
 * Handles admin-specific operations like track uploads, analytics, and user management
 */
@Singleton
class AdminRepository @Inject constructor(
    private val supabase: SupabaseClientProvider
) {
    /**
     * Upload track audio file
     */
    suspend fun uploadAudioFile(trackId: String, fileUri: Uri, fileName: String): Result<String> {
        return try {
            val path = "uploads/$trackId/$fileName"
            
            // Upload to Supabase Storage
            supabase.storage
                .from("music-files")
                .upload(path, fileUri)
            
            // Get public URL
            val url = supabase.storage
                .from("music-files")
                .publicUrl(path)
            
            Result.Success(url)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Upload track cover image
     */
    suspend fun uploadCoverImage(trackId: String, fileUri: Uri, fileName: String): Result<String> {
        return try {
            val path = "$trackId/$fileName"
            
            supabase.storage
                .from("covers")
                .upload(path, fileUri)
            
            val url = supabase.storage
                .from("covers")
                .publicUrl(path)
            
            Result.Success(url)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Create new track
     */
    suspend fun createTrack(
        title: String,
        artist: String,
        album: String? = null,
        genre: String? = null,
        audioUrl: String,
        coverUrl: String? = null,
        uploadedBy: String
    ): Result<Track> {
        return try {
            val track = Track(
                id = "", // Will be generated
                title = title,
                artist = artist,
                album = album,
                genre = genre,
                audioUrl = audioUrl,
                coverUrl = coverUrl,
                uploadedBy = uploadedBy,
                isProcessed = false
            )
            
            val response = supabase.database
                .from("tracks")
                .insert(track) { select() }
                .decodeSingleOrNull<Track>()
            
            response?.let { Result.Success(it) }
                ?: Result.Error(Exception("Failed to create track"))
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Update track
     */
    suspend fun updateTrack(track: Track): Result<Track> {
        return try {
            supabase.database
                .from("tracks")
                .update(track) {
                    filter {
                        eq("id", track.id)
                    }
                }
            
            Result.Success(track)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Delete track
     */
    suspend fun deleteTrack(trackId: String): Result<Unit> {
        return try {
            // Delete from database
            supabase.database
                .from("tracks")
                .delete {
                    filter {
                        eq("id", trackId)
                    }
                }
            
            // Delete files from storage
            try {
                supabase.storage
                    .from("music-files")
                    .delete(listOf("uploads/$trackId"))
                
                supabase.storage
                    .from("covers")
                    .delete(listOf(trackId))
            } catch (e: Exception) {
                // Ignore storage deletion errors
            }
            
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Get dashboard statistics
     */
    suspend fun getDashboardStats(): Result<DashboardStats> {
        return try {
            // Total users
            val totalUsers = supabase.database
                .from("users")
                .select(Columns.list("id", head = true))
                .decodeList<Map<String, String>>()
                .size
            
            // Active users (last 7 days)
            val activeUsers = supabase.database
                .from("users")
                .select(Columns.list("id", head = true)) {
                    filter {
                        gte("updated_at", "now() - interval '7 days'")
                    }
                }
                .decodeList<Map<String, String>>()
                .size
            
            // Total plays
            val totalPlays = supabase.database
                .from("analytics")
                .select(Columns.list("id", head = true)) {
                    filter {
                        eq("event_type", "track_play")
                    }
                }
                .decodeList<Map<String, String>>()
                .size
            
            // Total tracks
            val totalTracks = supabase.database
                .from("tracks")
                .select(Columns.list("id", head = true))
                .decodeList<Map<String, String>>()
                .size
            
            // Total playlists
            val totalPlaylists = supabase.database
                .from("playlists")
                .select(Columns.list("id", head = true))
                .decodeList<Map<String, String>>()
                .size
            
            // Plays today
            val playsToday = supabase.database
                .from("analytics")
                .select(Columns.list("id", head = true)) {
                    filter {
                        eq("event_type", "track_play")
                        gte("timestamp", "today()")
                    }
                }
                .decodeList<Map<String, String>>()
                .size
            
            // New users today
            val newUsersToday = supabase.database
                .from("users")
                .select(Columns.list("id", head = true)) {
                    filter {
                        gte("created_at", "today()")
                    }
                }
                .decodeList<Map<String, String>>()
                .size
            
            Result.Success(
                DashboardStats(
                    totalUsers = totalUsers,
                    activeUsers = activeUsers,
                    totalPlays = totalPlays,
                    totalTracks = totalTracks,
                    totalPlaylists = totalPlaylists,
                    playsToday = playsToday,
                    newUsersToday = newUsersToday
                )
            )
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Get top tracks
     */
    suspend fun getTopTracks(limit: Int = 10): Result<List<Track>> {
        return try {
            val response = supabase.database
                .from("tracks")
                .select(Columns.list("id, title, artist, cover_url, plays, created_at")) {
                    order("plays", Order.DESCENDING)
                    limit(limit)
                }
                .decodeList<Track>()
            
            Result.Success(response)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Get daily statistics
     */
    suspend fun getDailyStats(days: Int = 30): Result<List<DailyStats>> {
        return try {
            val response = supabase.database
                .from("analytics")
                .select(Columns.list("event_type, timestamp")) {
                    filter {
                        gte("timestamp", "now() - interval '$days days'")
                    }
                    order("timestamp", Order.ASCENDING)
                }
                .decodeList<AnalyticsEventRaw>()
            
            // Group by date
            val grouped = response.groupBy { it.timestamp.substring(0, 10) }
                .map { (date, events) ->
                    DailyStats(
                        date = date,
                        plays = events.count { it.eventType == "track_play" },
                        logins = events.count { it.eventType == "user_login" },
                        likes = events.count { it.eventType == "track_like" },
                        playlistCreates = events.count { it.eventType == "playlist_create" }
                    )
                }
            
            Result.Success(grouped)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Get all users (for admin)
     */
    suspend fun getAllUsers(page: Int = 0, pageSize: Int = 50): Result<List<Map<String, Any>>> {
        return try {
            val response = supabase.database
                .from("users")
                .select(Columns.list("id, email, username, role, avatar_url, points, coins, level, total_listening_time, created_at")) {
                    order("created_at", Order.DESCENDING)
                    range(page * pageSize, (page + 1) * pageSize - 1)
                }
                .decodeList<Map<String, Any>>()
            
            Result.Success(response)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Process audio file (trigger edge function)
     */
    suspend fun processAudio(trackId: String, filePath: String, fileName: String): Result<Unit> {
        return try {
            // Call edge function
            supabase.client.functions.invoke(
                "audio-processor",
                body = mapOf(
                    "trackId" to trackId,
                    "filePath" to filePath,
                    "fileName" to fileName
                )
            )
            
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    @kotlinx.serialization.Serializable
    private data class AnalyticsEventRaw(
        @kotlinx.serialization.SerialName("event_type")
        val eventType: String,
        val timestamp: String
    )
}
