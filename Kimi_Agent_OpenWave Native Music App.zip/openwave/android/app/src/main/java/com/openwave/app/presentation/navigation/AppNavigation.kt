package com.openwave.app.presentation.navigation

import androidx.compose.runtime.Composable
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.openwave.app.presentation.screens.admin.*
import com.openwave.app.presentation.screens.auth.*
import com.openwave.app.presentation.screens.home.HomeScreen
import com.openwave.app.presentation.screens.library.LibraryScreen
import com.openwave.app.presentation.screens.leaderboard.LeaderboardScreen
import com.openwave.app.presentation.screens.player.FullPlayerScreen
import com.openwave.app.presentation.screens.radio.RadioScreen
import com.openwave.app.presentation.screens.search.SearchScreen
import com.openwave.app.presentation.screens.spin.SpinScreen
import com.openwave.app.presentation.screens.support.SupportScreen
import com.openwave.app.presentation.viewmodel.AuthViewModel
import com.openwave.app.presentation.viewmodel.PlayerViewModel

/**
 * App Navigation
 * Defines all navigation routes and their corresponding screens
 */
@Composable
fun AppNavigation(
    navController: NavHostController,
    authViewModel: AuthViewModel,
    playerViewModel: PlayerViewModel,
    startDestination: String
) {
    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        // ==================== AUTH SCREENS ====================
        
        composable(Screen.Login.route) {
            LoginScreen(
                onNavigateToRegister = { navController.navigate(Screen.Register.route) },
                onNavigateToAdmin = { navController.navigate(Screen.AdminLogin.route) },
                onLoginSuccess = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                },
                viewModel = authViewModel
            )
        }
        
        composable(Screen.Register.route) {
            RegisterScreen(
                onNavigateToLogin = { navController.navigateUp() },
                onRegisterSuccess = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                },
                viewModel = authViewModel
            )
        }
        
        composable(Screen.AdminLogin.route) {
            AdminLoginScreen(
                onNavigateBack = { navController.navigateUp() },
                onLoginSuccess = {
                    navController.navigate(Screen.AdminDashboard.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                },
                viewModel = authViewModel
            )
        }
        
        // ==================== MAIN SCREENS ====================
        
        composable(Screen.Home.route) {
            HomeScreen(
                navController = navController,
                playerViewModel = playerViewModel,
                onTrackClick = { track, tracks ->
                    playerViewModel.playTrack(track, tracks)
                }
            )
        }
        
        composable(Screen.Search.route) {
            SearchScreen(
                navController = navController,
                playerViewModel = playerViewModel,
                onTrackClick = { track, tracks ->
                    playerViewModel.playTrack(track, tracks)
                }
            )
        }
        
        composable(Screen.Library.route) {
            LibraryScreen(
                navController = navController,
                playerViewModel = playerViewModel,
                onTrackClick = { track, tracks ->
                    playerViewModel.playTrack(track, tracks)
                }
            )
        }
        
        composable(Screen.Leaderboard.route) {
            LeaderboardScreen(
                navController = navController
            )
        }
        
        composable(Screen.Radio.route) {
            RadioScreen(
                navController = navController,
                playerViewModel = playerViewModel,
                onTrackClick = { track, tracks ->
                    playerViewModel.playTrack(track, tracks)
                }
            )
        }
        
        composable(Screen.Spin.route) {
            SpinScreen(
                navController = navController
            )
        }
        
        composable(Screen.Support.route) {
            SupportScreen(
                navController = navController
            )
        }
        
        // ==================== PLAYER SCREENS ====================
        
        composable(Screen.FullPlayer.route) {
            FullPlayerScreen(
                navController = navController,
                viewModel = playerViewModel,
                onNavigateBack = { navController.navigateUp() }
            )
        }
        
        // ==================== ADMIN SCREENS ====================
        
        composable(Screen.AdminDashboard.route) {
            AdminDashboardScreen(
                navController = navController,
                onLogout = {
                    authViewModel.signOut()
                    navController.navigate(Screen.Login.route) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }
        
        composable(Screen.AdminUpload.route) {
            AdminUploadScreen(
                navController = navController,
                onNavigateBack = { navController.navigateUp() }
            )
        }
        
        composable(Screen.AdminTracks.route) {
            AdminTracksScreen(
                navController = navController,
                onTrackClick = { track, tracks ->
                    playerViewModel.playTrack(track, tracks)
                }
            )
        }
        
        composable(Screen.AdminAnalytics.route) {
            AdminAnalyticsScreen(
                navController = navController
            )
        }
        
        composable(Screen.AdminMessages.route) {
            AdminMessagesScreen(
                navController = navController
            )
        }
        
        // ==================== DETAIL SCREENS ====================
        
        composable(
            route = Screen.PlaylistDetail.route,
            arguments = listOf(
                navArgument("playlistId") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val playlistId = backStackEntry.arguments?.getString("playlistId") ?: ""
            // PlaylistDetailScreen(playlistId = playlistId, ...)
        }
    }
}
