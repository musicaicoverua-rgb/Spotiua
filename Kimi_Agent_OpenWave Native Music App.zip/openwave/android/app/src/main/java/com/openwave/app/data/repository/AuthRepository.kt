package com.openwave.app.data.repository

import com.openwave.app.data.remote.Result
import com.openwave.app.data.remote.SupabaseClientProvider
import com.openwave.app.domain.model.User
import com.openwave.app.domain.model.UserRole
import io.github.jan.tensort.supabase.gotrue.providers.builtin.Email
import io.github.jan.tensort.supabase.gotrue.user.UserInfo
import io.github.jan.tensort.supabase.postgrest.query.Columns
import io.github.jan.tensort.supabase.postgrest.query.filter.FilterOperation
import io.github.jan.tensort.supabase.postgrest.query.filter.FilterOperator
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Authentication Repository
 * Handles user authentication, registration, and profile management
 */
@Singleton
class AuthRepository @Inject constructor(
    private val supabase: SupabaseClientProvider
) {
    private val json = Json { ignoreUnknownKeys = true }
    
    /**
     * Check if user is currently logged in
     */
    fun isLoggedIn(): Boolean {
        return supabase.auth.currentSessionOrNull() != null
    }
    
    /**
     * Get current user ID
     */
    fun getCurrentUserId(): String? {
        return supabase.auth.currentUserOrNull()?.id
    }
    
    /**
     * Get current user session
     */
    fun getCurrentSession() = supabase.auth.currentSessionOrNull()
    
    /**
     * Sign up with email and password
     */
    suspend fun signUp(email: String, password: String, username: String? = null): Result<User> {
        return try {
            // Create auth user
            val authResponse = supabase.auth.signUpWith(Email) {
                this.email = email
                this.password = password
            }
            
            val userId = authResponse?.id ?: throw Exception("Failed to create user")
            
            // Create user profile in database
            val newUser = User(
                id = userId,
                email = email,
                username = username,
                role = UserRole.USER
            )
            
            supabase.database.from("users").insert(newUser)
            
            Result.Success(newUser)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Sign in with email and password
     */
    suspend fun signIn(email: String, password: String): Result<User> {
        return try {
            supabase.auth.signInWith(Email) {
                this.email = email
                this.password = password
            }
            
            // Get user profile
            val userId = getCurrentUserId() ?: throw Exception("Login failed")
            getUserProfile(userId)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Admin login - verifies admin role
     */
    suspend fun adminSignIn(email: String, password: String): Result<User> {
        return try {
            supabase.auth.signInWith(Email) {
                this.email = email
                this.password = password
            }
            
            val userId = getCurrentUserId() ?: throw Exception("Login failed")
            val result = getUserProfile(userId)
            
            when (result) {
                is Result.Success -> {
                    if (result.data.role != UserRole.ADMIN) {
                        signOut()
                        Result.Error(Exception("Access denied. Admin only."))
                    } else {
                        Result.Success(result.data)
                    }
                }
                is Result.Error -> result
                else -> Result.Error(Exception("Unknown error"))
            }
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Sign out
     */
    suspend fun signOut(): Result<Unit> {
        return try {
            supabase.auth.signOut()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Get user profile from database
     */
    suspend fun getUserProfile(userId: String): Result<User> {
        return try {
            val response = supabase.database
                .from("users")
                .select(Columns.list("*")) {
                    filter {
                        eq("id", userId)
                    }
                }
                .decodeSingleOrNull<User>()
            
            response?.let { Result.Success(it) } 
                ?: Result.Error(Exception("User not found"))
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Update user profile
     */
    suspend fun updateUserProfile(user: User): Result<User> {
        return try {
            supabase.database
                .from("users")
                .update(user) {
                    filter {
                        eq("id", user.id)
                    }
                }
            
            Result.Success(user)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Update user avatar
     */
    suspend fun updateAvatar(userId: String, avatarUrl: String): Result<String> {
        return try {
            supabase.database
                .from("users")
                .update(
                    buildJsonObject {
                        put("avatar_url", avatarUrl)
                    }
                ) {
                    filter {
                        eq("id", userId)
                    }
                }
            
            Result.Success(avatarUrl)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Reset password
     */
    suspend fun resetPassword(email: String): Result<Unit> {
        return try {
            supabase.auth.resetPasswordForEmail(email)
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Update password
     */
    suspend fun updatePassword(newPassword: String): Result<Unit> {
        return try {
            supabase.auth.modifyUser {
                password = newPassword
            }
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Refresh session
     */
    suspend fun refreshSession(): Result<Unit> {
        return try {
            supabase.auth.refreshCurrentSession()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Observe auth state changes
     */
    fun observeAuthState(): Flow<Result<User?>> = flow {
        try {
            supabase.auth.sessionStatus.collect { session ->
                when (session) {
                    is io.github.jan.tensort.supabase.gotrue.SessionStatus.Authenticated -> {
                        val userId = session.session.user?.id
                        userId?.let {
                            emit(getUserProfile(it))
                        } ?: emit(Result.Success(null))
                    }
                    else -> emit(Result.Success(null))
                }
            }
        } catch (e: Exception) {
            emit(Result.Error(e))
        }
    }
}
