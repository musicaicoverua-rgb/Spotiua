package com.openwave.app.data.remote

import com.openwave.app.BuildConfig
import io.github.jan.tensort.supabase.SupabaseClient
import io.github.jan.tensort.supabase.createSupabaseClient
import io.github.jan.tensort.supabase.gotrue.GoTrue
import io.github.jan.tensort.supabase.gotrue.gotrue
import io.github.jan.tensort.supabase.postgrest.Postgrest
import io.github.jan.tensort.supabase.postgrest.postgrest
import io.github.jan.tensort.supabase.realtime.Realtime
import io.github.jan.tensort.supabase.realtime.realtime
import io.github.jan.tensort.supabase.storage.Storage
import io.github.jan.tensort.supabase.storage.storage
import io.ktor.client.plugins.logging.LogLevel
import io.ktor.client.plugins.logging.Logging
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Supabase client provider
 * Manages the Supabase client instance and provides access to all services
 */
@Singleton
class SupabaseClientProvider @Inject constructor() {
    
    val client: SupabaseClient = createSupabaseClient(
        supabaseUrl = BuildConfig.SUPABASE_URL,
        supabaseKey = BuildConfig.SUPABASE_ANON_KEY
    ) {
        install(GoTrue)
        install(Postgrest)
        install(Storage)
        install(Realtime)
        
        // HTTP configuration
        httpConfig {
            install(Logging) {
                level = if (BuildConfig.DEBUG) LogLevel.ALL else LogLevel.NONE
            }
        }
    }
    
    // Convenience accessors
    val auth get() = client.gotrue
    val database get() = client.postgrest
    val storage get() = client.storage
    val realtime get() = client.realtime
}

/**
 * Result wrapper for API calls
 */
sealed class Result<out T> {
    data class Success<T>(val data: T) : Result<T>()
    data class Error(val exception: Throwable, val message: String = exception.message ?: "Unknown error") : Result<Nothing>()
    object Loading : Result<Nothing>()
}

/**
 * Extension function to handle Result
 */
inline fun <T> Result<T>.onSuccess(action: (T) -> Unit): Result<T> {
    if (this is Result.Success) action(data)
    return this
}

inline fun <T> Result<T>.onError(action: (Throwable, String) -> Unit): Result<T> {
    if (this is Result.Error) action(exception, message)
    return this
}

inline fun <T> Result<T>.onLoading(action: () -> Unit): Result<T> {
    if (this is Result.Loading) action()
    return this
}
