package com.openwave.app.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/**
 * Offline Download DAO
 * Manages downloaded tracks for offline listening
 */
@Dao
interface OfflineDownloadDao {
    
    @Query("SELECT * FROM offline_downloads WHERE user_id = :userId ORDER BY downloaded_at DESC")
    fun getAllDownloadsFlow(userId: String): Flow<List<OfflineDownloadEntity>>
    
    @Query("SELECT * FROM offline_downloads WHERE user_id = :userId ORDER BY downloaded_at DESC")
    suspend fun getAllDownloads(userId: String): List<OfflineDownloadEntity>
    
    @Query("SELECT * FROM offline_downloads WHERE user_id = :userId AND track_id = :trackId LIMIT 1")
    suspend fun getDownload(userId: String, trackId: String): OfflineDownloadEntity?
    
    @Query("SELECT EXISTS(SELECT 1 FROM offline_downloads WHERE user_id = :userId AND track_id = :trackId)")
    suspend fun isDownloaded(userId: String, trackId: String): Boolean
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownload(download: OfflineDownloadEntity)
    
    @Delete
    suspend fun deleteDownload(download: OfflineDownloadEntity)
    
    @Query("DELETE FROM offline_downloads WHERE user_id = :userId AND track_id = :trackId")
    suspend fun deleteDownload(userId: String, trackId: String)
    
    @Query("DELETE FROM offline_downloads WHERE user_id = :userId")
    suspend fun deleteAllDownloads(userId: String)
    
    @Query("DELETE FROM offline_downloads WHERE expires_at < :currentTime")
    suspend fun deleteExpiredDownloads(currentTime: String)
    
    @Query("SELECT COUNT(*) FROM offline_downloads WHERE user_id = :userId")
    suspend fun getDownloadCount(userId: String): Int
}

/**
 * Offline Download Entity
 */
@Entity(
    tableName = "offline_downloads",
    indices = [Index(value = ["user_id", "track_id"], unique = true)]
)
data class OfflineDownloadEntity(
    @PrimaryKey
    val id: String,
    @ColumnInfo(name = "user_id")
    val userId: String,
    @ColumnInfo(name = "track_id")
    val trackId: String,
    @ColumnInfo(name = "local_path")
    val localPath: String,
    @ColumnInfo(name = "downloaded_at")
    val downloadedAt: String,
    @ColumnInfo(name = "expires_at")
    val expiresAt: String?
)
