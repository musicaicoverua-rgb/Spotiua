package com.openwave.app.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
nimport android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.net.toUri
import com.openwave.app.R
import com.openwave.app.data.local.OfflineDownloadDao
import com.openwave.app.data.remote.SupabaseClientProvider
import com.openwave.app.domain.model.OfflineDownload
import com.openwave.app.domain.model.Track
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File
import java.net.URL
import javax.inject.Inject

/**
 * Download Service
 * Handles downloading tracks for offline listening
 */
@AndroidEntryPoint
class DownloadService : Service() {

    companion object {
        const val CHANNEL_ID = "openwave_download_channel"
        const val NOTIFICATION_ID = 2
        const val ACTION_START_DOWNLOAD = "action_start_download"
        const val ACTION_CANCEL_DOWNLOAD = "action_cancel_download"
        const val EXTRA_TRACK = "extra_track"
        const val EXTRA_USER_ID = "extra_user_id"
    }

    @Inject
    lateinit var supabase: SupabaseClientProvider

    @Inject
    lateinit var offlineDownloadDao: OfflineDownloadDao

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var notificationManager: NotificationManager

    // Download state
    private val _downloadState = MutableStateFlow<DownloadState>(DownloadState.Idle)
    val downloadState: StateFlow<DownloadState> = _downloadState.asStateFlow()

    private val _downloadProgress = MutableStateFlow<Map<String, Float>>(emptyMap())
    val downloadProgress: StateFlow<Map<String, Float>> = _downloadProgress.asStateFlow()

    private val activeDownloads = mutableMapOf<String, kotlinx.coroutines.Job>()

    override fun onCreate() {
        super.onCreate()
        Timber.d("DownloadService created")
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.download_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.download_channel_description)
                setShowBadge(false)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_DOWNLOAD -> {
                val track = intent.getParcelableExtra<Track>(EXTRA_TRACK)
                val userId = intent.getStringExtra(EXTRA_USER_ID)
                if (track != null && userId != null) {
                    startDownload(track, userId)
                }
            }
            ACTION_CANCEL_DOWNLOAD -> {
                val trackId = intent.getStringExtra(EXTRA_TRACK)
                trackId?.let { cancelDownload(it) }
            }
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        activeDownloads.values.forEach { it.cancel() }
        activeDownloads.clear()
        Timber.d("DownloadService destroyed")
    }

    /**
     * Start downloading a track
     */
    private fun startDownload(track: Track, userId: String) {
        if (activeDownloads.containsKey(track.id)) {
            Timber.d("Download already in progress for track: ${track.id}")
            return
        }

        val job = serviceScope.launch {
            try {
                _downloadState.value = DownloadState.Downloading(track.id)
                updateNotification(track.title, 0)

                // Create local file
                val downloadsDir = getExternalFilesDir("downloads") 
                    ?: File(filesDir, "downloads").apply { mkdirs() }
                val trackDir = File(downloadsDir, track.id)
                trackDir.mkdirs()

                val audioFile = File(trackDir, "audio.mp3")
                val coverFile = track.coverUrl?.let { File(trackDir, "cover.jpg") }

                // Download audio file
                downloadFile(track.bestAudioUrl, audioFile) { progress ->
                    _downloadProgress.value = _downloadProgress.value + (track.id to progress)
                    updateNotification(track.title, (progress * 100).toInt())
                }

                // Download cover image if available
                track.coverUrl?.let { coverUrl ->
                    coverFile?.let { file ->
                        try {
                            downloadFile(coverUrl, file, null)
                        } catch (e: Exception) {
                            Timber.w(e, "Failed to download cover for track: ${track.id}")
                        }
                    }
                }

                // Save to database
                val offlineDownload = OfflineDownload(
                    id = "",
                    userId = userId,
                    trackId = track.id,
                    localPath = audioFile.absolutePath,
                    downloadedAt = java.time.Instant.now().toString(),
                    expiresAt = java.time.Instant.now().plusSeconds(30 * 24 * 60 * 60).toString() // 30 days
                )

                offlineDownloadDao.insertDownload(offlineDownload)

                _downloadState.value = DownloadState.Completed(track.id)
                updateNotificationComplete(track.title)

                Timber.d("Download completed for track: ${track.id}")

            } catch (e: Exception) {
                Timber.e(e, "Download failed for track: ${track.id}")
                _downloadState.value = DownloadState.Error(track.id, e.message ?: "Download failed")
                updateNotificationError(track.title)
            } finally {
                activeDownloads.remove(track.id)
                _downloadProgress.value = _downloadProgress.value - track.id

                if (activeDownloads.isEmpty()) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
        }

        activeDownloads[track.id] = job
    }

    /**
     * Cancel an active download
     */
    private fun cancelDownload(trackId: String) {
        activeDownloads[trackId]?.cancel()
        activeDownloads.remove(trackId)
        _downloadProgress.value = _downloadProgress.value - trackId
        _downloadState.value = DownloadState.Cancelled(trackId)
    }

    /**
     * Download file from URL
     */
    private suspend fun downloadFile(
        urlString: String, 
        destination: File,
        onProgress: ((Float) -> Unit)?
    ) = withContext(Dispatchers.IO) {
        val url = URL(urlString)
        val connection = url.openConnection()
        connection.connect()

        val totalSize = connection.contentLength
        val input = connection.getInputStream()
        val output = destination.outputStream()

        val buffer = ByteArray(8192)
        var downloaded = 0
        var read: Int

        while (input.read(buffer).also { read = it } != -1) {
            output.write(buffer, 0, read)
            downloaded += read

            if (totalSize > 0 && onProgress != null) {
                onProgress(downloaded.toFloat() / totalSize)
            }
        }

        output.flush()
        output.close()
        input.close()
    }

    /**
     * Delete downloaded track
     */
    suspend fun deleteDownload(trackId: String, userId: String) {
        try {
            // Delete from database
            offlineDownloadDao.deleteDownload(userId, trackId)

            // Delete files
            val downloadsDir = getExternalFilesDir("downloads")
            val trackDir = File(downloadsDir, trackId)
            if (trackDir.exists()) {
                trackDir.deleteRecursively()
            }

            Timber.d("Download deleted for track: $trackId")
        } catch (e: Exception) {
            Timber.e(e, "Failed to delete download for track: $trackId")
        }
    }

    /**
     * Check if track is downloaded
     */
    suspend fun isTrackDownloaded(trackId: String, userId: String): Boolean {
        return offlineDownloadDao.getDownload(userId, trackId) != null
    }

    /**
     * Get downloaded tracks
     */
    suspend fun getDownloadedTracks(userId: String): List<OfflineDownload> {
        return offlineDownloadDao.getAllDownloads(userId)
    }

    // ==================== NOTIFICATIONS ====================

    private fun updateNotification(trackTitle: String, progress: Int) {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.downloading_track, trackTitle))
            .setContentText("$progress%")
            .setSmallIcon(R.drawable.ic_download)
            .setProgress(100, progress, false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun updateNotificationComplete(trackTitle: String) {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.download_complete))
            .setContentText(trackTitle)
            .setSmallIcon(R.drawable.ic_download_complete)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(NOTIFICATION_ID + 1, notification)
    }

    private fun updateNotificationError(trackTitle: String) {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.download_failed))
            .setContentText(trackTitle)
            .setSmallIcon(R.drawable.ic_download_error)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(NOTIFICATION_ID + 2, notification)
    }
}

/**
 * Download state sealed class
 */
sealed class DownloadState {
    object Idle : DownloadState()
    data class Downloading(val trackId: String) : DownloadState()
    data class Completed(val trackId: String) : DownloadState()
    data class Error(val trackId: String, val message: String) : DownloadState()
    data class Cancelled(val trackId: String) : DownloadState()
}
