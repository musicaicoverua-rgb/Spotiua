package com.openwave.app.data.repository

import com.openwave.app.data.remote.Result
import com.openwave.app.data.remote.SupabaseClientProvider
import com.openwave.app.domain.model.Message
import io.github.jan.tensort.supabase.postgrest.query.Columns
import io.github.jan.tensort.supabase.postgrest.query.Order
import io.github.jan.tensort.supabase.realtime.RealtimeChannel
import io.github.jan.tensort.supabase.realtime.realtime
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Chat Repository
 * Handles user-admin messaging with real-time updates
 */
@Singleton
class ChatRepository @Inject constructor(
    private val supabase: SupabaseClientProvider
) {
    private var messageChannel: RealtimeChannel? = null
    
    /**
     * Get user's messages
     */
    suspend fun getUserMessages(userId: String): Result<List<Message>> {
        return try {
            val response = supabase.database
                .from("messages")
                .select(Columns.list("*")) {
                    filter {
                        eq("user_id", userId)
                    }
                    order("created_at", Order.ASCENDING)
                }
                .decodeList<Message>()
            
            Result.Success(response)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Get all messages (for admin)
     */
    suspend fun getAllMessages(limit: Int = 100): Result<List<Message>> {
        return try {
            val response = supabase.database
                .from("messages")
                .select(Columns.list("*, users!messages_user_id_fkey(*)") {
                    order("created_at", Order.DESCENDING)
                    limit(limit)
                })
                .decodeList<Message>()
            
            Result.Success(response)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Send message
     */
    suspend fun sendMessage(userId: String, message: String): Result<Message> {
        return try {
            val newMessage = Message(
                id = "",
                userId = userId,
                message = message,
                isRead = false
            )
            
            val response = supabase.database
                .from("messages")
                .insert(newMessage) { select() }
                .decodeSingleOrNull<Message>()
            
            response?.let { Result.Success(it) }
                ?: Result.Error(Exception("Failed to send message"))
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Reply to message (admin only)
     */
    suspend fun replyToMessage(messageId: String, reply: String, adminId: String): Result<Message> {
        return try {
            supabase.database
                .from("messages")
                .update(
                    buildJsonObject {
                        put("reply", reply)
                        put("replied_by", adminId)
                        put("replied_at", "now()")
                        put("is_read", true)
                    }
                ) {
                    filter {
                        eq("id", messageId)
                    }
                }
            
            // Get updated message
            val response = supabase.database
                .from("messages")
                .select(Columns.list("*")) {
                    filter {
                        eq("id", messageId)
                    }
                }
                .decodeSingleOrNull<Message>()
            
            response?.let { Result.Success(it) }
                ?: Result.Error(Exception("Message not found"))
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Mark messages as read
     */
    suspend fun markAsRead(messageIds: List<String>, userId: String): Result<Unit> {
        return try {
            supabase.database
                .from("messages")
                .update(
                    buildJsonObject {
                        put("is_read", true)
                    }
                ) {
                    filter {
                        isIn("id", messageIds)
                        eq("user_id", userId)
                    }
                }
            
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Get unread message count
     */
    suspend fun getUnreadCount(userId: String, isAdmin: Boolean = false): Result<Int> {
        return try {
            val query = supabase.database
                .from("messages")
                .select(Columns.list("id", head = true)) {
                    filter {
                        eq("is_read", false)
                    }
                }
            
            val response = if (isAdmin) {
                // Admin sees unread user messages
                query.decodeList<Map<String, String>>()
            } else {
                // User sees unread replies
                query.decodeList<Map<String, String>>()
            }
            
            Result.Success(response.size)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Subscribe to real-time messages
     */
    fun subscribeToMessages(userId: String? = null): Flow<Result<Message>> = flow {
        try {
            messageChannel = supabase.realtime.createChannel("messages") {
                table("messages", schema = "public") {
                    if (userId != null) {
                        filter("user_id", io.github.jan.tensort.supabase.realtime.eq(userId))
                    }
                }
            }
            
            messageChannel?.subscribe()
            
            messageChannel?.messageFlow?.collect { message ->
                try {
                    val decoded = kotlinx.serialization.json.Json.decodeFromString<Message>(message.toString())
                    emit(Result.Success(decoded))
                } catch (e: Exception) {
                    emit(Result.Error(e))
                }
            }
        } catch (e: Exception) {
            emit(Result.Error(e))
        }
    }
    
    /**
     * Unsubscribe from messages
     */
    suspend fun unsubscribeFromMessages() {
        messageChannel?.unsubscribe()
        messageChannel = null
    }
    
    /**
     * Delete message
     */
    suspend fun deleteMessage(messageId: String): Result<Unit> {
        return try {
            supabase.database
                .from("messages")
                .delete {
                    filter {
                        eq("id", messageId)
                    }
                }
            
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
}
