package com.openwave.app.data.repository

import com.openwave.app.data.remote.Result
import com.openwave.app.data.remote.SupabaseClientProvider
import com.openwave.app.domain.model.*
import io.github.jan.tensort.supabase.postgrest.query.Columns
import io.github.jan.tensort.supabase.postgrest.query.Order
import io.github.jan.tensort.supabase.postgrest.rpc
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Track Repository
 * Handles all track-related operations including playlists, likes, and listening history
 */
@Singleton
class TrackRepository @Inject constructor(
    private val supabase: SupabaseClientProvider
) {
    /**
     * Get all tracks with pagination
     */
    suspend fun getTracks(page: Int = 0, pageSize: Int = 20): Result<List<Track>> {
        return try {
            val response = supabase.database
                .from("tracks")
                .select(Columns.list("*")) {
                    order("created_at", Order.DESCENDING)
                    range(page * pageSize, (page + 1) * pageSize - 1)
                }
                .decodeList<Track>()
            
            Result.Success(response)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Get track by ID
     */
    suspend fun getTrack(trackId: String): Result<Track> {
        return try {
            val response = supabase.database
                .from("tracks")
                .select(Columns.list("*")) {
                    filter {
                        eq("id", trackId)
                    }
                }
                .decodeSingleOrNull<Track>()
            
            response?.let { Result.Success(it) }
                ?: Result.Error(Exception("Track not found"))
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Search tracks by title or artist
     */
    suspend fun searchTracks(query: String): Result<List<Track>> {
        return try {
            val response = supabase.database
                .from("tracks")
                .select(Columns.list("*")) {
                    filter {
                        or {
                            ilike("title", "%$query%")
                            ilike("artist", "%$query%")
                            ilike("album", "%$query%")
                        }
                    }
                    order("plays", Order.DESCENDING)
                    limit(50)
                }
                .decodeList<Track>()
            
            Result.Success(response)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Get tracks by genre
     */
    suspend fun getTracksByGenre(genre: String): Result<List<Track>> {
        return try {
            val response = supabase.database
                .from("tracks")
                .select(Columns.list("*")) {
                    filter {
                        eq("genre", genre)
                    }
                    order("plays", Order.DESCENDING)
                }
                .decodeList<Track>()
            
            Result.Success(response)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Get trending tracks (most played)
     */
    suspend fun getTrendingTracks(limit: Int = 20): Result<List<Track>> {
        return try {
            val response = supabase.database
                .from("tracks")
                .select(Columns.list("*")) {
                    order("plays", Order.DESCENDING)
                    limit(limit)
                }
                .decodeList<Track>()
            
            Result.Success(response)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Get new releases (recently added)
     */
    suspend fun getNewReleases(limit: Int = 20): Result<List<Track>> {
        return try {
            val response = supabase.database
                .from("tracks")
                .select(Columns.list("*")) {
                    order("created_at", Order.DESCENDING)
                    limit(limit)
                }
                .decodeList<Track>()
            
            Result.Success(response)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Increment track play count
     */
    suspend fun incrementPlays(trackId: String): Result<Unit> {
        return try {
            supabase.database.rpc("increment_track_plays", mapOf("track_uuid" to trackId))
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    // ==================== PLAYLISTS ====================
    
    /**
     * Get user's playlists
     */
    suspend fun getUserPlaylists(userId: String): Result<List<Playlist>> {
        return try {
            val response = supabase.database
                .from("playlists")
                .select(Columns.list("*")) {
                    filter {
                        eq("user_id", userId)
                    }
                    order("created_at", Order.DESCENDING)
                }
                .decodeList<Playlist>()
            
            Result.Success(response)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Get playlist by ID with tracks
     */
    suspend fun getPlaylist(playlistId: String): Result<Playlist> {
        return try {
            val playlist = supabase.database
                .from("playlists")
                .select(Columns.list("*")) {
                    filter {
                        eq("id", playlistId)
                    }
                }
                .decodeSingleOrNull<Playlist>()
            
            playlist ?: return Result.Error(Exception("Playlist not found"))
            
            // Get tracks in playlist
            val tracks = supabase.database
                .from("playlist_tracks")
                .select(Columns.list("*, tracks(*)")) {
                    filter {
                        eq("playlist_id", playlistId)
                    }
                    order("position", Order.ASCENDING)
                }
                .decodeList<Track>()
            
            Result.Success(playlist.copy(tracks = tracks, trackCount = tracks.size))
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Create new playlist
     */
    suspend fun createPlaylist(name: String, description: String? = null, userId: String): Result<Playlist> {
        return try {
            val playlist = Playlist(
                id = "", // Will be generated by Supabase
                name = name,
                description = description,
                userId = userId
            )
            
            val response = supabase.database
                .from("playlists")
                .insert(playlist) { select() }
                .decodeSingleOrNull<Playlist>()
            
            response?.let { Result.Success(it) }
                ?: Result.Error(Exception("Failed to create playlist"))
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Add track to playlist
     */
    suspend fun addTrackToPlaylist(playlistId: String, trackId: String): Result<Unit> {
        return try {
            val playlistTrack = PlaylistTrack(
                id = "",
                playlistId = playlistId,
                trackId = trackId
            )
            
            supabase.database
                .from("playlist_tracks")
                .insert(playlistTrack)
            
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Remove track from playlist
     */
    suspend fun removeTrackFromPlaylist(playlistId: String, trackId: String): Result<Unit> {
        return try {
            supabase.database
                .from("playlist_tracks")
                .delete {
                    filter {
                        eq("playlist_id", playlistId)
                        eq("track_id", trackId)
                    }
                }
            
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Delete playlist
     */
    suspend fun deletePlaylist(playlistId: String): Result<Unit> {
        return try {
            supabase.database
                .from("playlists")
                .delete {
                    filter {
                        eq("id", playlistId)
                    }
                }
            
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    // ==================== LIKES ====================
    
    /**
     * Get user's liked tracks
     */
    suspend fun getLikedTracks(userId: String): Result<List<Track>> {
        return try {
            val response = supabase.database
                .from("likes")
                .select(Columns.list("tracks(*)")) {
                    filter {
                        eq("user_id", userId)
                    }
                    order("created_at", Order.DESCENDING)
                }
                .decodeList<Track>()
            
            Result.Success(response)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Check if track is liked
     */
    suspend fun isTrackLiked(userId: String, trackId: String): Result<Boolean> {
        return try {
            val response = supabase.database
                .from("likes")
                .select(Columns.list("id")) {
                    filter {
                        eq("user_id", userId)
                        eq("track_id", trackId)
                    }
                }
                .decodeList<Like>()
            
            Result.Success(response.isNotEmpty())
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Like a track
     */
    suspend fun likeTrack(userId: String, trackId: String): Result<Unit> {
        return try {
            val like = Like(
                id = "",
                userId = userId,
                trackId = trackId
            )
            
            supabase.database
                .from("likes")
                .insert(like)
            
            // Log analytics
            logAnalytics(EventType.TRACK_LIKE, userId, trackId)
            
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Unlike a track
     */
    suspend fun unlikeTrack(userId: String, trackId: String): Result<Unit> {
        return try {
            supabase.database
                .from("likes")
                .delete {
                    filter {
                        eq("user_id", userId)
                        eq("track_id", trackId)
                    }
                }
            
            // Log analytics
            logAnalytics(EventType.TRACK_UNLIKE, userId, trackId)
            
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    // ==================== LISTENING HISTORY ====================
    
    /**
     * Get user's listening history
     */
    suspend fun getListeningHistory(userId: String, limit: Int = 50): Result<List<ListeningHistory>> {
        return try {
            val response = supabase.database
                .from("listening_history")
                .select(Columns.list("*, tracks(*)")) {
                    filter {
                        eq("user_id", userId)
                    }
                    order("played_at", Order.DESCENDING)
                    limit(limit)
                }
                .decodeList<ListeningHistory>()
            
            Result.Success(response)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Add listening history entry
     */
    suspend fun addListeningHistory(userId: String, trackId: String, duration: Int, completed: Boolean): Result<Unit> {
        return try {
            val history = ListeningHistory(
                id = "",
                userId = userId,
                trackId = trackId,
                playedAt = "", // Will be set by database
                duration = duration,
                completed = completed
            )
            
            supabase.database
                .from("listening_history")
                .insert(history)
            
            // Update user listening stats
            supabase.database.rpc(
                "update_user_listening_stats",
                mapOf(
                    "user_uuid" to userId,
                    "listen_duration" to (duration / 60).coerceAtLeast(1)
                )
            )
            
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    // ==================== ANALYTICS ====================
    
    /**
     * Log analytics event
     */
    private suspend fun logAnalytics(eventType: EventType, userId: String? = null, trackId: String? = null) {
        try {
            val event = AnalyticsEvent(
                id = "",
                eventType = eventType,
                userId = userId,
                trackId = trackId
            )
            
            supabase.database
                .from("analytics")
                .insert(event)
        } catch (e: Exception) {
            // Silently fail analytics
        }
    }
    
    /**
     * Log search query
     */
    suspend fun logSearch(userId: String?, query: String): Result<Unit> {
        return try {
            val event = AnalyticsEvent(
                id = "",
                eventType = EventType.SEARCH_QUERY,
                userId = userId,
                metadata = mapOf("query" to query)
            )
            
            supabase.database
                .from("analytics")
                .insert(event)
            
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
}
