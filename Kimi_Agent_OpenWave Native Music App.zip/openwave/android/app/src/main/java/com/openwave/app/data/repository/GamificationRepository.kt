package com.openwave.app.data.repository

import com.openwave.app.data.remote.Result
import com.openwave.app.data.remote.SupabaseClientProvider
import com.openwave.app.domain.model.*
import io.github.jan.tensort.supabase.postgrest.query.Columns
import io.github.jan.tensort.supabase.postgrest.query.Order
import io.github.jan.tensort.supabase.postgrest.rpc
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Gamification Repository
 * Handles points, coins, levels, daily rewards, and bonus wheel
 */
@Singleton
class GamificationRepository @Inject constructor(
    private val supabase: SupabaseClientProvider
) {
    /**
     * Claim daily reward
     */
    suspend fun claimDailyReward(userId: String): Result<DailyRewardResult> {
        return try {
            val response = supabase.database.rpc(
                "claim_daily_reward",
                mapOf("user_uuid" to userId)
            )
            
            val json = response as JsonObject
            val success = json["success"]?.jsonPrimitive?.content == "true"
            
            if (success) {
                val points = json["points"]?.jsonPrimitive?.content?.toIntOrNull() ?: 20
                val coins = json["coins"]?.jsonPrimitive?.content?.toIntOrNull() ?: 10
                Result.Success(DailyRewardResult(points, coins))
            } else {
                val message = json["message"]?.jsonPrimitive?.content ?: "Already claimed"
                Result.Error(Exception(message))
            }
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Check if daily reward is available
     */
    suspend fun isDailyRewardAvailable(userId: String): Result<Boolean> {
        return try {
            val response = supabase.database
                .from("daily_rewards")
                .select(Columns.list("*")) {
                    filter {
                        eq("user_id", userId)
                        eq("reward_date", "today()")
                    }
                }
                .decodeList<DailyReward>()
            
            Result.Success(response.isEmpty())
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Spin bonus wheel
     */
    suspend fun spinBonusWheel(userId: String): Result<WheelSpinResult> {
        return try {
            val response = supabase.database.rpc(
                "spin_bonus_wheel",
                mapOf("user_uuid" to userId)
            )
            
            val json = response as JsonObject
            val success = json["success"]?.jsonPrimitive?.content == "true"
            
            if (success) {
                val type = json["type"]?.jsonPrimitive?.content ?: "points"
                val amount = json["amount"]?.jsonPrimitive?.content?.toIntOrNull() ?: 0
                Result.Success(WheelSpinResult(RewardType.valueOf(type.uppercase()), amount))
            } else {
                val message = json["message"]?.jsonPrimitive?.content ?: "Already spun today"
                Result.Error(Exception(message))
            }
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Check if wheel spin is available
     */
    suspend fun isWheelSpinAvailable(userId: String): Result<Boolean> {
        return try {
            val response = supabase.database
                .from("wheel_spins")
                .select(Columns.list("*")) {
                    filter {
                        eq("user_id", userId)
                        eq("spin_date", "today()")
                    }
                }
                .decodeList<WheelSpin>()
            
            Result.Success(response.isEmpty())
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Get leaderboard by points
     */
    suspend fun getLeaderboardByPoints(limit: Int = 100): Result<List<LeaderboardEntry>> {
        return try {
            val response = supabase.database
                .from("users")
                .select(Columns.list("id, username, avatar_url, points, level")) {
                    filter {
                        eq("role", "user")
                    }
                    order("points", Order.DESCENDING)
                    limit(limit)
                }
                .decodeList<LeaderboardEntry>()
            
            // Add rank
            val ranked = response.mapIndexed { index, entry ->
                entry.copy(rank = (index + 1).toLong())
            }
            
            Result.Success(ranked)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Get leaderboard by listening time
     */
    suspend fun getLeaderboardByListeningTime(limit: Int = 100): Result<List<LeaderboardEntry>> {
        return try {
            val response = supabase.database
                .from("users")
                .select(Columns.list("id, username, avatar_url, total_listening_time, level")) {
                    filter {
                        eq("role", "user")
                    }
                    order("total_listening_time", Order.DESCENDING)
                    limit(limit)
                }
                .decodeList<LeaderboardEntry>()
            
            // Add rank
            val ranked = response.mapIndexed { index, entry ->
                entry.copy(rank = (index + 1).toLong())
            }
            
            Result.Success(ranked)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Get user's rank
     */
    suspend fun getUserRank(userId: String): Result<Int> {
        return try {
            val response = supabase.database
                .from("users")
                .select(Columns.list("id, points")) {
                    filter {
                        eq("role", "user")
                    }
                    order("points", Order.DESCENDING)
                }
                .decodeList<Map<String, String>>()
            
            val rank = response.indexOfFirst { it["id"] == userId } + 1
            Result.Success(if (rank > 0) rank else response.size + 1)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Add points to user
     */
    suspend fun addPoints(userId: String, points: Int): Result<Int> {
        return try {
            val user = supabase.database
                .from("users")
                .select(Columns.list("points")) {
                    filter {
                        eq("id", userId)
                    }
                }
                .decodeSingleOrNull<Map<String, Int>>()
            
            val currentPoints = user?.get("points") ?: 0
            val newPoints = currentPoints + points
            
            supabase.database
                .from("users")
                .update(
                    mapOf("points" to newPoints)
                ) {
                    filter {
                        eq("id", userId)
                    }
                }
            
            Result.Success(newPoints)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Add coins to user
     */
    suspend fun addCoins(userId: String, coins: Int): Result<Int> {
        return try {
            val user = supabase.database
                .from("users")
                .select(Columns.list("coins")) {
                    filter {
                        eq("id", userId)
                    }
                }
                .decodeSingleOrNull<Map<String, Int>>()
            
            val currentCoins = user?.get("coins") ?: 0
            val newCoins = currentCoins + coins
            
            supabase.database
                .from("users")
                .update(
                    mapOf("coins" to newCoins)
                ) {
                    filter {
                        eq("id", userId)
                    }
                }
            
            Result.Success(newCoins)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
    
    /**
     * Get level requirements
     */
    suspend fun getLevelRequirements(): Result<List<LevelRequirement>> {
        return try {
            val response = supabase.database
                .from("level_requirements")
                .select(Columns.list("*")) {
                    order("level", Order.ASCENDING)
                }
                .decodeList<LevelRequirement>()
            
            Result.Success(response)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }
}

/**
 * Daily reward result
 */
data class DailyRewardResult(
    val points: Int,
    val coins: Int
)

/**
 * Wheel spin result
 */
data class WheelSpinResult(
    val rewardType: RewardType,
    val amount: Int
)

/**
 * Level requirement
 */
@kotlinx.serialization.Serializable
data class LevelRequirement(
    val level: Int,
    @kotlinx.serialization.SerialName("points_required")
    val pointsRequired: Int,
    @kotlinx.serialization.SerialName("coins_reward")
    val coinsReward: Int = 0,
    val description: String? = null
)
