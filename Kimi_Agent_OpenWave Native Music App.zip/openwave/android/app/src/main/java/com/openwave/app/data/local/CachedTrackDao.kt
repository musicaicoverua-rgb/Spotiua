package com.openwave.app.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/**
 * Cached Track DAO
 * Manages cached track data for offline access
 */
@Dao
interface CachedTrackDao {
    
    @Query("SELECT * FROM cached_tracks ORDER BY cached_at DESC")
    fun getAllCachedTracksFlow(): Flow<List<CachedTrackEntity>>
    
    @Query("SELECT * FROM cached_tracks WHERE id = :trackId LIMIT 1")
    suspend fun getCachedTrack(trackId: String): CachedTrackEntity?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrack(track: CachedTrackEntity)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTracks(tracks: List<CachedTrackEntity>)
    
    @Delete
    suspend fun deleteTrack(track: CachedTrackEntity)
    
    @Query("DELETE FROM cached_tracks")
    suspend fun deleteAllTracks()
    
    @Query("DELETE FROM cached_tracks WHERE cached_at < :timestamp")
    suspend fun deleteOldTracks(timestamp: String)
}

/**
 * Cached Track Entity
 */
@Entity(tableName = "cached_tracks")
data class CachedTrackEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val artist: String,
    val album: String?,
    val duration: Int?,
    @ColumnInfo(name = "audio_url")
    val audioUrl: String,
    @ColumnInfo(name = "cover_url")
    val coverUrl: String?,
    val genre: String?,
    val plays: Int,
    @ColumnInfo(name = "cached_at")
    val cachedAt: String = System.currentTimeMillis().toString()
)
