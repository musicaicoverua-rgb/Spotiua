package com.openwave.app.domain.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Message domain model for user-admin chat
 */
@Serializable
data class Message(
    val id: String,
    @SerialName("user_id")
    val userId: String,
    val message: String,
    val reply: String? = null,
    @SerialName("is_read")
    val isRead: Boolean = false,
    @SerialName("replied_by")
    val repliedBy: String? = null,
    @SerialName("replied_at")
    val repliedAt: String? = null,
    @SerialName("created_at")
    val createdAt: String? = null,
    // Joined data
    val user: User? = null,
    val admin: User? = null
) {
    val hasReply: Boolean
        get() = !reply.isNullOrBlank()
    
    val isFromUser: Boolean
        get() = reply == null
}

/**
 * Analytics Event domain model
 */
@Serializable
data class AnalyticsEvent(
    val id: String,
    @SerialName("event_type")
    val eventType: EventType,
    @SerialName("user_id")
    val userId: String? = null,
    @SerialName("track_id")
    val trackId: String? = null,
    @SerialName("playlist_id")
    val playlistId: String? = null,
    val metadata: Map<String, String>? = null,
    val timestamp: String? = null
)

@Serializable
enum class EventType {
    @SerialName("track_play")
    TRACK_PLAY,
    @SerialName("track_complete")
    TRACK_COMPLETE,
    @SerialName("track_like")
    TRACK_LIKE,
    @SerialName("track_unlike")
    TRACK_UNLIKE,
    @SerialName("playlist_create")
    PLAYLIST_CREATE,
    @SerialName("playlist_add_track")
    PLAYLIST_ADD_TRACK,
    @SerialName("playlist_remove_track")
    PLAYLIST_REMOVE_TRACK,
    @SerialName("user_login")
    USER_LOGIN,
    @SerialName("user_signup")
    USER_SIGNUP,
    @SerialName("user_logout")
    USER_LOGOUT,
    @SerialName("search_query")
    SEARCH_QUERY,
    @SerialName("download_track")
    DOWNLOAD_TRACK,
    @SerialName("radio_play")
    RADIO_PLAY,
    @SerialName("daily_reward_claim")
    DAILY_REWARD_CLAIM,
    @SerialName("wheel_spin")
    WHEEL_SPIN,
    @SerialName("level_up")
    LEVEL_UP
}

/**
 * Daily Reward domain model
 */
@Serializable
data class DailyReward(
    val id: String,
    @SerialName("user_id")
    val userId: String,
    @SerialName("reward_date")
    val rewardDate: String,
    @SerialName("points_rewarded")
    val pointsRewarded: Int = 20,
    @SerialName("coins_rewarded")
    val coinsRewarded: Int = 10,
    @SerialName("claimed_at")
    val claimedAt: String? = null
)

/**
 * Wheel Spin domain model
 */
@Serializable
data class WheelSpin(
    val id: String,
    @SerialName("user_id")
    val userId: String,
    @SerialName("spin_date")
    val spinDate: String,
    @SerialName("reward_type")
    val rewardType: RewardType,
    @SerialName("reward_amount")
    val rewardAmount: Int,
    @SerialName("claimed_at")
    val claimedAt: String? = null
)

@Serializable
enum class RewardType {
    @SerialName("points")
    POINTS,
    @SerialName("coins")
    COINS,
    @SerialName("xp")
    XP
}

/**
 * AI Recommendation domain model
 */
@Serializable
data class AIRecommendation(
    val id: String,
    @SerialName("user_id")
    val userId: String,
    @SerialName("track_id")
    val trackId: String,
    val score: Float,
    val reason: String? = null,
    @SerialName("created_at")
    val createdAt: String? = null,
    // Joined data
    val track: Track? = null
)

/**
 * Radio Session domain model
 */
@Serializable
data class RadioSession(
    val id: String,
    @SerialName("user_id")
    val userId: String,
    @SerialName("seed_track_id")
    val seedTrackId: String? = null,
    val genre: String? = null,
    @SerialName("is_active")
    val isActive: Boolean = true,
    @SerialName("started_at")
    val startedAt: String? = null,
    @SerialName("ended_at")
    val endedAt: String? = null
)

/**
 * Leaderboard Entry domain model
 */
@Serializable
data class LeaderboardEntry(
    val rank: Long,
    @SerialName("user_id")
    val userId: String,
    val username: String?,
    @SerialName("avatar_url")
    val avatarUrl: String?,
    val points: Int? = null,
    @SerialName("total_listening_time")
    val totalListeningTime: Int? = null,
    val level: Int
)

/**
 * Dashboard Stats domain model (for admin)
 */
@Serializable
data class DashboardStats(
    val totalUsers: Int,
    val activeUsers: Int,
    val totalPlays: Int,
    val totalTracks: Int,
    val totalPlaylists: Int,
    val playsToday: Int,
    val newUsersToday: Int
)

/**
 * Daily Stats domain model
 */
@Serializable
data class DailyStats(
    val date: String,
    val plays: Int,
    val logins: Int,
    val likes: Int,
    @SerialName("playlist_creates")
    val playlistCreates: Int
)
