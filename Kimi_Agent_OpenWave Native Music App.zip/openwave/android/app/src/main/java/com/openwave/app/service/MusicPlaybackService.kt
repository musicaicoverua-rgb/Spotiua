package com.openwave.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.support.v4.media.MediaBrowserCompat
import android.support.v4.media.MediaDescriptionCompat
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.annotation.OptIn
import androidx.core.app.NotificationCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.MediaStyleNotificationHelper
import com.openwave.app.R
import com.openwave.app.domain.model.Track
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

/**
 * Music Playback Service
 * Handles background audio playback using ExoPlayer
 */
@AndroidEntryPoint
@OptIn(UnstableApi::class)
class MusicPlaybackService : MediaSessionService() {

    companion object {
        const val CHANNEL_ID = "openwave_playback_channel"
        const val NOTIFICATION_ID = 1
        const val ACTION_PLAY = "action_play"
        const val ACTION_PAUSE = "action_pause"
        const val ACTION_NEXT = "action_next"
        const val ACTION_PREVIOUS = "action_previous"
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    
    private var exoPlayer: ExoPlayer? = null
    private var mediaSession: MediaSession? = null
    private lateinit var notificationManager: NotificationManager
    
    // Playback state
    private val _playbackState = MutableStateFlow<PlaybackState>(PlaybackState.Idle)
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()
    
    private val _currentTrack = MutableStateFlow<Track?>(null)
    val currentTrack: StateFlow<Track?> = _currentTrack.asStateFlow()
    
    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition: StateFlow<Long> = _currentPosition.asStateFlow()
    
    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration.asStateFlow()
    
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()
    
    private val playlist = mutableListOf<Track>()
    private var currentIndex = 0

    override fun onCreate() {
        super.onCreate()
        Timber.d("MusicPlaybackService created")
        
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createNotificationChannel()
        initializePlayer()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.playback_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.playback_channel_description)
                setShowBadge(false)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun initializePlayer() {
        val trackSelector = DefaultTrackSelector(this).apply {
            setParameters(buildUponParameters().setAllowAudioMixedMimeTypeAdaptiveness(true))
        }
        
        exoPlayer = ExoPlayer.Builder(this)
            .setTrackSelector(trackSelector)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
            .apply {
                addListener(playerListener)
            }
        
        mediaSession = MediaSession.Builder(this, exoPlayer!!)
            .setCallback(mediaSessionCallback)
            .build()
    }

    private val playerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            when (playbackState) {
                Player.STATE_IDLE -> _playbackState.value = PlaybackState.Idle
                Player.STATE_BUFFERING -> _playbackState.value = PlaybackState.Buffering
                Player.STATE_READY -> _playbackState.value = PlaybackState.Ready
                Player.STATE_ENDED -> {
                    _playbackState.value = PlaybackState.Ended
                    playNext()
                }
            }
            updateNotification()
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _isPlaying.value = isPlaying
            updateNotification()
        }

        override fun onPositionDiscontinuity(
            oldPosition: Player.PositionInfo,
            newPosition: Player.PositionInfo,
            reason: Int
        ) {
            _currentPosition.value = exoPlayer?.currentPosition ?: 0
        }

        override fun onPlayerError(error: PlaybackException) {
            Timber.e(error, "Player error: ${error.message}")
            _playbackState.value = PlaybackState.Error(error.message ?: "Unknown error")
        }
    }

    private val mediaSessionCallback = object : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(
                    MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS
                        .buildUpon()
                        .add(androidx.media3.session.SessionCommand(ACTION_PLAY, Bundle.EMPTY))
                        .add(androidx.media3.session.SessionCommand(ACTION_PAUSE, Bundle.EMPTY))
                        .add(androidx.media3.session.SessionCommand(ACTION_NEXT, Bundle.EMPTY))
                        .add(androidx.media3.session.SessionCommand(ACTION_PREVIOUS, Bundle.EMPTY))
                        .build()
                )
                .build()
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = exoPlayer ?: return
        if (!player.playWhenReady || player.playbackState == Player.STATE_ENDED) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        exoPlayer = null
        Timber.d("MusicPlaybackService destroyed")
    }

    // ==================== PLAYBACK CONTROL ====================

    fun playTrack(track: Track, tracks: List<Track> = listOf(track)) {
        playlist.clear()
        playlist.addAll(tracks)
        currentIndex = tracks.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
        
        _currentTrack.value = track
        loadAndPlay(track)
    }

    fun playTracks(tracks: List<Track>, startIndex: Int = 0) {
        if (tracks.isEmpty()) return
        
        playlist.clear()
        playlist.addAll(tracks)
        currentIndex = startIndex.coerceIn(0, tracks.size - 1)
        
        _currentTrack.value = tracks[currentIndex]
        loadAndPlay(tracks[currentIndex])
    }

    private fun loadAndPlay(track: Track) {
        val player = exoPlayer ?: return
        
        val mediaItem = MediaItem.Builder()
            .setUri(track.bestAudioUrl)
            .setMediaId(track.id)
            .setMediaMetadata(
                androidx.media3.common.MediaMetadata.Builder()
                    .setTitle(track.title)
                    .setArtist(track.artist)
                    .setArtworkUri(track.coverUrl?.let { android.net.Uri.parse(it) })
                    .build()
            )
            .build()
        
        player.setMediaItem(mediaItem)
        player.prepare()
        player.playWhenReady = true
        
        startForeground(NOTIFICATION_ID, createNotification())
    }

    fun togglePlayPause() {
        exoPlayer?.let {
            it.playWhenReady = !it.playWhenReady
        }
    }

    fun play() {
        exoPlayer?.playWhenReady = true
    }

    fun pause() {
        exoPlayer?.playWhenReady = false
    }

    fun playNext() {
        if (playlist.isEmpty()) return
        
        currentIndex = (currentIndex + 1) % playlist.size
        _currentTrack.value = playlist[currentIndex]
        loadAndPlay(playlist[currentIndex])
    }

    fun playPrevious() {
        if (playlist.isEmpty()) return
        
        currentIndex = if (currentIndex > 0) currentIndex - 1 else playlist.size - 1
        _currentTrack.value = playlist[currentIndex]
        loadAndPlay(playlist[currentIndex])
    }

    fun seekTo(positionMs: Long) {
        exoPlayer?.seekTo(positionMs)
        _currentPosition.value = positionMs
    }

    fun skipForward(milliseconds: Long = 10000) {
        exoPlayer?.let {
            val newPosition = (it.currentPosition + milliseconds).coerceAtMost(it.duration)
            it.seekTo(newPosition)
        }
    }

    fun skipBackward(milliseconds: Long = 10000) {
        exoPlayer?.let {
            val newPosition = (it.currentPosition - milliseconds).coerceAtLeast(0)
            it.seekTo(newPosition)
        }
    }

    fun setShuffleEnabled(enabled: Boolean) {
        exoPlayer?.shuffleModeEnabled = enabled
    }

    fun setRepeatMode(repeatMode: Int) {
        exoPlayer?.repeatMode = repeatMode
    }

    fun addToQueue(track: Track) {
        playlist.add(track)
    }

    fun clearQueue() {
        playlist.clear()
        currentIndex = 0
    }

    fun getQueue(): List<Track> = playlist.toList()

    fun getCurrentIndex(): Int = currentIndex

    // ==================== NOTIFICATION ====================

    private fun createNotification(): Notification {
        val track = _currentTrack.value
        val isPlaying = _isPlaying.value
        
        val playPauseIntent = PendingIntent.getBroadcast(
            this,
            0,
            Intent(if (isPlaying) ACTION_PAUSE else ACTION_PLAY),
            PendingIntent.FLAG_IMMUTABLE
        )
        
        val nextIntent = PendingIntent.getBroadcast(
            this,
            1,
            Intent(ACTION_NEXT),
            PendingIntent.FLAG_IMMUTABLE
        )
        
        val previousIntent = PendingIntent.getBroadcast(
            this,
            2,
            Intent(ACTION_PREVIOUS),
            PendingIntent.FLAG_IMMUTABLE
        )
        
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(track?.title ?: getString(R.string.app_name))
            .setContentText(track?.artist ?: "")
            .setSmallIcon(R.drawable.ic_notification)
            .setLargeIcon(null) // TODO: Load cover image
            .setOngoing(isPlaying)
            .setOnlyAlertOnce(true)
            .addAction(R.drawable.ic_previous, getString(R.string.previous), previousIntent)
            .addAction(
                if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play,
                getString(if (isPlaying) R.string.pause else R.string.play),
                playPauseIntent
            )
            .addAction(R.drawable.ic_next, getString(R.string.next), nextIntent)
            .setStyle(
                MediaStyleNotificationHelper.MediaStyle(mediaSession!!)
                    .setShowActionsInCompactView(1)
            )
            .build()
    }

    private fun updateNotification() {
        if (_isPlaying.value) {
            notificationManager.notify(NOTIFICATION_ID, createNotification())
        }
    }

    // ==================== POSITION UPDATES ====================

    init {
        serviceScope.launch {
            while (true) {
                exoPlayer?.let {
                    _currentPosition.value = it.currentPosition
                    _duration.value = it.duration.coerceAtLeast(0)
                }
                kotlinx.coroutines.delay(1000)
            }
        }
    }
}

/**
 * Playback state sealed class
 */
sealed class PlaybackState {
    object Idle : PlaybackState()
    object Buffering : PlaybackState()
    object Ready : PlaybackState()
    object Ended : PlaybackState()
    data class Error(val message: String) : PlaybackState()
}
