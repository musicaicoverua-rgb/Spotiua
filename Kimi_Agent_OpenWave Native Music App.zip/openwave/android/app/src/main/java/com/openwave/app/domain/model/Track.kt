package com.openwave.app.domain.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Track domain model
 * Represents a music track in the OpenWave system
 */
@Serializable
data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String? = null,
    val duration: Int? = null,
    @SerialName("audio_url")
    val audioUrl: String,
    @SerialName("audio_url_aac")
    val audioUrlAac: String? = null,
    @SerialName("cover_url")
    val coverUrl: String? = null,
    val genre: String? = null,
    val plays: Int = 0,
    @SerialName("uploaded_by")
    val uploadedBy: String? = null,
    @SerialName("is_processed")
    val isProcessed: Boolean = false,
    @SerialName("original_format")
    val originalFormat: String? = null,
    val bitrate: Int? = null,
    @SerialName("created_at")
    val createdAt: String? = null,
    @SerialName("updated_at")
    val updatedAt: String? = null,
    // Local fields (not from API)
    val isDownloaded: Boolean = false,
    val localPath: String? = null,
    val isLiked: Boolean = false
) {
    val displayDuration: String
        get() = duration?.let { formatDuration(it) } ?: "--:--"
    
    val bestAudioUrl: String
        get() = audioUrlAac ?: audioUrl
    
    companion object {
        fun formatDuration(seconds: Int): String {
            val minutes = seconds / 60
            val remainingSeconds = seconds % 60
            return "%d:%02d".format(minutes, remainingSeconds)
        }
    }
}

/**
 * Playlist domain model
 */
@Serializable
data class Playlist(
    val id: String,
    val name: String,
    val description: String? = null,
    @SerialName("user_id")
    val userId: String,
    @SerialName("cover_url")
    val coverUrl: String? = null,
    @SerialName("is_public")
    val isPublic: Boolean = true,
    @SerialName("created_at")
    val createdAt: String? = null,
    @SerialName("updated_at")
    val updatedAt: String? = null,
    // Local fields
    val tracks: List<Track> = emptyList(),
    val trackCount: Int = 0
)

/**
 * Playlist Track junction model
 */
@Serializable
data class PlaylistTrack(
    val id: String,
    @SerialName("playlist_id")
    val playlistId: String,
    @SerialName("track_id")
    val trackId: String,
    val position: Int = 0,
    @SerialName("added_at")
    val addedAt: String? = null
)

/**
 * Like domain model
 */
@Serializable
data class Like(
    val id: String,
    @SerialName("user_id")
    val userId: String,
    @SerialName("track_id")
    val trackId: String,
    @SerialName("created_at")
    val createdAt: String? = null
)

/**
 * Listening History domain model
 */
@Serializable
data class ListeningHistory(
    val id: String,
    @SerialName("user_id")
    val userId: String,
    @SerialName("track_id")
    val trackId: String,
    @SerialName("played_at")
    val playedAt: String,
    val duration: Int = 0,
    val completed: Boolean = false,
    // Joined data
    val track: Track? = null
)

/**
 * Offline Download domain model
 */
@Serializable
data class OfflineDownload(
    val id: String,
    @SerialName("user_id")
    val userId: String,
    @SerialName("track_id")
    val trackId: String,
    @SerialName("local_path")
    val localPath: String? = null,
    @SerialName("downloaded_at")
    val downloadedAt: String? = null,
    @SerialName("expires_at")
    val expiresAt: String? = null,
    // Joined data
    val track: Track? = null
)
