package com.openwave.app.domain.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * User domain model
 * Represents a user in the OpenWave system
 */
@Serializable
data class User(
    val id: String,
    val email: String,
    val username: String? = null,
    val role: UserRole = UserRole.USER,
    val avatarUrl: String? = null,
    val points: Int = 0,
    val coins: Int = 0,
    val level: Int = 1,
    @SerialName("total_listening_time")
    val totalListeningTime: Int = 0,
    @SerialName("last_daily_reward")
    val lastDailyReward: String? = null,
    @SerialName("created_at")
    val createdAt: String? = null
) {
    val displayName: String
        get() = username ?: email.substringBefore("@")
    
    val isAdmin: Boolean
        get() = role == UserRole.ADMIN
    
    val nextLevelPoints: Int
        get() = LevelRequirements.getPointsForLevel(level + 1)
    
    val progressToNextLevel: Float
        get() {
            val currentLevelPoints = LevelRequirements.getPointsForLevel(level)
            val nextLevelPoints = LevelRequirements.getPointsForLevel(level + 1)
            val pointsInCurrentLevel = points - currentLevelPoints
            val pointsNeeded = nextLevelPoints - currentLevelPoints
            return if (pointsNeeded > 0) {
                (pointsInCurrentLevel.toFloat() / pointsNeeded).coerceIn(0f, 1f)
            } else 1f
        }
}

@Serializable
enum class UserRole {
    @SerialName("user")
    USER,
    @SerialName("admin")
    ADMIN
}

/**
 * Level requirements for gamification
 */
object LevelRequirements {
    private val requirements = mapOf(
        1 to 0,
        2 to 100,
        3 to 300,
        4 to 600,
        5 to 1000,
        6 to 1500,
        7 to 2100,
        8 to 2800,
        9 to 3600,
        10 to 4500
    )
    
    fun getPointsForLevel(level: Int): Int {
        return requirements[level] ?: requirements[10]!!
    }
    
    fun getLevelForPoints(points: Int): Int {
        return requirements.entries
            .filter { it.value <= points }
            .maxByOrNull { it.key }
            ?.key ?: 1
    }
    
    fun getLevelTitle(level: Int, language: String = "uk"): String {
        val titles = mapOf(
            "uk" to listOf("Новачок", "Слухач", "Меломан", "Експерт", "Майстер", "Профі", "Зірка", "Легенда", "Ікона", "Бог музики"),
            "en" to listOf("Beginner", "Listener", "Music Lover", "Expert", "Master", "Pro", "Star", "Legend", "Icon", "Music God"),
            "ru" to listOf("Новичок", "Слушатель", "Меломан", "Эксперт", "Мастер", "Про", "Звезда", "Легенда", "Икона", "Бог музыки"),
            "es" to listOf("Principiante", "Oyente", "Melómano", "Experto", "Maestro", "Pro", "Estrella", "Leyenda", "Icono", "Dios de la Música"),
            "fr" to listOf("Débutant", "Auditeur", "Mélomane", "Expert", "Maître", "Pro", "Star", "Légende", "Icône", "Dieu de la Musique"),
            "de" to listOf("Anfänger", "Hörer", "Musikliebhaber", "Experte", "Meister", "Profi", "Star", "Legende", "Ikone", "Musikgott"),
            "pl" to listOf("Początkujący", "Słuchacz", "Meloman", "Ekspert", "Mistrz", "Pro", "Gwiazda", "Legenda", "Ikona", "Bóg Muzyki"),
            "cs" to listOf("Začátečník", "Posluchač", "Meloman", "Expert", "Mistr", "Pro", "Hvězda", "Legenda", "Ikona", "Bůh Hudby")
        )
        return titles[language]?.getOrNull(level - 1) ?: titles["uk"]!![level - 1]
    }
}
