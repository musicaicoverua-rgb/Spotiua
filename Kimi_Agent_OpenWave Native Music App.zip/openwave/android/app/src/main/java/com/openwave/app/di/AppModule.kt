package com.openwave.app.di

import android.content.Context
import androidx.room.Room
import com.openwave.app.data.local.AppDatabase
import com.openwave.app.data.remote.SupabaseClientProvider
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Application Module
 * Provides app-wide dependencies
 */
@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    
    @Provides
    @Singleton
    fun provideSupabaseClient(): SupabaseClientProvider {
        return SupabaseClientProvider()
    }
    
    @Provides
    @Singleton
    fun provideAppDatabase(@ApplicationContext context: Context): AppDatabase {
        return Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            "openwave_database"
        )
            .fallbackToDestructiveMigration()
            .build()
    }
    
    @Provides
    fun provideOfflineDownloadDao(database: AppDatabase) = database.offlineDownloadDao()
    
    @Provides
    fun provideCachedTrackDao(database: AppDatabase) = database.cachedTrackDao()
    
    @Provides
    fun provideListeningHistoryDao(database: AppDatabase) = database.listeningHistoryDao()
}
