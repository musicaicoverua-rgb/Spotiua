package com.openwave.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

/**
 * Room Database for OpenWave
 * Stores offline downloads and cached data
 */
@Database(
    entities = [
        OfflineDownloadEntity::class,
        CachedTrackEntity::class,
        ListeningHistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    
    abstract fun offlineDownloadDao(): OfflineDownloadDao
    abstract fun cachedTrackDao(): CachedTrackDao
    abstract fun listeningHistoryDao(): ListeningHistoryDao
    
    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null
        
        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context).also { INSTANCE = it }
            }
        }
        
        private fun buildDatabase(context: Context): AppDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "openwave_database"
            )
                .fallbackToDestructiveMigration()
                .build()
        }
    }
}
