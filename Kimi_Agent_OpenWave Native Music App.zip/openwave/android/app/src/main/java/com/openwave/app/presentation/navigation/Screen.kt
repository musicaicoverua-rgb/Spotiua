package com.openwave.app.presentation.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Screen destinations for navigation
 */
sealed class Screen(
    val route: String,
    val title: String,
    val icon: ImageVector? = null
) {
    // Auth Screens
    object Login : Screen("login", "login")
    object Register : Screen("register", "register")
    object AdminLogin : Screen("admin_login", "admin_login")
    
    // Main Screens
    object Home : Screen("home", "home", Icons.Default.Home)
    object Search : Screen("search", "search", Icons.Default.Search)
    object Library : Screen("library", "library", Icons.Default.LibraryMusic)
    object Leaderboard : Screen("leaderboard", "leaderboard", Icons.Default.EmojiEvents)
    object Radio : Screen("radio", "radio", Icons.Default.Radio)
    object Spin : Screen("spin", "spin", Icons.Default.Casino)
    object Support : Screen("support", "support", Icons.Default.SupportAgent)
    
    // Player Screens
    object FullPlayer : Screen("full_player", "full_player")
    object PlaylistDetail : Screen("playlist/{playlistId}", "playlist_detail")
    object AlbumDetail : Screen("album/{albumId}", "album_detail")
    object ArtistDetail : Screen("artist/{artistId}", "artist_detail")
    
    // Admin Screens
    object AdminDashboard : Screen("admin_dashboard", "admin_dashboard")
    object AdminUpload : Screen("admin_upload", "admin_upload")
    object AdminTracks : Screen("admin_tracks", "admin_tracks")
    object AdminAnalytics : Screen("admin_analytics", "admin_analytics")
    object AdminMessages : Screen("admin_messages", "admin_messages")
    
    // Profile
    object Profile : Screen("profile", "profile")
    object Settings : Screen("settings", "settings")
    
    companion object {
        fun bottomNavScreens(isAdmin: Boolean = false): List<Screen> {
            return if (isAdmin) {
                listOf(Home, Search, Library, AdminDashboard)
            } else {
                listOf(Home, Search, Library, Leaderboard, Radio, Spin, Support)
            }
        }
        
        fun fromRoute(route: String?): Screen {
            return when (route) {
                Login.route -> Login
                Register.route -> Register
                AdminLogin.route -> AdminLogin
                Home.route -> Home
                Search.route -> Search
                Library.route -> Library
                Leaderboard.route -> Leaderboard
                Radio.route -> Radio
                Spin.route -> Spin
                Support.route -> Support
                FullPlayer.route -> FullPlayer
                AdminDashboard.route -> AdminDashboard
                AdminUpload.route -> AdminUpload
                AdminTracks.route -> AdminTracks
                AdminAnalytics.route -> AdminAnalytics
                AdminMessages.route -> AdminMessages
                Profile.route -> Profile
                Settings.route -> Settings
                else -> Home
            }
        }
    }
}

fun Screen.PlaylistDetail.createRoute(playlistId: String) = "playlist/$playlistId"
fun Screen.AlbumDetail.createRoute(albumId: String) = "album/$albumId"
fun Screen.ArtistDetail.createRoute(artistId: String) = "artist/$artistId"
