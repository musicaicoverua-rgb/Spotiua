-- OpenWave Supabase Storage Configuration
-- Run this after creating the buckets in Supabase Dashboard

-- ============================================
-- STORAGE BUCKETS
-- ============================================

-- Create buckets (do this via Supabase Dashboard > Storage)
-- 1. music-files - For audio files (MP3, AAC)
-- 2. covers - For album/track cover images
-- 3. avatars - For user profile pictures

-- ============================================
-- STORAGE POLICIES
-- ============================================

-- Music Files Bucket Policies
BEGIN;

-- Allow anyone to read music files (for streaming)
CREATE POLICY "Allow public read access to music files" 
ON storage.objects FOR SELECT 
USING (bucket_id = 'music-files');

-- Allow only admins to upload music files
CREATE POLICY "Allow admin upload to music files" 
ON storage.objects FOR INSERT 
WITH CHECK (
  bucket_id = 'music-files' 
  AND EXISTS (
    SELECT 1 FROM public.users 
    WHERE id = auth.uid() AND role = 'admin'
  )
);

-- Allow only admins to update music files
CREATE POLICY "Allow admin update to music files" 
ON storage.objects FOR UPDATE 
USING (
  bucket_id = 'music-files' 
  AND EXISTS (
    SELECT 1 FROM public.users 
    WHERE id = auth.uid() AND role = 'admin'
  )
);

-- Allow only admins to delete music files
CREATE POLICY "Allow admin delete from music files" 
ON storage.objects FOR DELETE 
USING (
  bucket_id = 'music-files' 
  AND EXISTS (
    SELECT 1 FROM public.users 
    WHERE id = auth.uid() AND role = 'admin'
  )
);

COMMIT;

-- Covers Bucket Policies
BEGIN;

-- Allow anyone to read covers
CREATE POLICY "Allow public read access to covers" 
ON storage.objects FOR SELECT 
USING (bucket_id = 'covers');

-- Allow only admins to upload covers
CREATE POLICY "Allow admin upload to covers" 
ON storage.objects FOR INSERT 
WITH CHECK (
  bucket_id = 'covers' 
  AND EXISTS (
    SELECT 1 FROM public.users 
    WHERE id = auth.uid() AND role = 'admin'
  )
);

-- Allow only admins to update covers
CREATE POLICY "Allow admin update to covers" 
ON storage.objects FOR UPDATE 
USING (
  bucket_id = 'covers' 
  AND EXISTS (
    SELECT 1 FROM public.users 
    WHERE id = auth.uid() AND role = 'admin'
  )
);

-- Allow only admins to delete covers
CREATE POLICY "Allow admin delete from covers" 
ON storage.objects FOR DELETE 
USING (
  bucket_id = 'covers' 
  AND EXISTS (
    SELECT 1 FROM public.users 
    WHERE id = auth.uid() AND role = 'admin'
  )
);

COMMIT;

-- Avatars Bucket Policies
BEGIN;

-- Allow anyone to read avatars
CREATE POLICY "Allow public read access to avatars" 
ON storage.objects FOR SELECT 
USING (bucket_id = 'avatars');

-- Allow users to upload their own avatar
CREATE POLICY "Allow users to upload own avatar" 
ON storage.objects FOR INSERT 
WITH CHECK (
  bucket_id = 'avatars' 
  AND (storage.foldername(name))[1] = auth.uid()::text
);

-- Allow users to update their own avatar
CREATE POLICY "Allow users to update own avatar" 
ON storage.objects FOR UPDATE 
USING (
  bucket_id = 'avatars' 
  AND (storage.foldername(name))[1] = auth.uid()::text
);

-- Allow users to delete their own avatar
CREATE POLICY "Allow users to delete own avatar" 
ON storage.objects FOR DELETE 
USING (
  bucket_id = 'avatars' 
  AND (storage.foldername(name))[1] = auth.uid()::text
);

COMMIT;

-- ============================================
-- CDN CONFIGURATION
-- ============================================

-- Enable CDN for all buckets via Supabase Dashboard
-- Go to Storage > Buckets > Settings > Enable CDN

-- ============================================
-- FILE SIZE LIMITS
-- ============================================

-- Set max file sizes via Supabase Dashboard:
-- music-files: 50MB (for audio files)
-- covers: 5MB (for images)
-- avatars: 2MB (for profile pictures)

-- ============================================
-- ALLOWED MIME TYPES
-- ============================================

-- music-files bucket:
-- - audio/mpeg (MP3)
-- - audio/aac (AAC)
-- - audio/wav (WAV)
-- - audio/flac (FLAC)
-- - audio/ogg (OGG)
-- - audio/mp4 (M4A)

-- covers bucket:
-- - image/jpeg
-- - image/png
-- - image/webp

-- avatars bucket:
-- - image/jpeg
-- - image/png
-- - image/webp
