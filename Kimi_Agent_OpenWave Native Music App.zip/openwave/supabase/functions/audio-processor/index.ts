// OpenWave Audio Processor Edge Function
// Handles audio file validation, conversion, and optimization

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

interface AudioProcessRequest {
  trackId: string;
  filePath: string;
  fileName: string;
}

interface AudioMetadata {
  duration: number;
  bitrate: number;
  format: string;
  sampleRate: number;
  channels: number;
}

serve(async (req) => {
  try {
    // CORS headers
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    }

    if (req.method === 'OPTIONS') {
      return new Response('ok', { headers: corsHeaders })
    }

    // Initialize Supabase client
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Parse request
    const { trackId, filePath, fileName }: AudioProcessRequest = await req.json()

    if (!trackId || !filePath) {
      return new Response(
        JSON.stringify({ error: 'Missing required parameters' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    console.log(`Processing audio for track: ${trackId}`)

    // Download original file from storage
    const { data: fileData, error: downloadError } = await supabaseClient
      .storage
      .from('music-files')
      .download(filePath)

    if (downloadError || !fileData) {
      throw new Error(`Failed to download file: ${downloadError?.message}`)
    }

    // Get file info
    const fileSize = fileData.size
    const fileExtension = fileName.split('.').pop()?.toLowerCase()

    console.log(`File size: ${fileSize} bytes, Format: ${fileExtension}`)

    // Validate audio file
    const validationResult = await validateAudioFile(fileData, fileExtension)
    
    if (!validationResult.valid) {
      // Delete invalid file
      await supabaseClient.storage.from('music-files').remove([filePath])
      
      // Update track status
      await supabaseClient
        .from('tracks')
        .update({ 
          is_processed: false,
          title: `[INVALID] ${validationResult.error}` 
        })
        .eq('id', trackId)

      return new Response(
        JSON.stringify({ error: validationResult.error }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Extract metadata
    const metadata = validationResult.metadata as AudioMetadata

    // Update track with metadata
    await supabaseClient
      .from('tracks')
      .update({
        duration: metadata.duration,
        bitrate: metadata.bitrate,
        original_format: metadata.format,
        is_processed: true
      })
      .eq('id', trackId)

    // Generate optimized versions (MP3 320kbps and AAC)
    // Note: In production, you would use FFmpeg via a processing service
    // This is a simplified version

    const mp3Path = `processed/${trackId}_320kbps.mp3`
    const aacPath = `processed/${trackId}_streaming.aac`

    // Upload processed files (simulated - in production use actual conversion)
    // For now, we'll use the original file as both MP3 and AAC
    await supabaseClient
      .storage
      .from('music-files')
      .upload(mp3Path, fileData, {
        contentType: 'audio/mpeg',
        upsert: true
      })

    await supabaseClient
      .storage
      .from('music-files')
      .upload(aacPath, fileData, {
        contentType: 'audio/aac',
        upsert: true
      })

    // Get public URLs
    const { data: mp3Url } = supabaseClient
      .storage
      .from('music-files')
      .getPublicUrl(mp3Path)

    const { data: aacUrl } = supabaseClient
      .storage
      .from('music-files')
      .getPublicUrl(aacPath)

    // Update track with processed URLs
    await supabaseClient
      .from('tracks')
      .update({
        audio_url: mp3Url.publicUrl,
        audio_url_aac: aacUrl.publicUrl,
        is_processed: true
      })
      .eq('id', trackId)

    // Log analytics event
    await supabaseClient
      .from('analytics')
      .insert({
        event_type: 'track_processed',
        track_id: trackId,
        metadata: {
          original_format: metadata.format,
          duration: metadata.duration,
          bitrate: metadata.bitrate
        }
      })

    return new Response(
      JSON.stringify({
        success: true,
        trackId,
        metadata,
        urls: {
          mp3: mp3Url.publicUrl,
          aac: aacUrl.publicUrl
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Audio processing error:', error)
    
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    )
  }
})

// Validate audio file
async function validateAudioFile(
  fileData: Blob, 
  format?: string
): Promise<{ valid: boolean; error?: string; metadata?: AudioMetadata }> {
  
  // Check file size (max 50MB)
  const MAX_FILE_SIZE = 50 * 1024 * 1024
  if (fileData.size > MAX_FILE_SIZE) {
    return { valid: false, error: 'File too large (max 50MB)' }
  }

  // Check file size (min 10KB)
  const MIN_FILE_SIZE = 10 * 1024
  if (fileData.size < MIN_FILE_SIZE) {
    return { valid: false, error: 'File too small (min 10KB)' }
  }

  // Supported formats
  const supportedFormats = ['mp3', 'wav', 'flac', 'aac', 'ogg', 'm4a', 'wma']
  if (format && !supportedFormats.includes(format)) {
    return { valid: false, error: `Unsupported format: ${format}` }
  }

  // Read file header for validation
  const header = await fileData.slice(0, 16).arrayBuffer()
  const headerBytes = new Uint8Array(header)

  // Check MP3 signature
  const isMp3 = (
    (headerBytes[0] === 0xFF && (headerBytes[1] & 0xE0) === 0xE0) || // MPEG sync
    (headerBytes[0] === 0x49 && headerBytes[1] === 0x44 && headerBytes[2] === 0x33) // ID3 tag
  )

  // Check WAV signature
  const isWav = (
    headerBytes[0] === 0x52 && headerBytes[1] === 0x49 && 
    headerBytes[2] === 0x46 && headerBytes[3] === 0x46
  )

  // Check FLAC signature
  const isFlac = (
    headerBytes[0] === 0x66 && headerBytes[1] === 0x4C && 
    headerBytes[2] === 0x61 && headerBytes[3] === 0x43
  )

  // Check AAC/MP4 signature
  const isAac = (
    headerBytes[4] === 0x66 && headerBytes[5] === 0x74 && 
    headerBytes[6] === 0x79 && headerBytes[7] === 0x70
  )

  if (!isMp3 && !isWav && !isFlac && !isAac) {
    return { valid: false, error: 'Invalid audio file format' }
  }

  // Estimate duration based on file size (rough approximation for MP3 at 320kbps)
  const estimatedDuration = Math.floor((fileData.size * 8) / (320 * 1000))

  // Detected format
  let detectedFormat = format || 'unknown'
  if (isMp3) detectedFormat = 'mp3'
  else if (isWav) detectedFormat = 'wav'
  else if (isFlac) detectedFormat = 'flac'
  else if (isAac) detectedFormat = 'aac'

  // Estimated bitrate
  const estimatedBitrate = isMp3 ? 320 : Math.floor((fileData.size * 8) / estimatedDuration / 1000)

  return {
    valid: true,
    metadata: {
      duration: estimatedDuration,
      bitrate: estimatedBitrate,
      format: detectedFormat,
      sampleRate: 44100, // Default assumption
      channels: 2 // Default assumption
    }
  }
}
