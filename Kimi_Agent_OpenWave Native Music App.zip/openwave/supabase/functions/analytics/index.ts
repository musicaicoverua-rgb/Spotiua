// OpenWave Analytics Edge Function
// Handles analytics aggregation and admin dashboard data

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

serve(async (req) => {
  try {
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    }

    if (req.method === 'OPTIONS') {
      return new Response('ok', { headers: corsHeaders })
    }

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const url = new URL(req.url)
    const action = url.searchParams.get('action')

    switch (action) {
      case 'dashboard':
        return await getDashboardStats(supabaseClient, corsHeaders)
      
      case 'top-tracks':
        const limit = parseInt(url.searchParams.get('limit') || '10')
        return await getTopTracks(supabaseClient, corsHeaders, limit)
      
      case 'daily-stats':
        const days = parseInt(url.searchParams.get('days') || '30')
        return await getDailyStats(supabaseClient, corsHeaders, days)
      
      case 'user-activity':
        return await getUserActivity(supabaseClient, corsHeaders)
      
      default:
        return new Response(
          JSON.stringify({ error: 'Invalid action' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
    }

  } catch (error) {
    console.error('Analytics error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    )
  }
})

// Get dashboard statistics
async function getDashboardStats(supabase: any, corsHeaders: any) {
  // Total users
  const { count: totalUsers, error: usersError } = await supabase
    .from('users')
    .select('*', { count: 'exact', head: true })

  // Active users (logged in within last 7 days)
  const { count: activeUsers, error: activeError } = await supabase
    .from('users')
    .select('*', { count: 'exact', head: true })
    .gte('updated_at', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString())

  // Total plays
  const { data: playsData, error: playsError } = await supabase
    .from('analytics')
    .select('event_type')
    .eq('event_type', 'track_play')

  const totalPlays = playsData?.length || 0

  // Total tracks
  const { count: totalTracks, error: tracksError } = await supabase
    .from('tracks')
    .select('*', { count: 'exact', head: true })

  // Total playlists
  const { count: totalPlaylists, error: playlistsError } = await supabase
    .from('playlists')
    .select('*', { count: 'exact', head: true })

  // Today's plays
  const today = new Date().toISOString().split('T')[0]
  const { data: todayPlays, error: todayError } = await supabase
    .from('analytics')
    .select('event_type')
    .eq('event_type', 'track_play')
    .gte('timestamp', today)

  // New users today
  const { count: newUsersToday, error: newUsersError } = await supabase
    .from('users')
    .select('*', { count: 'exact', head: true })
    .gte('created_at', today)

  return new Response(
    JSON.stringify({
      totalUsers: totalUsers || 0,
      activeUsers: activeUsers || 0,
      totalPlays,
      totalTracks: totalTracks || 0,
      totalPlaylists: totalPlaylists || 0,
      playsToday: todayPlays?.length || 0,
      newUsersToday: newUsersToday || 0
    }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  )
}

// Get top tracks
async function getTopTracks(supabase: any, corsHeaders: any, limit: number) {
  const { data: tracks, error } = await supabase
    .from('tracks')
    .select('id, title, artist, cover_url, plays, created_at')
    .order('plays', { ascending: false })
    .limit(limit)

  if (error) {
    throw new Error(error.message)
  }

  return new Response(
    JSON.stringify({ tracks: tracks || [] }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  )
}

// Get daily statistics
async function getDailyStats(supabase: any, corsHeaders: any, days: number) {
  const startDate = new Date()
  startDate.setDate(startDate.getDate() - days)

  const { data: analytics, error } = await supabase
    .from('analytics')
    .select('event_type, timestamp')
    .gte('timestamp', startDate.toISOString())
    .order('timestamp', { ascending: true })

  if (error) {
    throw new Error(error.message)
  }

  // Group by date
  const dailyStats: Record<string, any> = {}

  analytics?.forEach((event: any) => {
    const date = event.timestamp.split('T')[0]
    
    if (!dailyStats[date]) {
      dailyStats[date] = {
        date,
        plays: 0,
        logins: 0,
        likes: 0,
        playlistCreates: 0
      }
    }

    switch (event.event_type) {
      case 'track_play':
        dailyStats[date].plays++
        break
      case 'user_login':
        dailyStats[date].logins++
        break
      case 'track_like':
        dailyStats[date].likes++
        break
      case 'playlist_create':
        dailyStats[date].playlistCreates++
        break
    }
  })

  return new Response(
    JSON.stringify({ 
      dailyStats: Object.values(dailyStats),
      totalDays: days 
    }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  )
}

// Get user activity statistics
async function getUserActivity(supabase: any, corsHeaders: any) {
  // Most active users by listening time
  const { data: topListeners, error: listenersError } = await supabase
    .from('users')
    .select('id, username, avatar_url, total_listening_time, points, level')
    .order('total_listening_time', { ascending: false })
    .limit(10)

  // Recent activity
  const { data: recentActivity, error: activityError } = await supabase
    .from('analytics')
    .select('event_type, user_id, track_id, timestamp')
    .order('timestamp', { ascending: false })
    .limit(50)

  return new Response(
    JSON.stringify({
      topListeners: topListeners || [],
      recentActivity: recentActivity || []
    }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  )
}
