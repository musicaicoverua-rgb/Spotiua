// OpenWave Chat Notifications Edge Function
// Handles real-time chat notifications and message replies

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

serve(async (req) => {
  try {
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    }

    if (req.method === 'OPTIONS') {
      return new Response('ok', { headers: corsHeaders })
    }

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const url = new URL(req.url)
    const action = url.searchParams.get('action')

    switch (action) {
      case 'send-message':
        return await sendMessage(supabaseClient, req, corsHeaders)
      
      case 'reply-message':
        return await replyMessage(supabaseClient, req, corsHeaders)
      
      case 'get-unread':
        return await getUnreadCount(supabaseClient, req, corsHeaders)
      
      case 'mark-read':
        return await markAsRead(supabaseClient, req, corsHeaders)
      
      default:
        return new Response(
          JSON.stringify({ error: 'Invalid action' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
    }

  } catch (error) {
    console.error('Chat notification error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    )
  }
})

// Send a new message
async function sendMessage(supabase: any, req: Request, corsHeaders: any) {
  const { userId, message } = await req.json()

  if (!userId || !message) {
    return new Response(
      JSON.stringify({ error: 'Missing required parameters' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }

  // Insert message
  const { data, error } = await supabase
    .from('messages')
    .insert({
      user_id: userId,
      message: message,
      is_read: false
    })
    .select()
    .single()

  if (error) {
    throw new Error(error.message)
  }

  // Notify admins (in production, use push notifications)
  // For now, we rely on Supabase Realtime

  // Log analytics
  await supabase
    .from('analytics')
    .insert({
      event_type: 'message_sent',
      user_id: userId
    })

  return new Response(
    JSON.stringify({ success: true, message: data }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  )
}

// Reply to a message (admin only)
async function replyMessage(supabase: any, req: Request, corsHeaders: any) {
  const { messageId, reply, adminId } = await req.json()

  if (!messageId || !reply || !adminId) {
    return new Response(
      JSON.stringify({ error: 'Missing required parameters' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }

  // Verify admin
  const { data: admin, error: adminError } = await supabase
    .from('users')
    .select('role')
    .eq('id', adminId)
    .single()

  if (adminError || admin?.role !== 'admin') {
    return new Response(
      JSON.stringify({ error: 'Unauthorized' }),
      { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }

  // Update message with reply
  const { data, error } = await supabase
    .from('messages')
    .update({
      reply: reply,
      replied_by: adminId,
      replied_at: new Date().toISOString(),
      is_read: true
    })
    .eq('id', messageId)
    .select()
    .single()

  if (error) {
    throw new Error(error.message)
  }

  return new Response(
    JSON.stringify({ success: true, message: data }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  )
}

// Get unread message count
async function getUnreadCount(supabase: any, req: Request, corsHeaders: any) {
  const url = new URL(req.url)
  const userId = url.searchParams.get('userId')
  const isAdmin = url.searchParams.get('isAdmin') === 'true'

  if (!userId) {
    return new Response(
      JSON.stringify({ error: 'Missing userId' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }

  let query = supabase
    .from('messages')
    .select('*', { count: 'exact', head: true })
    .eq('is_read', false)

  if (isAdmin) {
    // Admin sees all unread messages from users
    query = query.not('message', 'is', null)
  } else {
    // User sees unread replies
    query = query.eq('user_id', userId).not('reply', 'is', null)
  }

  const { count, error } = await query

  if (error) {
    throw new Error(error.message)
  }

  return new Response(
    JSON.stringify({ unreadCount: count || 0 }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  )
}

// Mark messages as read
async function markAsRead(supabase: any, req: Request, corsHeaders: any) {
  const { messageIds, userId } = await req.json()

  if (!messageIds || !Array.isArray(messageIds) || !userId) {
    return new Response(
      JSON.stringify({ error: 'Missing required parameters' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }

  const { data, error } = await supabase
    .from('messages')
    .update({ is_read: true })
    .in('id', messageIds)
    .eq('user_id', userId)

  if (error) {
    throw new Error(error.message)
  }

  return new Response(
    JSON.stringify({ success: true }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  )
}
