-- OpenWave Music Streaming App - Supabase Database Schema
-- Supports: Authentication, Music Streaming, Gamification, Analytics, Chat

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================
-- USERS TABLE (extends auth.users)
-- ============================================
CREATE TABLE IF NOT EXISTS public.users (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL UNIQUE,
    username TEXT UNIQUE,
    role TEXT DEFAULT 'user' CHECK (role IN ('user', 'admin')),
    avatar_url TEXT,
    points INTEGER DEFAULT 0,
    coins INTEGER DEFAULT 0,
    level INTEGER DEFAULT 1,
    total_listening_time INTEGER DEFAULT 0, -- in minutes
    last_daily_reward TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- TRACKS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS public.tracks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    artist TEXT NOT NULL,
    album TEXT,
    duration INTEGER, -- in seconds
    audio_url TEXT NOT NULL,
    audio_url_aac TEXT, -- AAC streaming format
    cover_url TEXT,
    genre TEXT,
    plays INTEGER DEFAULT 0,
    uploaded_by UUID REFERENCES public.users(id),
    is_processed BOOLEAN DEFAULT FALSE,
    original_format TEXT,
    bitrate INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- PLAYLISTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS public.playlists (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    description TEXT,
    user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    cover_url TEXT,
    is_public BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- PLAYLIST TRACKS (junction table)
-- ============================================
CREATE TABLE IF NOT EXISTS public.playlist_tracks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    playlist_id UUID NOT NULL REFERENCES public.playlists(id) ON DELETE CASCADE,
    track_id UUID NOT NULL REFERENCES public.tracks(id) ON DELETE CASCADE,
    position INTEGER DEFAULT 0,
    added_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(playlist_id, track_id)
);

-- ============================================
-- LIKES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS public.likes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    track_id UUID NOT NULL REFERENCES public.tracks(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, track_id)
);

-- ============================================
-- LISTENING HISTORY TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS public.listening_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    track_id UUID NOT NULL REFERENCES public.tracks(id) ON DELETE CASCADE,
    played_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    duration INTEGER DEFAULT 0, -- seconds listened
    completed BOOLEAN DEFAULT FALSE
);

-- ============================================
-- OFFLINE DOWNLOADS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS public.offline_downloads (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    track_id UUID NOT NULL REFERENCES public.tracks(id) ON DELETE CASCADE,
    local_path TEXT,
    downloaded_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE,
    UNIQUE(user_id, track_id)
);

-- ============================================
-- MESSAGES TABLE (User-Admin Chat)
-- ============================================
CREATE TABLE IF NOT EXISTS public.messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    message TEXT NOT NULL,
    reply TEXT,
    is_read BOOLEAN DEFAULT FALSE,
    replied_by UUID REFERENCES public.users(id),
    replied_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- ANALYTICS EVENTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS public.analytics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_type TEXT NOT NULL CHECK (event_type IN (
        'track_play', 'track_complete', 'track_like', 'track_unlike',
        'playlist_create', 'playlist_add_track', 'playlist_remove_track',
        'user_login', 'user_signup', 'user_logout',
        'search_query', 'download_track', 'radio_play',
        'daily_reward_claim', 'wheel_spin', 'level_up'
    )),
    user_id UUID REFERENCES public.users(id) ON DELETE SET NULL,
    track_id UUID REFERENCES public.tracks(id) ON DELETE SET NULL,
    playlist_id UUID REFERENCES public.playlists(id) ON DELETE SET NULL,
    metadata JSONB,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- DAILY REWARDS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS public.daily_rewards (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    reward_date DATE NOT NULL DEFAULT CURRENT_DATE,
    points_rewarded INTEGER DEFAULT 20,
    coins_rewarded INTEGER DEFAULT 10,
    claimed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, reward_date)
);

-- ============================================
-- WHEEL SPINS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS public.wheel_spins (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    spin_date DATE NOT NULL DEFAULT CURRENT_DATE,
    reward_type TEXT NOT NULL CHECK (reward_type IN ('points', 'coins', 'xp')),
    reward_amount INTEGER NOT NULL,
    claimed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, spin_date)
);

-- ============================================
-- LEVEL REQUIREMENTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS public.level_requirements (
    level INTEGER PRIMARY KEY,
    points_required INTEGER NOT NULL,
    coins_reward INTEGER DEFAULT 0,
    description TEXT
);

-- Insert level requirements
INSERT INTO public.level_requirements (level, points_required, coins_reward, description) VALUES
(1, 0, 0, 'Новачок'),
(2, 100, 5, 'Слухач'),
(3, 300, 10, 'Меломан'),
(4, 600, 15, 'Експерт'),
(5, 1000, 20, 'Майстер'),
(6, 1500, 25, 'Профі'),
(7, 2100, 30, 'Зірка'),
(8, 2800, 35, 'Легенда'),
(9, 3600, 40, 'Ікона'),
(10, 4500, 50, 'Бог музики')
ON CONFLICT (level) DO NOTHING;

-- ============================================
-- AI RECOMMENDATIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS public.ai_recommendations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    track_id UUID NOT NULL REFERENCES public.tracks(id) ON DELETE CASCADE,
    score FLOAT NOT NULL, -- recommendation score 0-1
    reason TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, track_id)
);

-- ============================================
-- RADIO SESSIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS public.radio_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    seed_track_id UUID REFERENCES public.tracks(id),
    genre TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    ended_at TIMESTAMP WITH TIME ZONE
);

-- ============================================
-- INDEXES FOR PERFORMANCE
-- ============================================
CREATE INDEX IF NOT EXISTS idx_tracks_artist ON public.tracks(artist);
CREATE INDEX IF NOT EXISTS idx_tracks_genre ON public.tracks(genre);
CREATE INDEX IF NOT EXISTS idx_tracks_plays ON public.tracks(plays DESC);
CREATE INDEX IF NOT EXISTS idx_tracks_created ON public.tracks(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_likes_user ON public.likes(user_id);
CREATE INDEX IF NOT EXISTS idx_likes_track ON public.likes(track_id);

CREATE INDEX IF NOT EXISTS idx_listening_history_user ON public.listening_history(user_id);
CREATE INDEX IF NOT EXISTS idx_listening_history_track ON public.listening_history(track_id);
CREATE INDEX IF NOT EXISTS idx_listening_history_played ON public.listening_history(played_at DESC);

CREATE INDEX IF NOT EXISTS idx_playlist_tracks_playlist ON public.playlist_tracks(playlist_id);
CREATE INDEX IF NOT EXISTS idx_playlist_tracks_track ON public.playlist_tracks(track_id);

CREATE INDEX IF NOT EXISTS idx_analytics_user ON public.analytics(user_id);
CREATE INDEX IF NOT EXISTS idx_analytics_event ON public.analytics(event_type);
CREATE INDEX IF NOT EXISTS idx_analytics_timestamp ON public.analytics(timestamp DESC);

CREATE INDEX IF NOT EXISTS idx_messages_user ON public.messages(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_created ON public.messages(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_users_points ON public.users(points DESC);
CREATE INDEX IF NOT EXISTS idx_users_listening_time ON public.users(total_listening_time DESC);

-- ============================================
-- ROW LEVEL SECURITY POLICIES
-- ============================================

-- Enable RLS on all tables
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tracks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.playlists ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.playlist_tracks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.listening_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.offline_downloads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.daily_rewards ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wheel_spins ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_recommendations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.radio_sessions ENABLE ROW LEVEL SECURITY;

-- Users table policies
CREATE POLICY "Users can view own profile" ON public.users
    FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON public.users
    FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Admins can view all users" ON public.users
    FOR SELECT USING (
        EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
    );

-- Tracks table policies
CREATE POLICY "Anyone can view tracks" ON public.tracks
    FOR SELECT USING (true);

CREATE POLICY "Only admins can insert tracks" ON public.tracks
    FOR INSERT WITH CHECK (
        EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
    );

CREATE POLICY "Only admins can update tracks" ON public.tracks
    FOR UPDATE USING (
        EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
    );

CREATE POLICY "Only admins can delete tracks" ON public.tracks
    FOR DELETE USING (
        EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
    );

-- Playlists table policies
CREATE POLICY "Users can view public playlists" ON public.playlists
    FOR SELECT USING (is_public = true OR user_id = auth.uid());

CREATE POLICY "Users can manage own playlists" ON public.playlists
    FOR ALL USING (user_id = auth.uid());

-- Playlist tracks policies
CREATE POLICY "Users can view playlist tracks" ON public.playlist_tracks
    FOR SELECT USING (
        EXISTS (SELECT 1 FROM public.playlists WHERE id = playlist_id AND (is_public = true OR user_id = auth.uid()))
    );

CREATE POLICY "Users can manage own playlist tracks" ON public.playlist_tracks
    FOR ALL USING (
        EXISTS (SELECT 1 FROM public.playlists WHERE id = playlist_id AND user_id = auth.uid())
    );

-- Likes table policies
CREATE POLICY "Users can view own likes" ON public.likes
    FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can manage own likes" ON public.likes
    FOR ALL USING (user_id = auth.uid());

-- Listening history policies
CREATE POLICY "Users can view own history" ON public.listening_history
    FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can insert own history" ON public.listening_history
    FOR INSERT WITH CHECK (user_id = auth.uid());

-- Offline downloads policies
CREATE POLICY "Users can manage own downloads" ON public.offline_downloads
    FOR ALL USING (user_id = auth.uid());

-- Messages policies
CREATE POLICY "Users can view own messages" ON public.messages
    FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can insert own messages" ON public.messages
    FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins can view all messages" ON public.messages
    FOR SELECT USING (
        EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
    );

CREATE POLICY "Admins can reply to messages" ON public.messages
    FOR UPDATE USING (
        EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
    );

-- Analytics policies
CREATE POLICY "Users can insert analytics" ON public.analytics
    FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins can view analytics" ON public.analytics
    FOR SELECT USING (
        EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
    );

-- Daily rewards policies
CREATE POLICY "Users can view own rewards" ON public.daily_rewards
    FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can insert own rewards" ON public.daily_rewards
    FOR INSERT WITH CHECK (user_id = auth.uid());

-- Wheel spins policies
CREATE POLICY "Users can view own spins" ON public.wheel_spins
    FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can insert own spins" ON public.wheel_spins
    FOR INSERT WITH CHECK (user_id = auth.uid());

-- AI recommendations policies
CREATE POLICY "Users can view own recommendations" ON public.ai_recommendations
    FOR SELECT USING (user_id = auth.uid());

-- Radio sessions policies
CREATE POLICY "Users can manage own radio sessions" ON public.radio_sessions
    FOR ALL USING (user_id = auth.uid());

-- ============================================
-- FUNCTIONS AND TRIGGERS
-- ============================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for updated_at
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_tracks_updated_at BEFORE UPDATE ON public.tracks
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_playlists_updated_at BEFORE UPDATE ON public.playlists
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to increment track plays
CREATE OR REPLACE FUNCTION increment_track_plays(track_uuid UUID)
RETURNS VOID AS $$
BEGIN
    UPDATE public.tracks SET plays = plays + 1 WHERE id = track_uuid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to update user listening time and points
CREATE OR REPLACE FUNCTION update_user_listening_stats(
    user_uuid UUID,
    listen_duration INTEGER -- in minutes
)
RETURNS VOID AS $$
DECLARE
    new_points INTEGER;
    new_coins INTEGER;
    new_level INTEGER;
BEGIN
    -- Calculate new stats
    new_points := listen_duration;
    new_coins := listen_duration / 10;
    
    -- Update user stats
    UPDATE public.users 
    SET 
        total_listening_time = total_listening_time + listen_duration,
        points = points + new_points,
        coins = coins + new_coins
    WHERE id = user_uuid;
    
    -- Check for level up
    SELECT level INTO new_level FROM public.level_requirements 
    WHERE points_required <= (SELECT points FROM public.users WHERE id = user_uuid)
    ORDER BY level DESC LIMIT 1;
    
    IF new_level IS NOT NULL THEN
        UPDATE public.users SET level = new_level WHERE id = user_uuid AND level < new_level;
    END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to claim daily reward
CREATE OR REPLACE FUNCTION claim_daily_reward(user_uuid UUID)
RETURNS JSONB AS $$
DECLARE
    last_claim TIMESTAMP WITH TIME ZONE;
    result JSONB;
BEGIN
    -- Get last claim date
    SELECT last_daily_reward INTO last_claim FROM public.users WHERE id = user_uuid;
    
    -- Check if already claimed today
    IF last_claim IS NOT NULL AND DATE(last_claim) = CURRENT_DATE THEN
        RETURN jsonb_build_object('success', false, 'message', 'Reward already claimed today');
    END IF;
    
    -- Insert daily reward record
    INSERT INTO public.daily_rewards (user_id, reward_date, points_rewarded, coins_rewarded)
    VALUES (user_uuid, CURRENT_DATE, 20, 10)
    ON CONFLICT (user_id, reward_date) DO NOTHING;
    
    -- Update user stats
    UPDATE public.users 
    SET 
        points = points + 20,
        coins = coins + 10,
        last_daily_reward = NOW()
    WHERE id = user_uuid;
    
    RETURN jsonb_build_object('success', true, 'points', 20, 'coins', 10);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to spin bonus wheel
CREATE OR REPLACE FUNCTION spin_bonus_wheel(user_uuid UUID)
RETURNS JSONB AS $$
DECLARE
    reward_types TEXT[] := ARRAY['points', 'coins', 'xp'];
    selected_type TEXT;
    reward_amount INTEGER;
    result JSONB;
BEGIN
    -- Check if already spun today
    IF EXISTS (SELECT 1 FROM public.wheel_spins WHERE user_id = user_uuid AND spin_date = CURRENT_DATE) THEN
        RETURN jsonb_build_object('success', false, 'message', 'Wheel already spun today');
    END IF;
    
    -- Random reward type
    selected_type := reward_types[1 + floor(random() * array_length(reward_types, 1))];
    
    -- Random amount based on type
    CASE selected_type
        WHEN 'points' THEN reward_amount := 10 + floor(random() * 90)::INTEGER; -- 10-100 points
        WHEN 'coins' THEN reward_amount := 5 + floor(random() * 45)::INTEGER; -- 5-50 coins
        WHEN 'xp' THEN reward_amount := 5 + floor(random() * 20)::INTEGER; -- 5-25 XP
    END CASE;
    
    -- Insert spin record
    INSERT INTO public.wheel_spins (user_id, spin_date, reward_type, reward_amount)
    VALUES (user_uuid, CURRENT_DATE, selected_type, reward_amount);
    
    -- Apply reward
    CASE selected_type
        WHEN 'points' THEN UPDATE public.users SET points = points + reward_amount WHERE id = user_uuid;
        WHEN 'coins' THEN UPDATE public.users SET coins = coins + reward_amount WHERE id = user_uuid;
        WHEN 'xp' THEN UPDATE public.users SET points = points + reward_amount WHERE id = user_uuid;
    END CASE;
    
    RETURN jsonb_build_object('success', true, 'type', selected_type, 'amount', reward_amount);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get leaderboard by points
CREATE OR REPLACE FUNCTION get_leaderboard_by_points(limit_count INTEGER DEFAULT 100)
RETURNS TABLE (
    rank BIGINT,
    user_id UUID,
    username TEXT,
    avatar_url TEXT,
    points INTEGER,
    level INTEGER
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        ROW_NUMBER() OVER (ORDER BY u.points DESC)::BIGINT as rank,
        u.id as user_id,
        u.username,
        u.avatar_url,
        u.points,
        u.level
    FROM public.users u
    WHERE u.role = 'user'
    ORDER BY u.points DESC
    LIMIT limit_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get leaderboard by listening time
CREATE OR REPLACE FUNCTION get_leaderboard_by_listening_time(limit_count INTEGER DEFAULT 100)
RETURNS TABLE (
    rank BIGINT,
    user_id UUID,
    username TEXT,
    avatar_url TEXT,
    total_listening_time INTEGER,
    level INTEGER
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        ROW_NUMBER() OVER (ORDER BY u.total_listening_time DESC)::BIGINT as rank,
        u.id as user_id,
        u.username,
        u.avatar_url,
        u.total_listening_time,
        u.level
    FROM public.users u
    WHERE u.role = 'user'
    ORDER BY u.total_listening_time DESC
    LIMIT limit_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to generate AI recommendations for a user
CREATE OR REPLACE FUNCTION generate_ai_recommendations(user_uuid UUID, limit_count INTEGER DEFAULT 20)
RETURNS VOID AS $$
BEGIN
    -- Delete old recommendations
    DELETE FROM public.ai_recommendations WHERE user_id = user_uuid;
    
    -- Insert new recommendations based on listening history and likes
    INSERT INTO public.ai_recommendations (user_id, track_id, score, reason)
    SELECT 
        user_uuid,
        t.id as track_id,
        CASE 
            WHEN lh.track_id IS NOT NULL THEN 0.8 + random() * 0.2
            WHEN l.track_id IS NOT NULL THEN 0.7 + random() * 0.2
            ELSE 0.5 + random() * 0.3
        END as score,
        CASE 
            WHEN lh.track_id IS NOT NULL THEN 'Based on your listening history'
            WHEN l.track_id IS NOT NULL THEN 'Similar to tracks you like'
            ELSE 'Popular in your region'
        END as reason
    FROM public.tracks t
    LEFT JOIN public.listening_history lh ON t.id = lh.track_id AND lh.user_id = user_uuid
    LEFT JOIN public.likes l ON t.id = l.track_id AND l.user_id = user_uuid
    WHERE t.id NOT IN (SELECT track_id FROM public.listening_history WHERE user_id = user_uuid AND played_at > NOW() - INTERVAL '7 days')
    ORDER BY score DESC, t.plays DESC
    LIMIT limit_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================
-- REALTIME SUBSCRIPTIONS
-- ============================================

-- Enable realtime for messages
ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;

-- Enable realtime for tracks
ALTER PUBLICATION supabase_realtime ADD TABLE public.tracks;

-- Enable realtime for users (for points/level updates)
ALTER PUBLICATION supabase_realtime ADD TABLE public.users;

-- ============================================
-- STORAGE BUCKETS
-- ============================================

-- Create storage buckets (run these in Supabase dashboard Storage section)
-- Bucket: music-files - for audio files
-- Bucket: covers - for album/track covers
-- Bucket: avatars - for user avatars

-- Storage policies will be configured via Supabase dashboard or separate SQL
